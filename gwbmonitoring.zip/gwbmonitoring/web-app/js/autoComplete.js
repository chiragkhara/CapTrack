
if(typeof String.prototype.trim !== 'function') {
  String.prototype.trim = function() {
    return this.replace(/^\s+|\s+$/g, ''); 
  }
}

function autoCompleteAssign(domObjJQuery,url,functionName,selectField,minChar,extraFields){

	var functionCall = window[functionName]
	var minLen = 3;
	
	if(typeof minChar == 'undefined'){
		minLen = 3;
	}else{
		minLen = minChar;
	}
	
	if(!$('*').hasClass('ui-autocomplete-loading')){
		var spinnerStyle =  ".ui-autocomplete-loading {	background: white url('/ServicePortal/images/spinner.gif') right center no-repeat";	
		$("<style type='text/css'>"+spinnerStyle+"</style>").appendTo("head");
	}
	
	domObjJQuery.autocomplete({
			source: function(request, response) {
				$.ajax({
					url:url, 
					data: { 
						id: request.term.trim()
					}, 
	                 success: function( data ) {
	                	 if(data.length==0){ alert("No value was returned for your search term: '"+request.term.trim()+"'.\nPlease try again")}
	                	 
	                     response( $.map( data, function( item ) {
	                         return {
	                             data:item
	                         }
	                     }));
	                 }
	                });
	            },
	        minLength: minLen,
	        select: function( event, ui ) {
	        	domObjJQuery.val(ui.item.data[selectField])
	        	if (typeof functionCall === "function"){
	        		var params = []
	        		params.push([ui.item.data[selectField]])
	        		
	        		if(typeof extraFields!= 'undefined'){
	        			$.each(extraFields,function(k,v){
	    					var stringParam = ui.item.data[v]
	        				params.push(stringParam)
	    				})
	        		}
	        		
	        		functionCall.apply(null, params);
	        	}
	        	return false
	        }
	            
	    }).data( "ui-autocomplete" )._renderItem = function( ul, item ) {
	    		var strDropDown = "<a>" + item.data[selectField]
	    		if(typeof extraFields!= 'undefined'){
	    			$.each(extraFields,function(k,v){
	    				strDropDown += "<BR>"+item.data[v]
	    			})
	    		}
	    		strDropDown += "</a>"
	    		return $( "<li>" ).append(strDropDown).appendTo(ul)
	    };
	    
}	