package gwbmonitoring

import grails.converters.JSON
import groovy.sql.Sql
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.*
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class EngagementController {
	def dataSource
	def aitLookup

    def index() {
		getUser()
		redirect(action: "hpd", params: params)
	
	}
	
	def hpd() {
		getUser()
	}
	
	def retrieve_portfolio() {
		getUser()
	}
	
	def cemonitor() {
		getUser()
	}
	
	def nexusLookup(){
		def db = new Sql(dataSource)
		def nexusLookup = params.nexusnumber
		
		def queryString = """\
			Select distinct nexus_id as nexus_id from hotpdb.mon_engagement_inputs 
			WHERE mon_engagement_inputs.nexus_id LIKE '"""+nexusLookup+"""%'
			LIMIT 10
		"""
			
		println queryString
		
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def list() {
	}

	def getUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "chirag.khara@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "chirag.khara@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
}
