package gwbmonitoring

import org.springframework.dao.DataIntegrityViolationException
import grails.converters.JSON
import groovy.sql.Sql
import com.bankofamerica.gwbio.ia.LDAPFunctions.*
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

class GwbmonitoringController {
	def dataSource
	
    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }
	
	def document_resources() {
		
	}
	
	def getUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "chirag.khara@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "chirag.khara@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
	
    def list() {
        [gwbmonitoringInstanceList: Gwbmonitoring.list(params)]
    }
	
	def wosheet() {
		def nexus_rec = params['nexusID']
		
		def configureList = Gwbmonitoring.findAll("from Gwbmonitoring as GM where GM.nexus_id = ${nexus_rec}")
		def monengageList = MonEngagement.findAll("from MonEngagement as ME where ME.nexus_id = ${nexus_rec}")
		
		[engageList: monengageList, gwbmonList: configureList]
	}
	
	def retrieveData() {
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		params.remove('username')
		
		def nexus_value = params.get('nexusID')
		
		redirect(action: "monitoring_portfolio", params: [nexusID: nexus_value])
	}
	
	def checkValuesExist(){
		def db = new Sql(dataSource)
		def nexusid = params.get('nexusid')
		
		def queryString = """\
			Select count(monitoring_engagement.nexus_id) as nexuscount
			FROM hotpdb.monitoring_engagement 
			WHERE monitoring_engagement.nexus_id = ${nexusid}
		"""
		
		//println queryString
		def result = db.firstRow(queryString).nexuscount
		
		if(result == 0){
			render 'NEW_NEXUS';
		}
		else{
			render 'NEXUS_EXISTS'
		}	
	}
	
	def monitoring_portfolio() {
		def nexus_rec = params['nexusID']
		
		def configureList = Gwbmonitoring.findAll("from Gwbmonitoring as GM where GM.nexus_id = ${nexus_rec}")
		def monengageList = MonEngagement.findAll("from MonEngagement as ME where ME.nexus_id = ${nexus_rec}")
		
		[engageList: monengageList, gwbmonList: configureList]
	}
	
	def monitoring_print() {
		def nexus_rec = params['nexusID']
		
		def configureList = Gwbmonitoring.findAll("from Gwbmonitoring as GM where GM.nexus_id = ${nexus_rec}")
		def monengageList = MonEngagement.findAll("from MonEngagement as ME where ME.nexus_id = ${nexus_rec}")
		
		[engageList: monengageList, gwbmonList: configureList]
	}
	
	def hpdlist() {
		def nexus_rec = params['nexusID']
		def configureList = Gwbmonitoring.findAll("from Gwbmonitoring as GM where GM.nexus_id = ${nexus_rec}")
		[gwbmonList: configureList]
	}

    def create() {
        [gwbmonitoringInstance: new Gwbmonitoring(params)]
    }
	
	def aitLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,
			capacity_workflow_master.aittier,capacity_workflow_master.ucal_flag,
			capacity_workflow_master.appmanager FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%')
			LIMIT 10
		"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def ceLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,
			capacity_workflow_master.aittier,capacity_workflow_master.ucal_flag,
			capacity_workflow_master.appmanager FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%')
			LIMIT 10
		"""
		def result = db.rows(queryString)
		render result as JSON
	}

	
	/* CE Input FORM PROCESSING function */
	
	def ceData(){
		def db = new Sql(dataSource)
		
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		params.remove('username')
		
		def nexusID = params.get('nexusID')
		print "Working on - " + nexusID
		// Flag which determines whether old AIT or new AIT
		def aitFlag = params.get('aitinput')
		def applocation = params.get('location')
		def apptier = params.get('appnewtier')
		def appucal = params.get('appnewucal')
		def appvendor = params.get('appvendor')
		
		int webservers
		if (params.get('webservers')){
			webservers = 1;
		}else{
			webservers = 0;
		}
		
		int iis
		if (params.get('iis')){
			iis = 1;
		}else{
			iis = 0;
		}
		
		int javaApp
		if (params.get('java_app')){
			javaApp = 1;
		}else{
			javaApp = 0;
		}
		
		int dotnet
		if (params.get('dotnet')){
			dotnet = 1;
		}else{
			dotnet = 0;
		}
		
		int dbaccess
		if (params.get('database')){
			dbaccess = 1;
		}else{
			dbaccess = 0;
		}
		
		int cvactive
		if (params.get('cvactive')){
			cvactive = 1;
		}else{
			cvactive = 0;
		}
		
		int connectdirect
		if (params.get('connectdirect')){
			connectdirect = 1;
		}else{
			connectdirect = 0;
		}
		
		int netbackup
		if (params.get('netbackup')){
			netbackup = 1;
		}else{
			netbackup = 0;
		}
		
		int ibmmq
		if (params.get('ibmmq')){
			ibmmq = 1;
		}else{
			ibmmq = 0;
		}
		
		int batchprocess
		if (params.get('batchprocess')){
			batchprocess = 1;
		}else{
			batchprocess = 0;
		}
		
		def profiler = session['name']
		def profiler_email = session['email']
		
		def date_got = new Date();
		DateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
		def date_received = dateFormat.format(date_got);
		
		def input_type
		int aitnum
		if (aitFlag == "No"){
			def ceInputs = params.get('ceInput')
			//println "CE Labels --> " + ceInputs
			String[] ceAITs = ceInputs.split("\n")
			for(String str: ceAITs){
				aitnum = Integer.parseInt(str.trim());
				println "Array Value : " + aitnum;
				//-- Extract Apptier Data for this AIT from MDH
				
				def createString = """\
					insert into hotpdb.mon_engagement_inputs (input_type,aitnumber,apptier,appucal,vendor,nexus_id,webapp_flag,java_app_flag,iis_flag,
					dotnet_flag,db_flag,mq_flag,cvactive_flag,cdirect_flag,netbackup_flag,batchproc_flag,hw_location,profiler,profiler_email,profiledate) values
					('FALSE',${aitnum},${apptier},${appucal},${appvendor},${nexusID},${webservers},${javaApp},${iis},${dotnet},${dbaccess},${ibmmq},${cvactive},${connectdirect},
					${netbackup},${batchprocess},'${applocation}','${profiler}','${profiler_email}',${date_received})
				"""
				
				println createString
				def dataCreate = db.execute(createString)
			} // END FOR LOOP OF EACH AIT
			
		} else{
			aitnum = params.int('aitNew')	
			def createString = """\
					insert into hotpdb.mon_engagement_inputs (input_type,aitnumber,apptier,appucal,vendor,nexus_id,webapp_flag,java_app_flag,iis_flag,
					dotnet_flag,db_flag,mq_flag,cvactive_flag,cdirect_flag,netbackup_flag,batchproc_flag,hw_location,profiler,profiler_email,profiledate) values
					('TRUE',${aitnum},${apptier},${appucal},${appvendor},${nexusID},${webservers},${javaApp},${iis},${dotnet},${dbaccess},${ibmmq},${cvactive},${connectdirect},
					${netbackup},${batchprocess},'${applocation}','${profiler}','${profiler_email}',${date_received})
				"""			
			println createString
			def dataCreate = db.execute(createString)
		}
		
		/* Evaluations for the Monitoring Engagement Table - Based on Nexus Request ID */
		int service_data 
		def service_flag
		service_data = Integer.parseInt(apptier);
		
		/* Set Vendor Flag for next set of evaluations */
		int vendor_flag;
		vendor_flag = Integer.parseInt(appvendor);
		
		int tivoli_flag, bluestripe_flag, introscope_flag, oem_flag
		int foglight_flag, iis_flag, dotnet_flag, splunk_flag 
		def engagement_string
		/* Determine Service State-based on Recovery Tier*/
		
		if (service_data > 4){
			service_flag = 'BRONZE';
			bluestripe_flag= 0;
		} else {
			service_flag = 'GOLD';
			bluestripe_flag = 1;
		}
		
		/*--- UPDATES FOR ENGAGEMENT ---*/
		if (!vendor_flag) {
		
			/* Set Tivoli Flag */
			if ((webservers == 1) || (javaApp == 1) || (iis == 1) 
				|| (dotnet == 1) || (dbaccess == 1)|| (ibmmq == 1)
					|| (cvactive == 1) || (connectdirect == 1)){
					tivoli_flag = 1;
			}else{
					tivoli_flag = 0;
			}
			
			/* Set Introscope Flag */
			if ((service_flag == 'GOLD') && (javaApp == 1)){
				introscope_flag = 1;
			}else{
				introscope_flag = 0;
			}
			
			/* Set SPLUNK Flag */
			if ((webservers == 1 || javaApp == 1 || iis == 1 || dotnet == 1 || dbaccess == 1|| ibmmq == 1)
				&& (applocation == 'AMRS' || applocation == 'Multisite')){
				splunk_flag = 1;
			}else{
				splunk_flag = 0;
			}
			
			int sitescope_flag;
			/* Set Sitescope Flag */
			if (webservers == 1 || iis == 1 || dotnet == 1){
				sitescope_flag = 1;
			}else{
				sitescope_flag = 0;
			}
			
			/* Set Foglight Flag */
			if (dbaccess == 1){
				foglight_flag = 1;
			}else{
				foglight_flag = 0;
			}
			
			/* Set OEM Flag */
			if ((dbaccess == 1) && (applocation == 'AMRS' || applocation == 'Multisite')){
				oem_flag = 1;
			}else{
				oem_flag = 0;
			}
			
				engagement_string = """\
					insert into hotpdb.monitoring_engagement(nexus_id,service_flag,hosting_flag,itm,introscope,
					foglight,oem,splunk,bluestripe,cvactive,connectdirect,omegamon,sitescope) values
					(${nexusID},'${service_flag}','NO',${tivoli_flag},${introscope_flag},${foglight_flag},${oem_flag},
					${splunk_flag},${bluestripe_flag},${cvactive},${connectdirect},${ibmmq},${sitescope_flag})
				"""		
				println engagement_string
				db.execute(engagement_string)
	
			/* Evaluations End */
		}else{
				engagement_string = """\
					insert into hotpdb.monitoring_engagement(nexus_id,service_flag,hosting_flag) values 
					(${nexusID},${service_flag},'YES')
				"""
				println engagement_string
				db.execute(engagement_string)
		}
	
		redirect(action: "monitoring_portfolio", params: [nexusID: nexusID])
	}
	
    def save() {
        def gwbmonitoringInstance = new Gwbmonitoring(params)
        if (!gwbmonitoringInstance.save(flush: true)) {
            render(view: "create", model: [gwbmonitoringInstance: gwbmonitoringInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), gwbmonitoringInstance.id])
        redirect(action: "show", id: gwbmonitoringInstance.id)
    }

    def show() {
        def gwbmonitoringInstance = Gwbmonitoring.get(params.id)
        if (!gwbmonitoringInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "list")
            return
        }

        [gwbmonitoringInstance: gwbmonitoringInstance]
    }

    def edit() {
        def gwbmonitoringInstance = Gwbmonitoring.get(params.id)
        if (!gwbmonitoringInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "list")
            return
        }

        [gwbmonitoringInstance: gwbmonitoringInstance]
    }

    def update() {
        def gwbmonitoringInstance = Gwbmonitoring.get(params.id)
        if (!gwbmonitoringInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (gwbmonitoringInstance.version > version) {
                gwbmonitoringInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring')] as Object[],
                          "Another user has updated this Gwbmonitoring while you were editing")
                render(view: "edit", model: [gwbmonitoringInstance: gwbmonitoringInstance])
                return
            }
        }

        gwbmonitoringInstance.properties = params

        if (!gwbmonitoringInstance.save(flush: true)) {
            render(view: "edit", model: [gwbmonitoringInstance: gwbmonitoringInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), gwbmonitoringInstance.id])
        redirect(action: "show", id: gwbmonitoringInstance.id)
    }

    def delete() {
        def gwbmonitoringInstance = Gwbmonitoring.get(params.id)
        if (!gwbmonitoringInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "list")
            return
        }

        try {
            gwbmonitoringInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'gwbmonitoring.label', default: 'Gwbmonitoring'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
