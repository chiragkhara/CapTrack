package gwbmonitoring

class Gwbmonitoring {
	
	Integer aitnumber
	String input_type
	Integer nexus_id
	Integer webapp_flag 
	Integer java_app_flag 
	Integer iis_flag 
	Integer dotnet_flag 
	Integer db_flag 
	Integer mq_flag
	Integer netbackup_flag 
	Integer apptier 
	Integer cvactive_flag  
	String hw_location
	Integer cdirect_flag
	Integer batchproc_flag  
	String profiler
	String profiler_email
	Date profiledate

	static mapping = {
		table name: 'mon_engagement_inputs', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'engid'
	}
	
    static constraints = {
		aitnumber(size:0..10)
		profiler(size:0..127)
		profiler_email(size:0..511)
    }
}
