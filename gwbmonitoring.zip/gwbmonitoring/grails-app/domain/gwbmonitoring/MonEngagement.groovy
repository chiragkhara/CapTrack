package gwbmonitoring

class MonEngagement {
	
	Integer nexus_id
	String service_flag
	String hosting_flag
	Integer itm
	Integer introscope
	Integer foglight
	Integer oem
	Integer splunk
	Integer bluestripe
	Integer cvactive
	Integer connectdirect
	Integer omegamon
	Integer sitescope
	
	static mapping = {
		table name: 'monitoring_engagement', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
	}
	
    static constraints = {
		nexus_id(size:0..10)
		service_flag(size:0..15)
    }
}
