[![Build Status](https://travis-ci.org/gpc/grails-export.svg)](https://travis-ci.org/gpc/grails-export)

Grails Export Plugin
====================

Primary fork of the original export plugin. Sources forked from SVN and maintained here.
