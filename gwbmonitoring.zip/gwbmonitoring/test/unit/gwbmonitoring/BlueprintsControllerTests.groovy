package gwbmonitoring



import org.junit.*
import grails.test.mixin.*

@TestFor(BlueprintsController)
@Mock(Blueprints)
class BlueprintsControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/blueprints/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.blueprintsInstanceList.size() == 0
        assert model.blueprintsInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.blueprintsInstance != null
    }

    void testSave() {
        controller.save()

        assert model.blueprintsInstance != null
        assert view == '/blueprints/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/blueprints/show/1'
        assert controller.flash.message != null
        assert Blueprints.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/blueprints/list'


        populateValidParams(params)
        def blueprints = new Blueprints(params)

        assert blueprints.save() != null

        params.id = blueprints.id

        def model = controller.show()

        assert model.blueprintsInstance == blueprints
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/blueprints/list'


        populateValidParams(params)
        def blueprints = new Blueprints(params)

        assert blueprints.save() != null

        params.id = blueprints.id

        def model = controller.edit()

        assert model.blueprintsInstance == blueprints
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/blueprints/list'

        response.reset()


        populateValidParams(params)
        def blueprints = new Blueprints(params)

        assert blueprints.save() != null

        // test invalid parameters in update
        params.id = blueprints.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/blueprints/edit"
        assert model.blueprintsInstance != null

        blueprints.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/blueprints/show/$blueprints.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        blueprints.clearErrors()

        populateValidParams(params)
        params.id = blueprints.id
        params.version = -1
        controller.update()

        assert view == "/blueprints/edit"
        assert model.blueprintsInstance != null
        assert model.blueprintsInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/blueprints/list'

        response.reset()

        populateValidParams(params)
        def blueprints = new Blueprints(params)

        assert blueprints.save() != null
        assert Blueprints.count() == 1

        params.id = blueprints.id

        controller.delete()

        assert Blueprints.count() == 0
        assert Blueprints.get(blueprints.id) == null
        assert response.redirectedUrl == '/blueprints/list'
    }
}
