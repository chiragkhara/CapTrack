package gwbmonitoring



import org.junit.*
import grails.test.mixin.*

@TestFor(MonitoringConfigsController)
@Mock(MonitoringConfigs)
class MonitoringConfigsControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/monitoringConfigs/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.monitoringConfigsInstanceList.size() == 0
        assert model.monitoringConfigsInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.monitoringConfigsInstance != null
    }

    void testSave() {
        controller.save()

        assert model.monitoringConfigsInstance != null
        assert view == '/monitoringConfigs/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/monitoringConfigs/show/1'
        assert controller.flash.message != null
        assert MonitoringConfigs.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/monitoringConfigs/list'


        populateValidParams(params)
        def monitoringConfigs = new MonitoringConfigs(params)

        assert monitoringConfigs.save() != null

        params.id = monitoringConfigs.id

        def model = controller.show()

        assert model.monitoringConfigsInstance == monitoringConfigs
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/monitoringConfigs/list'


        populateValidParams(params)
        def monitoringConfigs = new MonitoringConfigs(params)

        assert monitoringConfigs.save() != null

        params.id = monitoringConfigs.id

        def model = controller.edit()

        assert model.monitoringConfigsInstance == monitoringConfigs
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/monitoringConfigs/list'

        response.reset()


        populateValidParams(params)
        def monitoringConfigs = new MonitoringConfigs(params)

        assert monitoringConfigs.save() != null

        // test invalid parameters in update
        params.id = monitoringConfigs.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/monitoringConfigs/edit"
        assert model.monitoringConfigsInstance != null

        monitoringConfigs.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/monitoringConfigs/show/$monitoringConfigs.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        monitoringConfigs.clearErrors()

        populateValidParams(params)
        params.id = monitoringConfigs.id
        params.version = -1
        controller.update()

        assert view == "/monitoringConfigs/edit"
        assert model.monitoringConfigsInstance != null
        assert model.monitoringConfigsInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/monitoringConfigs/list'

        response.reset()

        populateValidParams(params)
        def monitoringConfigs = new MonitoringConfigs(params)

        assert monitoringConfigs.save() != null
        assert MonitoringConfigs.count() == 1

        params.id = monitoringConfigs.id

        controller.delete()

        assert MonitoringConfigs.count() == 0
        assert MonitoringConfigs.get(monitoringConfigs.id) == null
        assert response.redirectedUrl == '/monitoringConfigs/list'
    }
}
