package gwbmonitoring



import org.junit.*
import grails.test.mixin.*

@TestFor(MonEngagementController)
@Mock(MonEngagement)
class MonEngagementControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/monEngagement/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.monEngagementInstanceList.size() == 0
        assert model.monEngagementInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.monEngagementInstance != null
    }

    void testSave() {
        controller.save()

        assert model.monEngagementInstance != null
        assert view == '/monEngagement/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/monEngagement/show/1'
        assert controller.flash.message != null
        assert MonEngagement.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/monEngagement/list'


        populateValidParams(params)
        def monEngagement = new MonEngagement(params)

        assert monEngagement.save() != null

        params.id = monEngagement.id

        def model = controller.show()

        assert model.monEngagementInstance == monEngagement
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/monEngagement/list'


        populateValidParams(params)
        def monEngagement = new MonEngagement(params)

        assert monEngagement.save() != null

        params.id = monEngagement.id

        def model = controller.edit()

        assert model.monEngagementInstance == monEngagement
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/monEngagement/list'

        response.reset()


        populateValidParams(params)
        def monEngagement = new MonEngagement(params)

        assert monEngagement.save() != null

        // test invalid parameters in update
        params.id = monEngagement.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/monEngagement/edit"
        assert model.monEngagementInstance != null

        monEngagement.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/monEngagement/show/$monEngagement.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        monEngagement.clearErrors()

        populateValidParams(params)
        params.id = monEngagement.id
        params.version = -1
        controller.update()

        assert view == "/monEngagement/edit"
        assert model.monEngagementInstance != null
        assert model.monEngagementInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/monEngagement/list'

        response.reset()

        populateValidParams(params)
        def monEngagement = new MonEngagement(params)

        assert monEngagement.save() != null
        assert MonEngagement.count() == 1

        params.id = monEngagement.id

        controller.delete()

        assert MonEngagement.count() == 0
        assert MonEngagement.get(monEngagement.id) == null
        assert response.redirectedUrl == '/monEngagement/list'
    }
}
