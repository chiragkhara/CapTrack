package gwbmonitoring



import org.junit.*
import grails.test.mixin.*

@TestFor(GwbmonitoringController)
@Mock(Gwbmonitoring)
class GwbmonitoringControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/gwbmonitoring/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.gwbmonitoringInstanceList.size() == 0
        assert model.gwbmonitoringInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.gwbmonitoringInstance != null
    }

    void testSave() {
        controller.save()

        assert model.gwbmonitoringInstance != null
        assert view == '/gwbmonitoring/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/gwbmonitoring/show/1'
        assert controller.flash.message != null
        assert Gwbmonitoring.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/gwbmonitoring/list'


        populateValidParams(params)
        def gwbmonitoring = new Gwbmonitoring(params)

        assert gwbmonitoring.save() != null

        params.id = gwbmonitoring.id

        def model = controller.show()

        assert model.gwbmonitoringInstance == gwbmonitoring
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/gwbmonitoring/list'


        populateValidParams(params)
        def gwbmonitoring = new Gwbmonitoring(params)

        assert gwbmonitoring.save() != null

        params.id = gwbmonitoring.id

        def model = controller.edit()

        assert model.gwbmonitoringInstance == gwbmonitoring
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/gwbmonitoring/list'

        response.reset()


        populateValidParams(params)
        def gwbmonitoring = new Gwbmonitoring(params)

        assert gwbmonitoring.save() != null

        // test invalid parameters in update
        params.id = gwbmonitoring.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/gwbmonitoring/edit"
        assert model.gwbmonitoringInstance != null

        gwbmonitoring.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/gwbmonitoring/show/$gwbmonitoring.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        gwbmonitoring.clearErrors()

        populateValidParams(params)
        params.id = gwbmonitoring.id
        params.version = -1
        controller.update()

        assert view == "/gwbmonitoring/edit"
        assert model.gwbmonitoringInstance != null
        assert model.gwbmonitoringInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/gwbmonitoring/list'

        response.reset()

        populateValidParams(params)
        def gwbmonitoring = new Gwbmonitoring(params)

        assert gwbmonitoring.save() != null
        assert Gwbmonitoring.count() == 1

        params.id = gwbmonitoring.id

        controller.delete()

        assert Gwbmonitoring.count() == 0
        assert Gwbmonitoring.get(gwbmonitoring.id) == null
        assert response.redirectedUrl == '/gwbmonitoring/list'
    }
}
