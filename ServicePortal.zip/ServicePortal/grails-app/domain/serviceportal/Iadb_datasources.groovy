package serviceportal

class Iadb_datasources {

	
	static mapping = {
		table name: 'iadb_datasources', schema: 'hotpdb'
		version false
		id column:'id'
		schema_name defaultValue: "'extdb'"
	}
	
	String schema_name
	String table_name
	String data_source
	String documentation_link
	String data_source_description

	
    static constraints = {
		schema_name(size: 0..45,blank:false)
		table_name(size: 0..45,unique:true,blank:false)
		data_source(size: 0..45,blank:false)
		data_source(size: 0..128,blank:false)
		documentation_link(size: 0..1024)
		data_source_description(size: 0..4000)
    }
}
