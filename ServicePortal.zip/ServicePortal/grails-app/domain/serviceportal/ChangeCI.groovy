package serviceportal

import java.util.Date;

class ChangeCI {

    static mapping = {
		 table name: 'mxo_ch_allact_ci_aits', schema: 'extdb'
         version false
         id column:'ait_number'
		 change column:'ancestor'
    }
	
	Change change
	String cinum
	String id
	String wonum
    String baflabel
    String assetnum
    String ciClassification
    String aitCinum
    //String aitNumber
    String aitName
    Date allactChangedate
    Date allactChangedateEt
    Date ciChangedate
    Date ciChangedateEt
    Date aitChangedate
    Date aitChangedateEt
}
