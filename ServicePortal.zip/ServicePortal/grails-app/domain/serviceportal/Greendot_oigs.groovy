package serviceportal

class Greendot_oigs {
	
	static mapping = {
		table name: 'greendot_oigs', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	
	String PGP
	
    static constraints = {
		PGP(size: 0..8,unique:true,blank:false)
    }
}
