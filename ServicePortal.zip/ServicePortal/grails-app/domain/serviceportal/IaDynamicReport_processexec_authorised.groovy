package serviceportal

class IaDynamicReport_processexec_authorised {

	
	static mapping = {
		table name: 'ia_dynamicreport_processexec_authorised', schema: 'hotpdb'
		version false
		id column:'id'
		processExec column:'processExec'
	}
	
	String username
	
	static belongsTo = [processExec:IaDynamicReport_processexec]
	
    static constraints = {
    }
}
