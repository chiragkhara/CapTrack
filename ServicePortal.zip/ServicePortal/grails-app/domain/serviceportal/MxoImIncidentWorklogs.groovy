package serviceportal

class MxoImIncidentWorklogs {
    static mapping = {
         table name: 'mxo_im_incident_worklogs', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'worklogid'
		 classField column: 'class'
    }
	String recordkey
    String logtype
    Integer clientviewable
    String description
    String descriptionLongdescription
    String classField
    String bacallernbid
    String bacallername
    String bacalleremail
    String createby
    String createbyDisplayname
    String createdbyHierarchy
    Date createdate
    Date createdateEt
    String modifyby
    Date modifydate
    Date modifydateEt
    Integer id
    Integer rowstamp
    Integer descriptionLdRowstamp
    Date balastupdate
    Date descriptionLdBalastupdate
    // Relation


    static constraints = {
        logtype(size: 0..16)
        clientviewable(nullable: true, max: 2147483647)
        description(size: 0..100)
        descriptionLongdescription(size: 0..30000)
        classField(size: 0..16)
        bacallernbid(size: 0..30)
        bacallername(size: 0..62)
        bacalleremail(size: 0..100)
        createby(size: 0..30)
        createbyDisplayname(size: 0..62)
        createdbyHierarchy(size: 0..25)
        createdate()
        createdateEt()
        modifyby(size: 0..30)
        modifydate()
        modifydateEt()
        //worklogid(nullable: true, max: 2147483647)
        rowstamp(nullable: true, max: 2147483647)
        descriptionLdRowstamp(nullable: true, max: 2147483647)
        balastupdate()
        descriptionLdBalastupdate()
    }
    String toString() {
        return "${worklogid}" 
    }
}
