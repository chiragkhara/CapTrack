package serviceportal

class Backupanalysis_answers {

	
	static mapping = {
		table name:'backupanalysis_answers', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	
	String answer
	Integer questionid
	Integer ait
	String submitter
	
    static constraints = {
		answer(size: 0..5000)
    }
}
