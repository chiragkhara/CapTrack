package serviceportal

class EARC_Compsys_OS {

	
	static mapping = {
		table name:'earc_compsys_os_product_list', schema: 'extdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'ProductID'
		cache usage: 'read-only'
   }
	
	String productname
	String classification
	String friendlyname
	String platform
	
    static constraints = {
    }
}
