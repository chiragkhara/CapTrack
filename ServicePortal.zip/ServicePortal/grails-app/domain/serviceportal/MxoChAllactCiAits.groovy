package serviceportal
class MxoChAllactCiAits {
    static mapping = {
		 table name: 'mxo_ch_allact_ci_aits', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'wonum'
		 hotp_id column: 'aitNumber'
		 hotp joinTable:[name:'Hotpgroupaits', key:'aitId', column:'aitNumber']
    }
		
		
	Hotpgroupaits hotp
	String hotp_id
    //String wonum
	//String id
    String ancestor
    String cinum
    String baflabel
    String assetnum
    String ciClassification
    String aitCinum
    //String aitNumber
    String aitName
    Date allactChangedate
    Date allactChangedateEt
    Date ciChangedate
    Date ciChangedateEt
    Date aitChangedate
    Date aitChangedateEt

    static constraints = {
        //wonum(size: 0..10)
        ancestor(size: 0..10)
        cinum(size: 0..150)
        baflabel(size: 0..80)
        assetnum(size: 0..12)
        ciClassification(size: 0..250)
        aitCinum(size: 0..150)
        //aitNumber(size: 0..254)
        aitName(size: 0..254)
        allactChangedate()
        allactChangedateEt()
        ciChangedate()
        ciChangedateEt()
        aitChangedate()
        aitChangedateEt()
    }
    String toString() {
        return "${wonum}" 
    }
}
