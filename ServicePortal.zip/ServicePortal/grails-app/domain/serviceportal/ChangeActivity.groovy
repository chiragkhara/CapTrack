package serviceportal

import java.util.Date;

class ChangeActivity {

    static mapping = {
		table name: 'mxo_ch_woactivities', schema: 'extdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'taskid'
		change column:'ancestor'
    }
	
	Integer id
	Change change
	
	String description
	Integer wosequence
	String bataskaction
	String bachgknownimpact
	Integer pmchgisimptask
	Date targstartdateEt
	Date targstartdate
	Date targcompdateEt
	Date targcompdate
	Date actfinishEt
	Date actfinish
	Date actstartEt
	Date actstart
	Integer baisciconflict
	Integer baiscwconflict
	Integer baismissingwindow
	String status
	String pmchgprogress
	String bachgimplementer
	String bachgimplementergrp
	String bacifilterclass
	Double baclassteamscore
	Double baclassscore
	Double bateamscore
	//String ancestor
	Date changedateEt
	Date changedate
	Integer rowstamp
}
