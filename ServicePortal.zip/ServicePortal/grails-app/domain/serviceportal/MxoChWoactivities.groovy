package serviceportal

class MxoChWoactivities {
    static mapping = {
         table name: 'mxo_ch_woactivities', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'taskid'

    }
	
	
    String wonumLabel
	Integer id
    //Integer taskid
    String description
    Integer wosequence
    String bataskaction
    String bachgknownimpact
    Integer pmchgisimptask
    Date targstartdateEt
    Date targstartdate
    Date targcompdateEt
    Date targcompdate
    Date actfinishEt
    Date actfinish
    Date actstartEt
    Date actstart
    Integer baisciconflict
    Integer baiscwconflict
    Integer baismissingwindow
    String status
    String pmchgprogress
    String bachgimplementer
    String bachgimplementergrp
    String bacifilterclass
    Double baclassteamscore
    Double baclassscore
    Double bateamscore
    String ancestor
    Date changedateEt
    Date changedate
    Integer rowstamp

    static constraints = {
        //wonum(size: 0..10)
        //taskid(nullable: true, max: 2147483647)
        description(size: 0..100)
        wosequence(nullable: true, max: 2147483647)
        bataskaction(size: 0..21)
        bachgknownimpact(size: 0..2)
        pmchgisimptask(nullable: true, max: 2147483647)
        targstartdateEt(nullable: true)
        targstartdate(nullable: true)
        targcompdateEt(nullable: true)
        targcompdate(nullable: true)
        actfinishEt(nullable: true)
        actfinish(nullable: true)
        actstartEt(nullable: true)
        actstart(nullable: true)
        baisciconflict(nullable: true, max: 2147483647)
        baiscwconflict(nullable: true, max: 2147483647)
        baismissingwindow(nullable: true, max: 2147483647)
        status(size: 0..16)
        pmchgprogress(size: 0..192)
        bachgimplementer(size: 0..30)
        bachgimplementergrp(size: 0..8)
        bacifilterclass(size: 0..20)
        baclassteamscore(nullable: true)
        baclassscore(nullable: true)
        bateamscore(nullable: true)
        ancestor(size: 0..10)
        changedateEt(nullable: true)
        changedate(nullable: true)
        rowstamp(nullable: true, max: 2147483647)
    }
    String toString() {
        return "${taskid}" 
    }
}
