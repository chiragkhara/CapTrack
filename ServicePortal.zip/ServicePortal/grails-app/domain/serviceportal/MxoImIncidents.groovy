package serviceportal

class MxoImIncidents {
    static mapping = {
         table name: 'mxo_im_incidents', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'id'
    }
	
	Integer id
	String ticketid
    String affectedperson
    String baagenttype
    String bacomputername
    String baimappassigngroup
    String baimappname
    String baimerrorcode
    String baimjobname
    String baimlob
    String baimschedulemaster
    String baimstepnumber
    String baimsupporthier
    String baimsupporthiercode
    String baimsystemid
    String banodealias
    String barestoralgroup
    String barestoredbyemail
    String barestoredbyname
    String barestoredbynbid
    String barestoredpersonhier
    Date batriageengageddate
    Date batriageengageddateEt
    String classDescription
    String category
    String reportedby
    String reportedbyName
    String reportedbyHierarchy
    Date actualcontactdate
    Date actualcontactdateEt
    Date actualfinish
    Date actualfinishEt
    Date actualstart
    Date actualstartEt
    Date affecteddate
    Date affecteddateEt
    String affectedemail
    String affectedphone
    String baaccountablegroup
    String accountablegroupName
    String accountablegroupManagerName
    String accountablegroupManagerHier
    String baaccountablepersonid
    String accountablepersonName
    String baaffectedhier
    String baaffectednbid
    Integer babusinessimpact
    Integer bacausedby
    String bachangeid
    Date bacloseddate
    Date bacloseddateEt
    Integer baimpact
    String baimproject
    String baperegrineincidentnum
    String bapmhumanerrorcategory
    String bapmhumanerrorcontributeoutage
    Integer bapminternalpriority
    Integer baprbcandidate
    String baproblemcause
    String bareoccurenceflag
    String bareportednbid
    String baserialnum
    String basirid
    Date batriageinccommdate
    Date batriageinccommdateEt
    Date batriageogengagedate
    Date batriageogengagedateEt
    Integer baurgency
    String classificationid
    String commodity
    Date creationdate
    Date creationdateEt
    String description
    String externalsystem
    String globalticketclass
    String globalticketid
    Integer isglobal
    String origrecordclass
    String origrecordid
    String ownergroup
    Date reportdate
    Date reportdateEt
    String reportedemail
    String reportedphone
    Integer reportedpriority
    Integer selfservsolaccess
    String solution
    String status
    Date targetcontactdate
    Date targetcontactdateEt
    Date targetfinish
    Date targetfinishEt
    Date targetstart
    Date targetstartEt
    //String ticketid
    String bacreatedbyhier
    String baownerhier
    Date changedate
    Date changedateEt
    String url
    String resolutionDesc
    String vendorDispatchumber
    String vendorWonum
    String baaitnumber
    String balobhierarchy
    String baaitnumberDirect
    String balobhierarchyDirect
    String createdby
    String createdbyNbid
    String createdbyName
    Date woChangedate
    Date woChangedateEt
    Integer aitrelRowstamp
    Integer aitRowstamp
    Integer aitdirRowstamp
    String description_Ld_1k
    String symptom_Ld_1k
    Date aitdirBalastupdate
    Date aitBalastupdate
    Date aitrelBalastupdate
    Date resolutionLdBalastupdate
    Date descriptionLdBalastupdate
    Date symptomLdBalastupdate

    static constraints = {
        /*affectedperson(size: 0..62)
        baagenttype(size: 0..64)
        bacomputername(size: 0..25)
        baimappassigngroup(size: 0..150)
        baimappname(size: 0..25)
        baimerrorcode(size: 0..10)
        baimjobname(size: 0..64)
        baimlob(size: 0..150)
        baimschedulemaster(size: 0..15)
        baimstepnumber(size: 0..10)
        baimsupporthier(size: 0..50)
        baimsupporthiercode(size: 0..10)
        baimsystemid(size: 0..64)
        banodealias(size: 0..64)
        barestoralgroup(size: 0..8)
        barestoredbyemail(size: 0..100)
        barestoredbyname(size: 0..62)
        barestoredbynbid(size: 0..30)
        barestoredpersonhier(size: 0..25)
        batriageengageddate()
        batriageengageddateEt()
        classDescription(size: 0..250)
        category(size: 0..192)
        reportedby(size: 0..62)
        reportedbyName(size: 0..62)
        reportedbyHierarchy(size: 0..25)
        actualcontactdate()
        actualcontactdateEt()
        actualfinish()
        actualfinishEt()
        actualstart()
        actualstartEt()
        affecteddate()
        affecteddateEt()
        affectedemail(size: 0..100)
        affectedphone(size: 0..20)
        baaccountablegroup(size: 0..8)
        accountablegroupName(size: 0..100)
        accountablegroupManagerName(size: 0..62)
        accountablegroupManagerHier(size: 0..25)
        baaccountablepersonid(size: 0..30)
        accountablepersonName(size: 0..62)
        baaffectedhier(size: 0..25)
        baaffectednbid(size: 0..30)
        babusinessimpact(nullable: true, max: 2147483647)
        bacausedby(nullable: true, max: 2147483647)
        bachangeid(size: 0..25)
        bacloseddate()
        bacloseddateEt()
        baimpact(nullable: true, max: 2147483647)
        baimproject(size: 0..40)
        baperegrineincidentnum(size: 0..20)
        bapmhumanerrorcategory(size: 0..40)
        bapmhumanerrorcontributeoutage(size: 0..11)
        bapminternalpriority(nullable: true, max: 2147483647)
        baprbcandidate(nullable: true, max: 2147483647)
        baproblemcause(size: 0..50)
        bareoccurenceflag(size: 0..11)
        bareportednbid(size: 0..30)
        baserialnum(size: 0..25)
        basirid(size: 0..20)
        batriageinccommdate()
        batriageinccommdateEt()
        batriageogengagedate()
        batriageogengagedateEt()
        baurgency(nullable: true, max: 2147483647)
        classificationid(size: 0..192)
        commodity(size: 0..8)
        creationdate()
        creationdateEt()
        description(size: 0..100)
        externalsystem(size: 0..512)
        globalticketclass(size: 0..16)
        globalticketid(size: 0..10)
        isglobal(nullable: true, max: 2147483647)
        origrecordclass(size: 0..16)
        origrecordid(size: 0..10)
        ownergroup(size: 0..8)
        reportdate()
        reportdateEt()
        reportedemail(size: 0..100)
        reportedphone(size: 0..20)
        reportedpriority(nullable: true, max: 2147483647)
        selfservsolaccess(nullable: true, max: 2147483647)
        solution(size: 0..8)
        status(size: 0..10)
        targetcontactdate()
        targetcontactdateEt()
        targetfinish()
        targetfinishEt()
        targetstart()
        targetstartEt()
        //ticketid(size: 0..10)
        bacreatedbyhier(size: 0..25)
        baownerhier(size: 0..25)
        changedate()
        changedateEt()
        url(size: 0..1024)
        resolutionDesc(size: 0..1000)
        vendorDispatchumber(size: 0..15)
        vendorWonum(size: 0..10)
        baaitnumber(size: 0..254)
        balobhierarchy(size: 0..254)
        baaitnumberDirect(size: 0..254)
        balobhierarchyDirect(size: 0..254)
        createdby(size: 0..30)
        createdbyNbid(size: 0..30)
        createdbyName(size: 0..62)
        woChangedate()
        woChangedateEt()
        aitrelRowstamp(nullable: true, max: 2147483647)
        aitRowstamp(nullable: true, max: 2147483647)
        aitdirRowstamp(nullable: true, max: 2147483647)
        description_Ld_1k(size: 0..1000)
        symptom_Ld_1k(size: 0..1000)
        aitdirBalastupdate()
        aitBalastupdate()
        aitrelBalastupdate()
        resolutionLdBalastupdate()
        descriptionLdBalastupdate()
        symptomLdBalastupdate()*/
    }
    String toString() {
        return "${ticketid}" 
    }
}
