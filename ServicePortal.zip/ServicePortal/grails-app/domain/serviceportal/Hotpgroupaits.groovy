package serviceportal

class Hotpgroupaits {
    static mapping = {
         table name:'hotpgroupaits', schema: "hotpdb"
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'id'
         hotpgroupIdHotpgroups column:'hotpgroup_id'
    }
    
    Integer aitId
    Date createdtime
    Date modifiedtime
    Float availabilityGoal
    // Relation
    Hotpgroups hotpgroupIdHotpgroups

    static constraints = {
        aitId(nullable: true, max: 2147483647)
        createdtime(nullable: true)
        modifiedtime(nullable: true)
        availabilityGoal(nullable: true)
        hotpgroupIdHotpgroups()
    }
    String toString() {
        return "${id}" 
    }
}
