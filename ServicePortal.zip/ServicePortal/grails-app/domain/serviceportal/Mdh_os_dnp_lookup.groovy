package serviceportal

class Mdh_os_dnp_lookup {

	
	static mapping = {
		table name:'mdh_os_dnp_lookup', schema: 'extdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	

	String Compsys_Osname
	Integer compsys_is_virtual
	Integer hostcount
	Integer earc_id
	String earc_productname

	
    static constraints = {

    }
}
