package serviceportal

class MxoPmProblemActivities {
    static mapping = {
         table name: 'mxo_pm_problem_activities', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'wonum'
    }
    String id
    String description
    String location
    String cinum
    String status
    Integer wosequence
    String bataskcategory
    Integer baprobprioriy
    String baprobrisk
    Integer barootcause
    Integer bachangerelated
    String bapmtask
    Date bastatusduedate
    Date baresolutionduedate
    Date targcompdate
    Date actfinish
    Date reportdate
    Date actstart
    Date balastupdate
    String origrecordid
    String origrecordclass
    String longdescription

    static constraints = {
        //wonum(size: 0..10)
        description(size: 0..100)
        location(size: 0..17)
        cinum(size: 0..150)
        status(size: 0..16)
        wosequence(nullable: true, max: 2147483647)
        bataskcategory(size: 0..25)
        baprobprioriy(nullable: true, max: 2147483647)
        baprobrisk(size: 0..10)
        barootcause(nullable: true, max: 2147483647)
        bachangerelated(nullable: true, max: 2147483647)
        bapmtask(size: 0..10)
        bastatusduedate(nullable: true)
        baresolutionduedate(nullable: true)
        targcompdate(nullable: true)
        actfinish(nullable: true)
        reportdate(nullable: true)
        actstart(nullable: true)
        balastupdate(nullable: true)
        origrecordid(size: 0..10)
        origrecordclass(size: 0..16)
        longdescription()
    }
    String toString() {
        return "${wonum}" 
    }
}
