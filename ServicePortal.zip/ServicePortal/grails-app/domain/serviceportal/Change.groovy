package serviceportal

import java.util.Date;

class Change {

    static mapping = {
		table name: 'mxo_ch_changes', schema: 'extdb'
		version false
		id column:'wonum'
		reportedbyMgr3dothier column: 'reportedby_mgr_3dothier'
		activities lazy: false
		cis lazy: false
    }
	
	static hasMany = [activities:ChangeActivity, cis: ChangeCI]
	String id
	Date actfinish
    Date actfinishEt
    Date actstart
    Date actstartEt
    String bachangecat
    String bachangetype
    Integer bachgep
    Integer bachgfastrk
    String bachgknownimpact
    Integer bachgperscore
    String bachgproject
    String bachgproject1id
    String bachgproject2id
    Integer bachgq1
    Integer bachgq2
    Integer bachgq3
    Integer bachgq4
    String bacicollisionView
    Double baclassscore
    Double baclassteamscore
    Integer baeventflg
    Date bafirstproductionimpact
    Date bafirstproductionimpactEt
    Integer baglobalregflg
    Integer baisciconflict
    Integer baiscwconflict
    Integer baismissingwindow
    Integer bamaxaitscore
    Integer bamaxtechscore
    Integer bamisccheckbox3
    Integer bamisccheckbox7
    Integer bamisccheckbox10
    Integer baprodflg
    String barequestorgroupid
    String barfcbackoutplan
    String barfctested
    Integer basigjobplanflg
    Double bateamscore
    String bauserassignedimpact
    String bauserassignedrisk
    Date changedate
    Date changedateEt
    String description
    String jpnum
    String justifypriority
    String phone
    String pmchgimpdesc
    String pmchgprogress
    Date reportdate
    Date reportdateEt
    String reportedby
    Date schedstart
    Date schedstartEt
    String status
    Date targcompdate
    Date targcompdateEt
    Date targstartdate
    Date targstartdateEt
    //String wonum
    String jpDescription
    String jpLongdescription
    String reportedbyDisplayname
    String approvedbyDisplayname
    String approvedbyHierarchy
    String requestorgroupDesc
    String requestorgroupHierarchy
    String requestorgroupManager
    String reportedbyPrimaryemailaddress
    String changeRecordLink
    String ldtext
    String descLongdescFtlink
    Integer cabApprovalId
    String cabId
    String reportedbyMgr3dothier
    String reportedbyMgrName
    String approvingCabarray
    Integer jpRowstamp
    Integer jpldRowstamp
    Integer ldRowstamp
    Integer cabappRowstamp
    Date cabarrayChangedate
    Date cabarrayChangedateEt
    String reportedbyHierarchy
	
}
