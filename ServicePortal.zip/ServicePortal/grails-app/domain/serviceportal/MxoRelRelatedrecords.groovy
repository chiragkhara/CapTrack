package serviceportal

class MxoRelRelatedrecords {
    static mapping = {
         table name: 'mxo_rel_relatedrecords' , schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'rowstamp'
		 classType column: 'class'
    }
    String recordkey
    String classType
    String relatedreckey
    String relatedrecclass
    String relatetype
    Integer relatedrecordid
    Date balastupdate

    static constraints = {
        recordkey(size: 0..10)
        classType(size: 0..16)
        relatedreckey(size: 0..10)
        relatedrecclass(size: 0..16)
        relatetype(size: 0..18)
        relatedrecordid(nullable: true, max: 2147483647)
        balastupdate()
    }
    String toString() {
        return "${recordkey}" 
    }
}
