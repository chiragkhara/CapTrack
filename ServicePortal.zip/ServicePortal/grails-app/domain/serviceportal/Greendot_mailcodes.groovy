package serviceportal

class Greendot_mailcodes {
	
	static mapping = {
		table name: 'greendot_mailcodes', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	
	String mailcode
	
    static constraints = {
		mailcode(size: 0..13,unique:true,blank:false)
    }
}
