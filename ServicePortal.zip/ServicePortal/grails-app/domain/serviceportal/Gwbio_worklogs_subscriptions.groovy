package serviceportal

class Gwbio_worklogs_subscriptions {

	static mapping = {
		table name:'gwbio_worklogs_subscriptions', schema: 'hotpdb'
		version false
		id column:'id'
   }
	
	
	String email
	Integer ait
	String stdid
	
    static constraints = {
		ait(size: 0..11)
		email(size: 0..128)
		stdid(size: 0..7)
    }
}
