package serviceportal

class Application {
    static mapping = {
         table name: 'ait_dq_vws_app', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'APP_ID'
    }
	
    //Integer appId
    String appFullName
    String appShortName
    String appDesc
    String ccc
    String tenDotHierarchy
    String mgmtContactFname
    String mgmtContactLname
    String mgmtContactNetid
    String appMgrFname
    String appMgrLname
    String appMgrNetid
    String appStatusFlag
    Date appStatusDevDate
    Date appStatusProdDate
    Date appStatusSunsetDate
    Date appStatusDecommDate
    Integer lobFacingFlag
    String internalFlag
    String geoUserLocn
    

    static constraints = {
        //appId(nullable: true, max: 2147483647)
        appFullName(size: 0..80)
        appShortName(size: 0..50)
        appDesc(size: 0..255)
        ccc(size: 0..12)
        tenDotHierarchy(size: 0..10)
        mgmtContactFname(size: 0..30)
        mgmtContactLname(size: 0..30)
        mgmtContactNetid(size: 0..30)
        appMgrFname(size: 0..30)
        appMgrLname(size: 0..30)
        appMgrNetid(size: 0..50)
        appStatusFlag(size: 0..50)
        appStatusDevDate(nullable: true)
        appStatusProdDate(nullable: true)
        appStatusSunsetDate(nullable: true)
        appStatusDecommDate(nullable: true)
        lobFacingFlag(nullable: true, max: 2147483647)
        internalFlag(size: 0..65)
        geoUserLocn(size: 0..65)
       
    }
    String toString() {
        return "${appId}" 
    }
}
