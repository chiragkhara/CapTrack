package serviceportal

class Backupanalysis_feedback {

	static mapping = {
		table name:'backupanalysis_feedback', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }

    String comment
	String backupid
	String submitter
	String hostname
	String policyname
	String status
	String retentioncode
	
    static constraints = {
		backupid size: 0..500
		comment size: 0..5000, nullable: true
		hostname size: 0..255, nullable: false, blank:false
		policyname size: 0..255
		retentioncode size: 0..255, nullable: true
		status nullable: true
    }
}
