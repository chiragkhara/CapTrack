package serviceportal
class MxoPmProblems {
    static mapping = {
         table name: 'mxo_pm_problems', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'ticketid'
		 affected4dotHierarchy column: 'affected_4dot_hierarchy'
    }
	String id
    String accountablepersonDisplayname
    String accountablepersonHierarchy
    Date actualfinish
    Date actualfinishEt
    Date actualstart
    Date actualstartEt
    String affected4dotHierarchy
    Date affecteddate
    Date affecteddateEt
    String affectedemail
    String affectedpersonDisplayname
    String affectedpersonNbid
    String affectedphone
    Double baactualdurationdur
    String baaffectedhier
    String baaffectednbid
    Integer babusinessimpact
    Double bacalculateddurationdur
    Integer bacausedby
    String bacertifiedbyemail
    String bacertifiedbyname
    String bacertifiedbynbid
    String bachangeid
    Double bacopqemhl
    Double bacopqerl
    Double bacostofpoorqualitydollar
    Double badollarsimpacted
    Date bafollowupdate
    Date bafollowupdateEt
    String bahowid
    String bamonitoringinplaceflag
    String bamonitoringtool
    Double banumtradfinadvisimpacted
    String baotherareas
    String bapcausaleventoffailure
    String bapcauseoffailure
    String bapcompoundingissue
    Double bapcopqfcitotalaffusersphl
    Double bapcopqfcitotalamountperaml
    Double bapcopqfcitotalamountperfai
    Double bapcopqfcitotalamountperfci
    Double bapcopqfcitotalamountperlso
    Double bapcopqfcitotalamountperphl
    Double bapcopqtihl
    String bapmhumanerrorcategory
    String bapmhumanerrorcontributeoutage
    Integer bapminternalpriority
    String bapmprimarylob
    String bapmvendorrole
    String bapprimaryrootcause
    String bapprsummarytext
    Integer bapreventative
    String bapreventativeactionflag
    String bapreventativestepstext
    String baprobinvestigate
    String baprobinvestigatedesc
    String baproblemresolution
    Date baproblemresolutiondate
    String baprootcausependingreason
    String bapsecondaryrootcause
    String bapvendorrelated
    String bareoccurenceflag
    String bareportednbid
    Date barootcausedocumenteddate
    Date barootcausedocumenteddateEt
    String basirid
    Double batotalimpactatms
    Double batotalimpactbnkcntrs
    Double batotalimpactcchda
    Double batotalimpactcreb
    Double batotalimpacttrans
    Double batotalimpactusers
    String batroublelocation
    String bawhoid
    String baworkaroundsufficientflag
    Date changedate
    Date changedateEt
    String cinum
    String commodity
    Date creationdate
    Date creationdateEt
    String description
    String descriptionLongdescription
    String externalsystem
    Integer isglobal
    Integer isknownerror
    String origrecordid
    String pprActivityid
    Date reportdate
    Date reportdateEt
    String reportedbyDisplayname
    String reportedemail
    String reportedphone
    Integer reportedpriority
    Integer rowstamp
    Integer selfservsolaccess
    String solution
    String status
    //String ticketid
    String vendor
    String workaround
    Date balastupdate
    String baaccountablegroup
    String accountablegroupName
    String baaccountablepersonid
    String bareviewedbyname
    Integer bapprcomplete

    static constraints = {
        accountablepersonDisplayname(size: 0..62)
        accountablepersonHierarchy(size: 0..25)
        actualfinish(nullable: true)
        actualfinishEt(nullable: true)
        actualstart(nullable: true)
        actualstartEt(nullable: true)
        affected4dotHierarchy(size: 0..25)
        affecteddate(nullable: true)
        affecteddateEt(nullable: true)
        affectedemail(size: 0..100)
        affectedpersonDisplayname(size: 0..62)
        affectedpersonNbid(size: 0..30)
        affectedphone(size: 0..20)
        baactualdurationdur(nullable: true)
        baaffectedhier(size: 0..25)
        baaffectednbid(size: 0..30)
        babusinessimpact(nullable: true, max: 2147483647)
        bacalculateddurationdur(nullable: true)
        bacausedby(nullable: true, max: 2147483647)
        bacertifiedbyemail(size: 0..100)
        bacertifiedbyname(size: 0..62)
        bacertifiedbynbid(size: 0..30)
        bachangeid(size: 0..25)
        bacopqemhl(nullable: true)
        bacopqerl(nullable: true)
        bacostofpoorqualitydollar(nullable: true)
        badollarsimpacted(nullable: true)
        bafollowupdate(nullable: true)
        bafollowupdateEt(nullable: true)
        bahowid(size: 0..150)
        bamonitoringinplaceflag(size: 0..11)
        bamonitoringtool(size: 0..150)
        banumtradfinadvisimpacted(nullable: true)
        baotherareas(size: 0..150)
        bapcausaleventoffailure(size: 0..50)
        bapcauseoffailure(size: 0..50)
        bapcompoundingissue(size: 0..50)
        bapcopqfcitotalaffusersphl(nullable: true)
        bapcopqfcitotalamountperaml(nullable: true)
        bapcopqfcitotalamountperfai(nullable: true)
        bapcopqfcitotalamountperfci(nullable: true)
        bapcopqfcitotalamountperlso(nullable: true)
        bapcopqfcitotalamountperphl(nullable: true)
        bapcopqtihl(nullable: true)
        bapmhumanerrorcategory(size: 0..40)
        bapmhumanerrorcontributeoutage(size: 0..11)
        bapminternalpriority(nullable: true, max: 2147483647)
        bapmprimarylob(size: 0..15)
        bapmvendorrole(size: 0..30)
        bapprimaryrootcause(size: 0..50)
        bapprsummarytext(size: 0..150)
        bapreventative(nullable: true, max: 2147483647)
        bapreventativeactionflag(size: 0..11)
        bapreventativestepstext()
        baprobinvestigate(size: 0..12)
        baprobinvestigatedesc(size: 0..256)
        baproblemresolution()
        baproblemresolutiondate(nullable: true)
        baprootcausependingreason(size: 0..50)
        bapsecondaryrootcause(size: 0..50)
        bapvendorrelated(size: 0..50)
        bareoccurenceflag(size: 0..11)
        bareportednbid(size: 0..30)
        barootcausedocumenteddate(nullable: true)
        barootcausedocumenteddateEt(nullable: true)
        basirid(size: 0..20)
        batotalimpactatms(nullable: true)
        batotalimpactbnkcntrs(nullable: true)
        batotalimpactcchda(nullable: true)
        batotalimpactcreb(nullable: true)
        batotalimpacttrans(nullable: true)
        batotalimpactusers(nullable: true)
        batroublelocation(size: 0..17)
        bawhoid(size: 0..150)
        baworkaroundsufficientflag(size: 0..12)
        changedate(nullable: true)
        changedateEt(nullable: true)
        cinum(size: 0..150)
        commodity(size: 0..8)
        creationdate(nullable: true)
        creationdateEt(nullable: true)
        description(size: 0..100)
        descriptionLongdescription(size: 0..30000)
        externalsystem(size: 0..512)
        isglobal(nullable: true, max: 2147483647)
        isknownerror(nullable: true, max: 2147483647)
        origrecordid(size: 0..10)
        pprActivityid(size: 0..10)
        reportdate(nullable: true)
        reportdateEt(nullable: true)
        reportedbyDisplayname(size: 0..62)
        reportedemail(size: 0..100)
        reportedphone(size: 0..20)
        reportedpriority(nullable: true, max: 2147483647)
        rowstamp(nullable: true, max: 2147483647)
        selfservsolaccess(nullable: true, max: 2147483647)
        solution(size: 0..8)
        status(size: 0..10)
        //ticketid(size: 0..10)
        vendor(size: 0..20)
        workaround(size: 0..30000)
        balastupdate(nullable: true)
        baaccountablegroup(size: 0..8)
        accountablegroupName(size: 0..100)
        baaccountablepersonid(size: 0..30)
        bareviewedbyname(size: 0..62)
        bapprcomplete(nullable: true, max: 2147483647)
    }
    String toString() {
        return "${id}" 
    }
}
