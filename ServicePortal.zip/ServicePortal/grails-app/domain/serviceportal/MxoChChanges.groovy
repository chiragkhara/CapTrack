package serviceportal

class MxoChChanges {
    	
	static mapping = {
		 table name: 'mxo_ch_changes', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'wonum'
		 reportedbyMgr3dothier column: 'reportedby_mgr_3dothier'

    }
	
	static hasMany = [activities:ChangeActivity, cis: ChangeCI]
	
	String id
    Date actfinish
    Date actfinishEt
    Date actstart
    Date actstartEt
    String bachangecat
    String bachangetype
    Integer bachgep
    Integer bachgfastrk
    String bachgknownimpact
    Integer bachgperscore
    String bachgproject
    String bachgproject1id
    String bachgproject2id
    Integer bachgq1
    Integer bachgq2
    Integer bachgq3
    Integer bachgq4
    String bacicollisionView
    Double baclassscore
    Double baclassteamscore
    Integer baeventflg
    Date bafirstproductionimpact
    Date bafirstproductionimpactEt
    Integer baglobalregflg
    Integer baisciconflict
    Integer baiscwconflict
    Integer baismissingwindow
    Integer bamaxaitscore
    Integer bamaxtechscore
    Integer bamisccheckbox3
    Integer bamisccheckbox7
    Integer bamisccheckbox10
    Integer baprodflg
    String barequestorgroupid
    String barfcbackoutplan
    String barfctested
    Integer basigjobplanflg
    Double bateamscore
    String bauserassignedimpact
    String bauserassignedrisk
    Date changedate
    Date changedateEt
    String description
    String jpnum
    String justifypriority
    String phone
    String pmchgimpdesc
    String pmchgprogress
    Date reportdate
    Date reportdateEt
    String reportedby
    Date schedstart
    Date schedstartEt
    String status
    Date targcompdate
    Date targcompdateEt
    Date targstartdate
    Date targstartdateEt
    //String wonum
    String jpDescription
    String jpLongdescription
    String reportedbyDisplayname
    String approvedbyDisplayname
    String approvedbyHierarchy
    String requestorgroupDesc
    String requestorgroupHierarchy
    String requestorgroupManager
    String reportedbyPrimaryemailaddress
    String changeRecordLink
    String ldtext
    String descLongdescFtlink
    Integer cabApprovalId
    String cabId
    String reportedbyMgr3dothier
    String reportedbyMgrName
    String approvingCabarray
    Integer jpRowstamp
    Integer jpldRowstamp
    Integer ldRowstamp
    Integer cabappRowstamp
    Date cabarrayChangedate
    Date cabarrayChangedateEt
    String reportedbyHierarchy

    static constraints = {
        actfinish()
        actfinishEt()
        actstart()
        actstartEt()
        bachangecat(size: 0..50)
        bachangetype(size: 0..50)
        bachgep(nullable: true, max: 2147483647)
        bachgfastrk(nullable: true, max: 2147483647)
        bachgknownimpact(size: 0..2)
        bachgperscore(nullable: true, max: 2147483647)
        bachgproject(size: 0..25)
        bachgproject1id(size: 0..25)
        bachgproject2id(size: 0..25)
        bachgq1(nullable: true, max: 2147483647)
        bachgq2(nullable: true, max: 2147483647)
        bachgq3(nullable: true, max: 2147483647)
        bachgq4(nullable: true, max: 2147483647)
        bacicollisionView(size: 0..5)
        baclassscore(nullable: true)
        baclassteamscore(nullable: true)
        baeventflg(nullable: true, max: 2147483647)
        bafirstproductionimpact()
        bafirstproductionimpactEt()
        baglobalregflg(nullable: true, max: 2147483647)
        baisciconflict(nullable: true, max: 2147483647)
        baiscwconflict(nullable: true, max: 2147483647)
        baismissingwindow(nullable: true, max: 2147483647)
        bamaxaitscore(nullable: true, max: 2147483647)
        bamaxtechscore(nullable: true, max: 2147483647)
        bamisccheckbox3(nullable: true, max: 2147483647)
        bamisccheckbox7(nullable: true, max: 2147483647)
        bamisccheckbox10(nullable: true, max: 2147483647)
        baprodflg(nullable: true, max: 2147483647)
        barequestorgroupid(size: 0..8)
        barfcbackoutplan(size: 0..3)
        barfctested(size: 0..3)
        basigjobplanflg(nullable: true, max: 2147483647)
        bateamscore(nullable: true)
        bauserassignedimpact(size: 0..10)
        bauserassignedrisk(size: 0..10)
        changedate()
        changedateEt()
        description(size: 0..100)
        jpnum(size: 0..10)
        justifypriority(size: 0..50)
        phone(size: 0..20)
        pmchgimpdesc(size: 0..250)
        pmchgprogress(size: 0..192)
        reportdate()
        reportdateEt()
        reportedby(size: 0..62)
        schedstart()
        schedstartEt()
        status(size: 0..16)
        targcompdate()
        targcompdateEt()
        targstartdate()
        targstartdateEt()
        //wonum(size: 0..10)
        jpDescription(size: 0..100)
        jpLongdescription(size: 0..30000)
        reportedbyDisplayname(size: 0..62)
        approvedbyDisplayname(size: 0..62)
        approvedbyHierarchy(size: 0..25)
        requestorgroupDesc(size: 0..100)
        requestorgroupHierarchy(size: 0..25)
        requestorgroupManager(size: 0..62)
        reportedbyPrimaryemailaddress(size: 0..100)
        changeRecordLink(size: 0..1024)
        ldtext(size: 0..30000)
        descLongdescFtlink(size: 0..1000)
        cabApprovalId(nullable: true, max: 2147483647)
        //cabId(size: 0..8)
        reportedbyMgr3dothier(size: 0..100)
        reportedbyMgrName(size: 0..100)
        approvingCabarray(size: 0..1000)
        jpRowstamp(nullable: true, max: 2147483647)
        jpldRowstamp(nullable: true, max: 2147483647)
        ldRowstamp(nullable: true, max: 2147483647)
        cabappRowstamp(nullable: true, max: 2147483647)
        cabarrayChangedate()
        cabarrayChangedateEt()
        reportedbyHierarchy(size: 0..25)
    }
    String toString() {
        return "${wonum}" 
    }
}
