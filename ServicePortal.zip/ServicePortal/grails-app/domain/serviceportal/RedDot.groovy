package serviceportal

class RedDot {

	
	static mapping = {
		table name:'gwbio_reddot', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'pm', generator: 'assigned', type: 'string'
   }
	
	String id
	String status
	Integer risklevel
	Date resolutiondate
	String standardid
	Boolean archive
	Integer idtrigger
	String coordinator
	
    static constraints = {
		status(size: 0..5000,nullable: true)
		risklevel(range:0..2,nullable: true)
		resolutiondate(nullable: true)
		idtrigger(nullable: true)
		coordinator(nullable: true)
    }
}
