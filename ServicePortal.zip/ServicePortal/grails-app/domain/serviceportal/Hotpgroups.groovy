package serviceportal

class Hotpgroups {
    static mapping = {
         table name:'hotpgroups', schema: "hotpdb"
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'id'
    }

    String name
    String description
    Date createdtime
    Date modifiedtime
    Float availabilityGoal
    String reportingNeed
    String inventoryRequired

    static constraints = {
        name(size: 0..100)
        description(size: 0..255)
        createdtime(nullable: true)
        modifiedtime(nullable: true)
        availabilityGoal(nullable: true)
        reportingNeed(size: 0..5)
        inventoryRequired(size: 0..3)
    }
    String toString() {
        return "${id}" 
    }
}
