package serviceportal

class IaDynamicReport_processexec {

	static mapping = {
		table name: 'ia_dynamicreport_processexec', schema: 'hotpdb'
		version false
		id column:'id'
		processString column : 'processString'
	}
	
	String name
	String processString
	
	static hasMany = [authorisedUsers:IaDynamicReport_processexec_authorised]
	
    static constraints = {
    }
}
