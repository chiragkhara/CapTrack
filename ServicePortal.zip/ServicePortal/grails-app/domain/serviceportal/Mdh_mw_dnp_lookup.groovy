package serviceportal

class Mdh_mw_dnp_lookup {
	
	static mapping = {
		table name:'mdh_mw_dnp_lookup', schema: 'extdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	

	String mwinstance_product_name
	String mwinstance_product_version
	Integer instancecount
	Integer earc_id
	String earc_productname

	
    static constraints = {

    }
}
