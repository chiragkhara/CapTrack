package serviceportal
class MxoPmProblemActivityAssignees {
    static mapping = {
         table name: 'mxo_pm_problem_activity_assignees', schema: 'extdb'
         // version is set to false, because this isn't available by default for legacy databases
         version false
         id column:'rowstamp'
    }
    String name
    String extname
    String banbid
    String email
    String extemail
    String phone
    String extphone
    String woclass
    String wonum
    Integer externalyorn
    String wostatus
    String wolocation
    String woassetnum
    String wocinum
    String taskassigneetype
    Integer taskassigneesequence
    Integer baptaskassigneeid
    //Integer rowstamp
    Date balastupdate

    static constraints = {
        name(size: 0..62)
        extname(size: 0..62)
        banbid(size: 0..30)
        email(size: 0..100)
        extemail(size: 0..100)
        phone(size: 0..20)
        extphone(size: 0..20)
        woclass(size: 0..16)
        wonum(size: 0..10)
        externalyorn(nullable: true, max: 2147483647)
        wostatus(size: 0..16)
        wolocation(size: 0..17)
        woassetnum(size: 0..12)
        wocinum(size: 0..150)
        taskassigneetype(size: 0..12)
        taskassigneesequence(nullable: true, max: 2147483647)
        baptaskassigneeid(nullable: true, max: 2147483647)
        //rowstamp(nullable: true, max: 2147483647)
        balastupdate(nullable: true)
    }
    String toString() {
        return "${rowstamp}" 
    }
}
