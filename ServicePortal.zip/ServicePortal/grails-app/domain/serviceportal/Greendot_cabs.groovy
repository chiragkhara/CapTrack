package serviceportal

class Greendot_cabs {
	
	static mapping = {
		table name: 'greendot_cabs', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	
	String cabPGP
	
    static constraints = {
		cabPGP(size: 0..8,unique:true,blank:false)
    }
}
