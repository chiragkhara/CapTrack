package serviceportal

class Greendot_hierarchies {
	
	static mapping = {
		table name: 'greendot_hierachies', schema: 'hotpdb'
		// version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
   }
	
	String FOURDOT
	
    static constraints = {
		FOURDOT(size: 0..7,unique:true,blank:false)
    }
}
