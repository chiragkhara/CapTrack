package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class Gwbio_servermapsController {

	def dataSource
	
    def index() { }
	
	def getHost(){
		def returnMap
		if(params?.hostname){
			def db = new Sql(dataSource)
			def queryString = "Select hostname,`key`,value FROM hotpdb.gwbio_servermaps where hostname = ? order by `key`"
			def result = db.rows(queryString,[params.hostname])
			render result as JSON
		}else{
			returnMap = [error:'Please supply hostname parameter']
			render returnMap as JSON
		}
	}
	
	def getHostKey(){
		def returnMap
		if(params?.hostname  && params?.key){
			def db = new Sql(dataSource)
			def queryString = "Select hostname,`key`,value FROM hotpdb.gwbio_servermaps where hostname = ? and `key` = ? order by `key`"
			def result = db.rows(queryString,[params.hostname,params.key])
			render result as JSON
		}else{
			returnMap = [error:'Please supply hostname and key parameters']
			render returnMap as JSON
		}
	}
	
	def getAll(){
		def db = new Sql(dataSource)
		def queryString = "Select hostname,`key`,value FROM hotpdb.gwbio_servermaps order by hostname, `key`"
		def result = db.rows(queryString)
		render result as JSON
		
	}
	
	def putHostMap(){
		def returnMap
		if(params?.hostname && params?.key && params?.value){
			def hostname = params.hostname
			def key = params.key
			def value = params.value
			
			def parameterArray = [hostname,key,value,value]

			def db = new Sql(dataSource)
			
			def queryString = """\
			INSERT INTO hotpdb.gwbio_servermaps (hostname,`key`,value) 
			VALUES (?,?,?)
			ON DUPLICATE KEY UPDATE value = ?
			"""
			
			try {
				def insertUpdatesDone = db.executeUpdate(queryString,parameterArray)
				returnMap = [success:true,updates:insertUpdatesDone,query:queryString.replaceAll("\n", "").replaceAll("\t", "")]
			} catch(Exception e){
				returnMap = [errror:e.getMessage(),query:queryString]
			}
			
			render returnMap as JSON
		}else{
			returnMap = [error:'Please supply hostname, key and value parameters']
			render returnMap as JSON
		}
		
		
	}
}
