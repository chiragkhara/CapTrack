package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class Greendot_mailcodesController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [greendot_mailcodesInstanceList: Greendot_mailcodes.list(params), greendot_mailcodesInstanceTotal: Greendot_mailcodes.count()]
    }

    def create() {
        [greendot_mailcodesInstance: new Greendot_mailcodes(params)]
    }

    def save() {
        def greendot_mailcodesInstance = new Greendot_mailcodes(params)
        if (!greendot_mailcodesInstance.save(flush: true)) {
            render(view: "create", model: [greendot_mailcodesInstance: greendot_mailcodesInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), greendot_mailcodesInstance.id])
        redirect(action: "show", id: greendot_mailcodesInstance.id)
    }

    def show() {
        def greendot_mailcodesInstance = Greendot_mailcodes.get(params.id)
        if (!greendot_mailcodesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_mailcodesInstance: greendot_mailcodesInstance]
    }

    def edit() {
        def greendot_mailcodesInstance = Greendot_mailcodes.get(params.id)
        if (!greendot_mailcodesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_mailcodesInstance: greendot_mailcodesInstance]
    }

    def update() {
        def greendot_mailcodesInstance = Greendot_mailcodes.get(params.id)
        if (!greendot_mailcodesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (greendot_mailcodesInstance.version > version) {
                greendot_mailcodesInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes')] as Object[],
                          "Another user has updated this Greendot_mailcodes while you were editing")
                render(view: "edit", model: [greendot_mailcodesInstance: greendot_mailcodesInstance])
                return
            }
        }

        greendot_mailcodesInstance.properties = params

        if (!greendot_mailcodesInstance.save(flush: true)) {
            render(view: "edit", model: [greendot_mailcodesInstance: greendot_mailcodesInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), greendot_mailcodesInstance.id])
        redirect(action: "show", id: greendot_mailcodesInstance.id)
    }

    def delete() {
        def greendot_mailcodesInstance = Greendot_mailcodes.get(params.id)
        if (!greendot_mailcodesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "list")
            return
        }

        try {
            greendot_mailcodesInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'greendot_mailcodes.label', default: 'Greendot_mailcodes'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
