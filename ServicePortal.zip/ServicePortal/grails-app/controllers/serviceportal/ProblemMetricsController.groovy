package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import javax.servlet.http.Cookie

class ProblemMetricsController {

	def dataSource
	
    def index() { }
	
	
	def carServiceArea(){
		
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					Select SERVICEAREA as value
					FROM hotpdb.gwbio_incident_list
					GROUP BY SERVICEAREA
					ORDER BY SERVICEAREA"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def getRedDotTriggers(){
		def db = new Sql(dataSource)
		def queryString = "SELECT id, tiggerStatus FROM hotpdb.gwbio_reddot_trigger_statuses order by id"
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def manualRedDotFind(){
		if(params?.id){
			println params.id
			def db = new Sql(dataSource)
			def PM = params.id
			def queryString = """\
				select mxo_pm_problems.ticketid
				from extdb.mxo_pm_problems
				left join hotpdb.gwbio_reddot on mxo_pm_problems.ticketid = gwbio_reddot.PM
				where mxo_pm_problems.ticketid like '"""+PM+"""%' and gwbio_reddot.PM is null
				order by ticketid
				Limit 10"""
			println queryString
			def result = db.rows(queryString)
			render result as JSON
		}else{
			def error = [:]
			error.put("error", "no PM provided")
			render error as JSON
		}
	}
	
	def getProblemRedDotDetails(){
		if(params?.id){
			def db = new Sql(dataSource)
			def queryString = """\
					select
					  mxo_pm_problems.ticketid,
					  mxo_pm_problems.status Status,
					  mxo_pm_problems.description Description,
					  CASE
						WHEN gwbio_reddot.riskLevel = 1 THEN 'Green'
						WHEN gwbio_reddot.riskLevel = 2 THEN 'Yellow'
						WHEN gwbio_reddot.riskLevel = 3 THEN 'Red'   
						ELSE ''
					  END as `Red Dot Risk Level`,
					  COALESCE(gwbio_reddot.status,'') `RedDot Status`,
					  case 
					    when gwbio_reddot.resolutionDate is null then ''
					    else DATE_FORMAT(`resolutionDate`,'%d/%m/%Y')
					  end as ResolutionDate,
					  gwbio_reddot_trigger_statuses.tiggerStatus `RedDot Trigger`,
					  gwbioreporting_pgp_servicearea.SERVICEAREA as ServiceArea,
					  GROUP_CONCAT(distinct mxo_rel_relatedrecords.recordkey SEPARATOR ', ') as `Related IMs`,
					  gwbio_reddot_status_archive.status `archive status`, 
					  gwbio_reddot_status_archive.standardId `archive submitter`,
					  DATE_FORMAT(gwbio_reddot_status_archive.dt_archive,'%m-%d-%Y') `archive date`
					from extdb.mxo_pm_problems
					left join hotpdb.gwbio_reddot on mxo_pm_problems.ticketid = gwbio_reddot.PM
					left join hotpdb.gwbio_reddot_trigger_statuses on gwbio_reddot.idTrigger = gwbio_reddot_trigger_statuses.id
					left join hotpdb.gwbio_reddot_status_archive on gwbio_reddot.PM = gwbio_reddot_status_archive.PM
					LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP
					LEFT JOIN extdb.mxo_pm_problem_activities ON mxo_pm_problems.ticketid = mxo_pm_problem_activities.origrecordid
					LEFT JOIN extdb.mxo_rel_relatedrecords ON mxo_pm_problems.ticketid  = mxo_rel_relatedrecords.relatedreckey AND mxo_rel_relatedrecords.relatedrecclass = 'PROBLEM'
					where mxo_pm_problems.ticketid = '${params.id}'
					GROUP BY mxo_pm_problems.ticketid,gwbio_reddot_status_archive.id
			"""
			def result = db.rows(queryString)
			render result as JSON
		}
		
	}
	
	def gwbProblemStats(){
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					select  
					  SERVICEAREA as SERVICEAREA, 
					  SUM(CASE WHEN status = 'NEW' THEN 1 ELSE 0 END) as 'NEW',
					  SUM(CASE WHEN status = 'PENDING' THEN 1 ELSE 0 END) as 'PENDING',
					  SUM(CASE WHEN status = 'QUEUED' THEN 1 ELSE 0 END) as 'QUEUED',
					  SUM(CASE WHEN status = 'INPROG' THEN 1 ELSE 0 END) as 'INPROG',
					  SUM(CASE WHEN status = 'PENDCLOSED' THEN 1 ELSE 0 END) as 'PENDCLOSED',
					  count(distinct ticketid) as Total
					FROM (
					  select  gwbioreporting_pgp_servicearea.SERVICEAREA, mxo_pm_problems.status, gwbio_problem_landscape.ticketid
					  FROM hotpdb.gwbio_problem_landscape """

				if(params?.redDot){
					queryString += "INNER JOIN hotpdb.gwbio_reddot on gwbio_problem_landscape.ticketid = gwbio_reddot.pm and gwbio_reddot.archive = 0"
				}
				
				queryString += """
					  INNER JOIN extdb.mxo_pm_problems on gwbio_problem_landscape.ticketid = mxo_pm_problems.ticketid
					  LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP"""
				
				if(params?.closedTickets){
					 queryString +=" WHERE mxo_pm_problems.status IN ('CLOSED','RESOLVED') "
				}else{
					 queryString +=" WHERE mxo_pm_problems.status NOT IN ('CLOSED','RESOLVED') "
				}
			  
				queryString += """GROUP BY gwbio_problem_landscape.ticketid
					) tmp
					GROUP BY SERVICEAREA
					ORDER BY SERVICEAREA
					"""
				
		println queryString
		def result = db.rows(queryString)
		render result as JSON
	}
	
	
		
	
	def gwbProblemDetails(){
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
			select  
				gwbio_problem_landscape.ticketid as PM,
				mxo_pm_problems.description Description,
				CASE
					WHEN gwbio_reddot.riskLevel = 1 THEN 'Green'
					WHEN gwbio_reddot.riskLevel = 2 THEN 'Yellow'
					WHEN gwbio_reddot.riskLevel = 3 THEN 'Red'   
					ELSE ''
				END as `Risk Level`,
				CAST(COALESCE(gwbio_reddot.riskLevel,'') as CHAR) RiskLevel,
				mxo_pm_problems.status Status,
				COALESCE(gwbio_reddot.status,'') `RedDot Status`,
				case 
				    when gwbio_reddot.resolutionDate is null then ''
				    else DATE_FORMAT(`resolutionDate`,'%d/%m/%Y')
				end as ResolutionDate,
				gwbioreporting_pgp_servicearea.SERVICEAREA as ServiceArea, 
				case 
					when gwbio_reddot.pm is not null then 1
					else 0
				end as redDot,
				gwbio_reddot.archive redDot_Archive,
				COALESCE(gwbio_reddot.coordinator,'') coordinator,
				COALESCE(gwbio_reddot_trigger_statuses.tiggerStatus,'') `RedDot Trigger`,
				datediff(now(),mxo_pm_problems.actualstart) as daysOld,
				date_format(mxo_pm_problems.actualstart,'%m-%d-%Y') actualstart,		
				date_format(mxo_pm_problems.actualfinish,'%m-%d-%Y') actualfinish,	
				count(distinct mxo_pm_problem_activities.wonum) as `#Cars`,
			  	mxo_pm_problems.baaccountablegroup as PGP,
				GROUP_CONCAT(distinct im_pgp.SERVICEAREA) as Incident_ServiceAreas,
			  	SUBSTRING_INDEX(GROUP_CONCAT(mxo_im_incidents.ticketid SEPARATOR ','), ',', 5) as Incidents, 
		        mxo_pm_problems.actualstart,
		        mxo_pm_problems.baproblemresolutiondate,
		        mxo_pm_problems.accountablegroup_name
			FROM hotpdb.gwbio_problem_landscape """
		
		if(params?.redDot == null){
			queryString += "LEFT JOIN hotpdb.gwbio_reddot on gwbio_problem_landscape.ticketid = gwbio_reddot.pm"
		}else if(params?.redDot){
			queryString += "JOIN hotpdb.gwbio_reddot on gwbio_problem_landscape.ticketid = gwbio_reddot.pm and gwbio_reddot.archive = 0"
		}
		
			queryString +="""\
			INNER JOIN extdb.mxo_pm_problems on gwbio_problem_landscape.ticketid = mxo_pm_problems.ticketid
			LEFT JOIN extdb.mxo_pm_problem_activities ON mxo_pm_problems.ticketid = mxo_pm_problem_activities.origrecordid
			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP
			LEFT JOIN extdb.mxo_rel_relatedrecords ON gwbio_reddot.pm  = mxo_rel_relatedrecords.relatedreckey AND mxo_rel_relatedrecords.relatedrecclass = 'PROBLEM'
			LEFT JOIN extdb.mxo_im_incidents ON mxo_im_incidents.ticketid = mxo_rel_relatedrecords.recordkey 
			LEFT JOIN hotpdb.gwbio_reddot_trigger_statuses on gwbio_reddot.idTrigger = gwbio_reddot_trigger_statuses.id
			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea im_pgp ON mxo_im_incidents.BAACCOUNTABLEGROUP = im_pgp.PGP"""
			
		if(params?.closedTickets){
			queryString +=" WHERE mxo_pm_problems.status IN ('CLOSED','RESOLVED') "
		}else{
			queryString +=" WHERE mxo_pm_problems.status NOT IN ('CLOSED','RESOLVED') "
		}
			
		
		  if(params.servicearea && params.servicearea.toString().toUpperCase()!="NULL"){
			 queryString += "AND gwbioreporting_pgp_servicearea.SERVICEAREA = '${params.servicearea}'"
		  }else if(params.servicearea && params.servicearea.toString().toUpperCase()=="NULL"){
		  	queryString += "AND gwbioreporting_pgp_servicearea.SERVICEAREA IS NULL"
		  }
		  
		 queryString += " GROUP BY gwbio_problem_landscape.ticketid"
	
		 
		 if(params?.orderBy){
			 queryString += " ORDER BY ${params.orderBy}"
		 }else{
		 	queryString += " ORDER BY gwbio_problem_landscape.ticketid"
		 }
		 
		 println queryString
		 
		 if(params.export){
			def fileName = "IADB_Problems_by_ServiceArea"
			if(params?.closedTickets){
				fileName += "_CLOSED"
			}
			if(params?.redDot){
				fileName += "_REDDOT"
			}
			Cookie cookie = new Cookie("fileDownload","true")
			cookie.maxAge = 10
			cookie.setPath("/")
			response.addCookie(cookie)
			ExportController exporter = new ExportController();
			exporter.export(db.rows(queryString),fileName)
		}else{
			def result = db.rows(queryString)
			render result as JSON
		}
	}
	
	

	
	def serviceAreaStats(){
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
			SELECT 
			  SERVICEAREA,
			  SUM(CASE WHEN status = 'APPR' THEN 1 ELSE 0 END) as 'APPR',
			  SUM(CASE WHEN status = 'INPRG' THEN 1 ELSE 0 END) as 'INPRG',
			  SUM(CASE WHEN status = 'WAPPR' THEN 1 ELSE 0 END) as 'WAPPR',
			  count(distinct wonum) as Total
			FROM
			(
			  	select gwbio_problem_car_list.wonum, gwbio_problem_car_list.status,pgp2.SERVICEAREA
			  	FROM hotpdb.gwbio_problem_list
    			INNER JOIN extdb.mxo_pm_problems on gwbio_problem_list.ticketid = mxo_pm_problems.ticketid
    			INNER JOIN hotpdb.gwbio_problem_car_list ON gwbio_problem_car_list.problem_id = gwbio_problem_list.ticketid
    			INNER JOIN extdb.mxo_pm_problem_activities ON mxo_pm_problem_activities.wonum = gwbio_problem_car_list.wonum
    			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP
    			LEFT JOIN extdb.mxo_pm_problem_activity_assignees ON mxo_pm_problem_activities.wonum = mxo_pm_problem_activity_assignees.wonum AND mxo_pm_problem_activity_assignees.taskassigneetype = 'PRIMARY'
    			Left join extdb.mxo_persongroup_persons on mxo_pm_problem_activity_assignees.banbid = mxo_persongroup_persons.p_nbid AND is_primary_pgp = 'Yes'
    			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea pgp2 ON mxo_persongroup_persons.pgp_num = pgp2.pgp
    			Where gwbio_problem_car_list.status NOT IN ('CLOSE','CAN','COMP')
			  	GROUP BY gwbio_problem_car_list.wonum,pgp2.SERVICEAREA
			) tmp
			GROUP BY SERVICEAREA"""
		
		def result = db.rows(queryString)
		render result as JSON

	}
	
	
	def carsForProblem(){
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
		Select 
			mxo_pm_problem_activities.wonum as `Car #`,
			mxo_pm_problem_activities.status,
			mxo_persongroup_persons.p_displayname as assignee,
			mxo_persongroup_persons.pgp_num as assignee_pgp,
			pgp2.servicearea as assignee_ServiceArea,
			mxo_pm_problem_activities.description,
			mxo_pm_problem_activities.bataskcategory,
			mxo_pm_problem_activities.baprobprioriy,
			/*datediff(mxo_pm_problem_activities.targcompdate,now()) Days_till_resolution,*/
			datediff(mxo_pm_problem_activities.bastatusduedate,now()) Days_till_status_due
		FROM extdb.mxo_pm_problems 
		INNER JOIN extdb.mxo_pm_problem_activities ON mxo_pm_problems.ticketid = mxo_pm_problem_activities.origrecordid
		LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP
		LEFT JOIN extdb.mxo_pm_problem_activity_assignees ON mxo_pm_problem_activities.wonum = mxo_pm_problem_activity_assignees.wonum AND mxo_pm_problem_activity_assignees.taskassigneetype = 'PRIMARY'
		LEFT JOIN extdb.mxo_persongroup_persons on mxo_pm_problem_activity_assignees.banbid = mxo_persongroup_persons.p_nbid AND is_primary_pgp = 'Yes'
		LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea pgp2 ON mxo_persongroup_persons.pgp_num = pgp2.pgp 
		Where mxo_pm_problems.ticketid = '${params.pm}'
		AND mxo_pm_problems.status NOT IN ('CLOSE','CAN','COMP')
		GROUP BY mxo_pm_problem_activities.wonum,gwbioreporting_pgp_servicearea.SERVICEAREA  
		ORDER BY mxo_pm_problem_activities.status, mxo_pm_problem_activities. wonum,pgp2.SERVICEAREA"""
		
		println queryString
		
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def serviceAreaDetails(){
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
			SELECT
				gwbio_problem_car_list.wonum,
				gwbio_incident_list.SERVICEAREA,
				gwbio_problem_list.ticketid as PM,
				gwbio_incident_list.ticketid as Original_Inci,
				gwbio_incident_list.reportedpriority as Inci_Priority,
				gwbio_problem_car_list.status,
				gwbioreporting_pgp_servicearea.servicearea as Problem_ServiceArea,
				mxo_persongroup_persons.p_displayname as assignee,
				mxo_persongroup_persons.pgp_num as assignee_pgp,
				pgp2.servicearea as assignee_ServiceArea,
				mxo_pm_problem_activities.description,
				mxo_pm_problem_activities.longdescription,
				mxo_pm_problem_activities.bataskcategory,
				mxo_pm_problem_activities.wosequence,
				mxo_pm_problem_activities.baprobprioriy,
				datediff(mxo_pm_problem_activities.baresolutionduedate,now()) Days_till_resolution,
				datediff(mxo_pm_problem_activities.bastatusduedate,now()) Days_till_status_due,
				mxo_pm_problem_activities.baresolutionduedate,
				mxo_pm_problem_activities.bastatusduedate
			FROM hotpdb.gwbio_problem_list
			INNER JOIN hotpdb.gwbio_incident_list ON gwbio_problem_list.incident_id = gwbio_incident_list.ticketid
			INNER JOIN extdb.mxo_pm_problems on gwbio_problem_list.ticketid = mxo_pm_problems.ticketid
			INNER JOIN hotpdb.gwbio_problem_car_list ON gwbio_problem_car_list.problem_id = gwbio_problem_list.ticketid
			INNER JOIN extdb.mxo_pm_problem_activities ON mxo_pm_problem_activities.wonum = gwbio_problem_car_list.wonum
			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_pm_problems.baaccountablegroup = gwbioreporting_pgp_servicearea.PGP
			LEFT JOIN extdb.mxo_pm_problem_activity_assignees ON mxo_pm_problem_activities.wonum = mxo_pm_problem_activity_assignees.wonum AND mxo_pm_problem_activity_assignees.taskassigneetype = 'PRIMARY'
			Left join extdb.mxo_persongroup_persons on mxo_pm_problem_activity_assignees.banbid = mxo_persongroup_persons.p_nbid AND is_primary_pgp = 'Yes'
			LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea pgp2 ON mxo_persongroup_persons.pgp_num = pgp2.pgp
			Where gwbio_problem_car_list.status NOT IN ('CLOSE','CAN','COMP') """
		
		  if(params.servicearea && params.servicearea.toString().toUpperCase()!="NULL"){
			 queryString += "AND pgp2.SERVICEAREA = '${params.servicearea}'"
		  }else if(params.servicearea && params.servicearea.toString().toUpperCase()=="NULL"){
		  queryString += "AND pgp2.SERVICEAREA IS NULL"
		  }
		  
		 queryString += " GROUP BY gwbio_problem_car_list.wonum,gwbioreporting_pgp_servicearea.SERVICEAREA  ORDER BY gwbio_problem_car_list.status,gwbio_problem_car_list.wonum,pgp2.SERVICEAREA"
		
		 
		if(params.export){
			def fileName = "IADB_Cars_by_ServiceArea"
			Cookie cookie = new Cookie("fileDownload","true")
			cookie.maxAge = 10
			cookie.setPath("/")
			response.addCookie(cookie)
			ExportController exporter = new ExportController();
			exporter.export(db.rows(queryString),fileName)
		}else{
			def result = db.rows(queryString)
			render result as JSON
		}
		
		
		
	}
	

}
