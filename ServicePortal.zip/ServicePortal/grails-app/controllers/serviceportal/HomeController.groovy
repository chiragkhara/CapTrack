package serviceportal

class HomeController {

    def index() { 
		//redirect(view: "/index", params: [id:params.id])
		
		def urlFwdString = "/?"
		def urlFWD = false
		
		if(params?.id){
			urlFWD = true
			urlFwdString += "id="+params.id
		}
		
		if(params?.tab){
			if(urlFWD){
				urlFwdString += "&"
			}else{
				urlFWD = true
			}
			urlFwdString += "tab="+params.tab
		}
		
		if(urlFWD){
			redirect(uri: urlFwdString)
		}else{
			redirect(uri: "/")
		}
		
		//redirect(uri: "/", params: ['id': params.id])
	}
}
