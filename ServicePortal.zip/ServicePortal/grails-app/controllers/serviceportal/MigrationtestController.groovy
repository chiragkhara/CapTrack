package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class MigrationtestController {
	def dataSource_ReadOnly
	def dataSource_ReadOnly_prod
	def dataSource_ReadOnly_dev
    def index() { 
		
		if(params?.queryString){
			def queryString = params.queryString
			def db_prod_ro = new Sql(dataSource_ReadOnly)
			def db_prod = new Sql(dataSource_ReadOnly_prod)
			def db_dev = new Sql(dataSource_ReadOnly_dev)
			def results = [:]
			
			try{
				results.dev = db_dev.rows(queryString)
			}catch(e){
				results.dev = [error:"true", message :e.message]
			}
			
			try{
				results.prod = db_prod.rows(queryString)
			}catch(e){
				results.prod = [error:"true", message :e.message]
			}
			
			try{
				results.dr = db_prod_ro.rows(queryString)
			}catch(e){
				results.dr = [error:"true", message :e.message]
			}
			
			render results as JSON
		}
		}
}
