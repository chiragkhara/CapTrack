package serviceportal

class XmlCreateController {

    def index() {}
	
	def outPutXML(dbRows){
		def xml = convertSQL(dbRows)
		render(text: xml, contentType: "text/xml", encoding: "UTF-8")
	}
	
	def convertSQL(dbRows){	
		
		String xml10pattern = """[^
			\u0009\r\n
			\u0020-\uD7FF
			\uE000-\uFFFD
			\ud800\udc00-\udbff\udfff]"""
			
		def s_xml=new StringWriter()
		def builder = new groovy.xml.MarkupBuilder(s_xml)
		def outPut = []
			builder.RFC{
				dbRows.each() {
					def row = it
					item(){
						row.each(){ key, value ->
							def legal = value.toString().replaceAll(xml10pattern, "")
							"${key}"("${legal}")
						}
					}
				}
			}
		return s_xml
	}
}
