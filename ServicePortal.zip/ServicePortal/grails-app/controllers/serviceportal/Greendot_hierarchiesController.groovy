package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class Greendot_hierarchiesController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [greendot_hierachiesInstanceList: Greendot_hierarchies.list(params), greendot_hierachiesInstanceTotal: Greendot_hierarchies.count()]
    }

    def create() {
        [greendot_hierachiesInstance: new Greendot_hierarchies(params)]
    }

    def save() {
        def greendot_hierachiesInstance = new Greendot_hierarchies(params)
        if (!greendot_hierachiesInstance.save(flush: true)) {
            render(view: "create", model: [greendot_hierachiesInstance: greendot_hierachiesInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), greendot_hierachiesInstance.id])
        redirect(action: "show", id: greendot_hierachiesInstance.id)
    }

    def show() {
        def greendot_hierachiesInstance = Greendot_hierarchies.get(params.id)
        if (!greendot_hierachiesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_hierachiesInstance: greendot_hierachiesInstance]
    }

    def edit() {
        def greendot_hierachiesInstance = Greendot_hierarchies.get(params.id)
        if (!greendot_hierachiesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_hierachiesInstance: greendot_hierachiesInstance]
    }

    def update() {
        def greendot_hierachiesInstance = Greendot_hierarchies.get(params.id)
        if (!greendot_hierachiesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (greendot_hierachiesInstance.version > version) {
                greendot_hierachiesInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies')] as Object[],
                          "Another user has updated this Greendot_hierachies while you were editing")
                render(view: "edit", model: [greendot_hierachiesInstance: greendot_hierachiesInstance])
                return
            }
        }

        greendot_hierachiesInstance.properties = params

        if (!greendot_hierachiesInstance.save(flush: true)) {
            render(view: "edit", model: [greendot_hierachiesInstance: greendot_hierachiesInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), greendot_hierachiesInstance.id])
        redirect(action: "show", id: greendot_hierachiesInstance.id)
    }

    def delete() {
        def greendot_hierachiesInstance = Greendot_hierarchies.get(params.id)
        if (!greendot_hierachiesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "list")
            return
        }

        try {
            greendot_hierachiesInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'greendot_hierachies.label', default: 'Greendot_hierachies'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
