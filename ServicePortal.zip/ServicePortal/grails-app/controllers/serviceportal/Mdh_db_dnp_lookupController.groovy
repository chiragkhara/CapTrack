package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class Mdh_db_dnp_lookupController {

    def dataSource
	
    def index() { 
		//def db = new Sql(dataSource_ReadOnly)
		//def queryDistinctEARCProducts = "SELECT ProductID, ProductName, FriendlyName, VendorName, classification FROM extdb.earc_db_product_list ORDER BY ProductName"
		
		def allMapped = Mdh_db_dnp_lookup.findAllByEarc_idIsNotNull() as JSON
		def allUnmapped = Mdh_db_dnp_lookup.findAllWhere(earc_id: null)  as JSON
		
		def tableColumns = ['id':'id','dbinstance_product_name':'Product','dbinstance_version_num': 'Version', 'instancecount': 'Number'] as JSON
		def mapColumns =  ['id':'id','dbinstance_product_name':'Product','dbinstance_version_num': 'Version', 'earc_productname': 'EARC Product'] as JSON
		def messageFields = ['Product','Version'] as JSON
		
		render(view:"/mdh_mapping_view/index",model:[allMapped: allMapped, allUnmapped: allUnmapped,tableColumnsMap:tableColumns,messageFields:messageFields,mapColumns:mapColumns,dataType:'Database'])
	}
	
	
	def updateMappingData(){
		def db = new Sql(dataSource)
		
		def insertsQueryString = """\
		INSERT INTO extdb.mdh_db_dnp_lookup (DBINSTANCE_PRODUCT_NAME, DBINSTANCE_VERSION_NUM, instanceCount)
		select 
			mdh_db_inst.DBINSTANCE_PRODUCT_NAME,
			mdh_db_inst.DBINSTANCE_VERSION_NUM,
			count(distinct mdh_db_inst.DBINSTANCE_CMSCIID) as instanceCount
		FROM extdb.mdh_compsys
		INNER JOIN extdb.mdh_app_compsys_rel ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
		INNER JOIN extdb.mdh_ait mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
		INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
		INNER JOIN extdb.mdh_compsys_dbinstance_rel ON mdh_compsys_dbinstance_rel.REL_COMPSYS = mdh_compsys.COMPSYS_CMSCIID
		INNER JOIN extdb.mdh_db_inst ON mdh_compsys_dbinstance_rel.REL_DBINSTANCE = mdh_db_inst.DBINSTANCE_CMSCIID
		LEFT JOIN extdb.mdh_db_dnp_lookup 
			ON mdh_db_inst.DBINSTANCE_PRODUCT_NAME = mdh_db_dnp_lookup.DBINSTANCE_PRODUCT_NAME 
			AND mdh_db_inst.DBINSTANCE_VERSION_NUM = mdh_db_dnp_lookup.DBINSTANCE_VERSION_NUM 
		WHERE mdh_compsys.compsys_status IN ('IN USE', 'MAINTENANCE') and COMPSYS_FQDN != 'MAINFRAME' 
		and mdh_compsys.COMPSYS_OSNAME IS NOT NULL
		AND mdh_db_dnp_lookup.DBINSTANCE_PRODUCT_NAME IS NULL 
		AND mdh_db_dnp_lookup.DBINSTANCE_VERSION_NUM is null 
		GROUP BY mdh_db_inst.DBINSTANCE_PRODUCT_NAME,mdh_db_inst.DBINSTANCE_VERSION_NUM"""


		def updatesQueryString = """\
		UPDATE extdb.mdh_db_dnp_lookup
		JOIN(
		  select 
			  mdh_db_inst.DBINSTANCE_PRODUCT_NAME,
			  mdh_db_inst.DBINSTANCE_VERSION_NUM,
			  count(distinct mdh_db_inst.DBINSTANCE_CMSCIID) as instanceCount
		  FROM extdb.mdh_os_dnp_lookup
		  INNER JOIN extdb.mdh_compsys ON mdh_os_dnp_lookup.COMPSYS_OSNAME = mdh_compsys.COMPSYS_OSNAME
		  INNER JOIN extdb.mdh_app_compsys_rel ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
		  INNER JOIN extdb.mdh_ait mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
		  INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
		  INNER JOIN extdb.mdh_compsys_dbinstance_rel ON mdh_compsys_dbinstance_rel.REL_COMPSYS = mdh_compsys.COMPSYS_CMSCIID
		  INNER JOIN extdb.mdh_db_inst ON mdh_compsys_dbinstance_rel.REL_DBINSTANCE = mdh_db_inst.DBINSTANCE_CMSCIID
		  WHERE mdh_compsys.compsys_status IN ('IN USE', 'MAINTENANCE') and COMPSYS_FQDN != 'MAINFRAME' 
		  GROUP BY mdh_db_inst.DBINSTANCE_PRODUCT_NAME,mdh_db_inst.DBINSTANCE_VERSION_NUM 
		) dbCount 
		ON mdh_db_dnp_lookup.DBINSTANCE_PRODUCT_NAME = dbCount.DBINSTANCE_PRODUCT_NAME 
		AND mdh_db_dnp_lookup.DBINSTANCE_VERSION_NUM = dbCount.DBINSTANCE_VERSION_NUM 
		SET mdh_db_dnp_lookup.instanceCount = dbCount.instanceCount
		WHERE mdh_db_dnp_lookup.instanceCount != dbCount.instanceCount"""
		
		def returnMap
		try {
			def insertsDone = db.execute(insertsQueryString)
			def updatesDone = db.executeUpdate(updatesQueryString)
			returnMap = [insert:insertsDone,updates:updatesDone]
		} catch(Exception e){
			returnMap = [errror:e.getMessage()]
		}
		

		render returnMap as JSON
		
		
	}
	
	def unmapped(){
		def allUnmapped = Mdh_os_dnp_lookup.findAllWhere(dnpStatus: null)
		render allUnmapped as JSON
	}
	
	
	def saveMapping(){
		def returnJSON = [:]
		def record = Mdh_db_dnp_lookup.get(params.id)
		if(record){
			record.properties = params
		}
		
		if (!record.save(flush: true)) {
			returnJSON.put('error',true)
			returnJSON.put('details',record.errors)
			record.errors.each {
			   println it
			}
		}else{
			returnJSON.put('success',true)
			returnJSON.put('details','Save for '+record.dbinstance_product_name+" "+record.dbinstance_version_num+' complete')
		}
		
		render returnJSON as JSON
	}
}
