package serviceportal
import groovy.io.FileType

class DirectoryReaderController {

    def index() { }
	
	def dsr(){
		if(params?.path){	
			def dir = new File(params?.path)
			def results = []
			
			dir.listFiles().each(){	
				def tmpMap = [:]
				tmpMap.putAt("dateStamp", new Date(it.lastModified()))
				tmpMap.putAt("name", it.name)
				results.add(tmpMap)
			}
			
			
			results.sort{it.dateStamp}
			
			/*results.each(){
				println it.dateStamp.toString() + " " + it.name
			}*/
			
			
			def mostRecent = results[results.size()-1].name
			def outPut = new File(params?.path+mostRecent)
			render "<h2 style=\"font-family:Calibri;font-size:11pt;\">Issue date: "+results[results.size()-1].dateStamp+"</h2><br><br>"+outPut.text
		}
		
	}
	

}
