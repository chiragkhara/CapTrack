package serviceportal

import com.bankofamerica.gwbio.ia.dynamicreport.*

class DsrOnDemandController {

    def index() { }
	
	def callDaily(){
		def reportId = 4
		String[] paraMeters = [reportId.toString()]
		println paraMeters
		testReportId report = new testReportId(paraMeters);
		
	}
}
