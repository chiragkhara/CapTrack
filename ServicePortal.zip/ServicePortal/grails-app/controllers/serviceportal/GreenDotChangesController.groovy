package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class GreenDotChangesController {

	def dataSource_ReadOnly
	
    def index() { 
		
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT * 
					FROM hotpdb.green_dot_all_change_view
					"""
		def result = db.rows(queryString)
		
		/*XmlCreateController xmlOutput = new XmlCreateController()
		xmlOutput.outPutXML(result)*/
		
		HtmlCreateController htmlOutput = new HtmlCreateController()
		htmlOutput.outPutHTML(result)
		
		
	}
	
	
	def pgpLookup(){
	
		def searchTerm
		if(!params.id.toString().toUpperCase().startsWith("PGP")){
			searchTerm = "PGP"+params.id.toString()
		}else{
			searchTerm = params.id.toString()
		}
		
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT pgp_num, pgp_desc
					FROM extdb.mxo_persongroup_persons
					where pgp_num like '"""+searchTerm.toUpperCase()+"""%'
					GROUP BY pgp_num
					order by pgp_num
					limit 10
					"""
					
					println queryString
		def result = db.rows(queryString)
		render result as JSON
	}
}
