package serviceportal

class SearchController {

    def index() { 
			
	}
	
	def app(){
		def url = "/?type=Inventory&subType=Inventory Objects&application="+params.id
		redirect(uri: url)
	}
	
	def sys(){
		def url = "/?type=Inventory&subType=Inventory Objects&system="+params.id
		redirect(uri: url)
	}
	
	def db(){
		def url = "/?type=Inventory&subType=Inventory Objects&database="+params.id
		redirect(uri: url)
	}
	
	def mw(){
		def url = "/?type=Inventory&subType=Inventory Objects&middleware="+params.id
		redirect(uri: url)
	}
}
