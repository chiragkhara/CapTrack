package serviceportal

import grails.converters.JSON
import groovy.sql.*
import com.ibm.db2.*

class RecordRefreshController {

	def dataSource
	
    def index() {
		
		if(!session['username']){
			def sso = new AuthSSOController()
			sso.index()
			if(session['username']){
				callMaximoGet()
			}
		}else if(session['username']){
			callMaximoGet()
		}
		
	}
	
	def callMaximoGet(){
		if(request.post){
			def strType = params.type
			def arrayRequestIds = params['requestIds[]']
			getMaximoData(strType,arrayRequestIds)
		}else{
			if(params?.type && params['requestIds[]']){
				def strType = params.type
				def arrayRequestIds = params['requestIds[]']
				getMaximoData(strType,arrayRequestIds)
			}
		}
		
	}
	
	def getMaximoData(type,requestIds){
		
		def queryParameter = ""
		def iCnt = 1;
		def toRemoveCnt
		
		def errorCapture = [:]
		
		if(requestIds.class.isArray()){
			for(requestId in requestIds){
				queryParameter += "'"+requestId+"'"
				if(iCnt<requestIds.size()){
					queryParameter += ","
				}
				iCnt++
			}
			toRemoveCnt = requestIds.size()
		}else{
			queryParameter += "'"+requestIds+"'"
			toRemoveCnt = 1
		}
		
		def db = Sql.newInstance('jdbc:db2://mxomart.bankofamerica.com:50018/MXOPR1R', 'MXOGBMA', 'do7yt2rp', 'com.ibm.db2.jcc.DB2Driver')
		def query
		def extDBTable
		def keyColumn
		
		if(type=="Incident"){
			query = "select * from MXOMART.V_CTO_IM_INCIDENT_30DAYS where ticketid IN ("+queryParameter+")"
			extDBTable = "mxo_im_incidents"
			keyColumn = "ticketid"
		}else if(type=="Problem"){
			query = "select * from MXOMART.V_CTO_PM_PROBLEM_30DAYS where ticketid IN ("+queryParameter+")"
			extDBTable = "mxo_pm_problems"
			keyColumn = "ticketid"
		}
		
		
		
		println query
		def tmpTableName = "extdb.t_refreshTable"
		def dataAndSchema = getDataAndSchema(db,query,tmpTableName,extDBTable,type,keyColumn)
		
		def returnJSON = [:]
		
		if(dataAndSchema.error==null){
			returnJSON.put("success", true)
			returnJSON.put("error", false)
			returnJSON.put("removed", toRemoveCnt)
			returnJSON.put("submitted", dataAndSchema.size())
			returnJSON.put("inserted",dataAndSchema.inserts_completed)		
		}else if(dataAndSchema.error!=null){
			returnJSON.put("error", true)
			returnJSON.put("message","No records match the query in eSmart")
			returnJSON.put("detail", query)
		}



		
		render returnJSON as JSON
	
	}
	
	def createTableAndInsert(dataAndSchema,tableName,extDBTable,keyColumn,type,query){
		
		/*
		* Create new temp table
		* Insert all data from eSmart
		*/
		
		def db = new Sql(dataSource)
		def omitColumnsAll = getOmitColumns()
		def omitColumns = omitColumnsAll[type]
		try {
			db.execute("drop table "+tableName)
			println tableName+" dropped..."
		 } catch(Exception e){
		 	println e.getMessage()
		 }
		
		 // create table
		def createStatement = "create table "+tableName+" ( "+dataAndSchema.createTable+" )"
		println createStatement
		try {
			db.execute(createStatement)
		}catch(Exception e){
		 	println e.getMessage()
		 }
		 
		 println "new Table being created"
		 
		 def newTable = db.dataSet(tableName)
		 
		 println "data being inserted"
		 def iCnt = 0;
		 
		 dataAndSchema.results.each() {
			 for ( omitKey in omitColumns ) {
				 it.remove(omitKey)
			 }	 
			 println it.BATRIAGEENGAGEDDATE
			 newTable.add(it)
			 println "adding row "+iCnt
			 iCnt++
		 }
		 
		
		 
		 /*
		  * Call function to delete all records that join to recently returned ones
		  * and to reinsert them from new temp table
		  */
		 def newIds
		 def deleteAndInsert = getDeleteAndReInsert(tableName,dataAndSchema.columns,extDBTable,keyColumn);
		 try {
			 db.execute(deleteAndInsert.deleteString)
		 } catch(Exception e){
		 	println e.getMessage()
		 } finally {
			 println "deletions worked"
			 newIds = db.executeInsert(deleteAndInsert.insertString)
			 println newIds.size();
			 newIds.each(){
				 println "new id: "+it
			 }
		 }
		 
		 
		 try {
			 //def timestamp = new Date().format('dd-MM-yyyy H:m:s')
			 def logQuery = "insert into hotpdb.ia_forcerefresh (timestamp,authUser,sqlString) values (now(),'"+session["username"]+"','"+query.replaceAll("'", "''")+"')"
			 println logQuery
			 db.execute(logQuery)
		 }catch(Exception e){
		 	println e.getMessage()
		 }
		 
		 
		 try {
			 //db.execute("drop table "+tableName)
			 println tableName+" dropped..."
		  } catch(Exception e){
		  	println e.getMessage()
		  }
			 
		  return newIds

	}
	
	def getDeleteAndReInsert(tableName,columns,extDBTable,keyColumn){
		
		def mapDeleteInsert = [:]
		
		def delString = "DELETE extdb."+extDBTable+" FROM extdb."+extDBTable
		delString += " INNER JOIN "+tableName+" sourceData ON sourceData."+keyColumn+" = "+extDBTable+"."+keyColumn
		delString += " WHERE sourceData."+keyColumn+" = "+extDBTable+"."+keyColumn
		
		def insertString = "INSERT INTO extdb."+extDBTable+" ("
		def iCnt = 1;
		for ( columnName in columns ){
			insertString += columnName
			if(iCnt<columns.size()){
				insertString += ","
			}
			iCnt++;
		}
		
		insertString += ") Select * from "+tableName
		
		println delString
		println insertString
		
		
		mapDeleteInsert.put("deleteString", delString)
		mapDeleteInsert.put("insertString", insertString)
		
		return mapDeleteInsert
		
	}
	
	def getDataAndSchema(db,query,tmpTableName,extDBTable,type,keyColumn){
		
		def db2DataTypeMappings = getDataTypeMapping()
		def omitColumnsAll = getOmitColumns()
		def omitColumns = omitColumnsAll[type]
		def createTable = "";
		def minusCounter = 0;
		def columnArray = []
		def results = db.rows(query, { meta ->
			for (int i = 1; i <= meta.columnCount; i++) {
				def isOmitColumn = meta.getColumnLabel(i) in omitColumns
				if(!isOmitColumn){
					columnArray.add(meta.getColumnLabel(i))
					def columnString = meta.getColumnLabel(i) + " " + db2DataTypeMappings[meta.getColumnTypeName(i)].name
					if(db2DataTypeMappings[meta.getColumnTypeName(i)].size != null){
						columnString +=  "("+meta.getPrecision(i)+")"
					}
					
					columnString += ","
					createTable += columnString
				}else{
					minusCounter++
				}
			}
			
		})
		
		

		def returnDataAndSchema = [:]
		returnDataAndSchema.put("createTable", createTable[0..-2])
		returnDataAndSchema.put("results", results)
		returnDataAndSchema.put("columns", columnArray)
		
		
		//println createTable
		println "Data and table schema being returned"
		if(results.size()>0){
			def insertsWorked = createTableAndInsert(returnDataAndSchema,tmpTableName,extDBTable,keyColumn,type,query)		
			return ["inserts_submitted": results.size(), "inserts_completed": insertsWorked, "error": null]
		}else{
			return ["error": "No results from query exiting"]
		}
		
	}
	
	
	def getDataTypeMapping(){
		def mapMapping = [
			'BIGINT': [name:'BIGINT',size:null],
			'BLOB': [name:'BLOB',size:null],
			'CHAR': [name:'CHAR',size:1],
			'CHARACTER': [name:'CHAR',size:1],
			'CHARACTER_VARING': [name:'VARCHAR',size:null],
			'CHAR_()_FOR_BIT_DATA': [name:'BINARY',size:null],
			'CLOB': [name:'text',size:null],
			'DATE': [name:'DATE',size:null],
			'DBCLOB': [name:'CLOB',size:null],
			'DECIMAL': [name:'DECIMAL',size:null],
			'DOUBLE': [name:'DOUBLE',size:null],
			'GRAPHIC': [name:'CHAR',size:1],
			'INTEGER': [name:'INTEGER',size:null],
			'LONGVAR': [name:'CLOB',size:null],
			'LONG VARG': [name:'CLOB',size:null],
			'LONG_VARCHAR': [name:'CLOB',size:null],
			'LONG_VARCHAR_()_FOR_BIT_DATA': [name:'BLOB',size:null],
			'LONG_VARGRAPHIC': [name:'CLOB',size:null],
			'REAL': [name:'REAL',size:null],
			'ROWID': [name:'BINARY',size:1],
			'SMALLINT': [name:'SMALLINT',size:null],
			'TIME': [name:'TIME',size:null],
			'TIMESTAMP': [name:'TIMESTAMP NULL',size:null],
			'VARCHAR': [name:'VARCHAR',size:1],
			'VARCHAR_()_FOR_BIT_DATA': [name:'VARBINARY',size:true],
			'VARGRAPH': [name:'VARCHAR',size:1],
			'VARGRAPHIC': [name:'VARCHAR',size:1]
			]
	
		return mapMapping
	}
	
	def getOmitColumns(){
		
		def incidentOmits = [
			"DESCRIPTION_LONGDESCRIPTION",
			"PROBLEMCODE_LONGDESCRIPTION"
			]
		def changeOmits = [
			"JP_BALASTUPDATE",
			"JPLD_BALASTUPDATE",
			"LD_BALASTUPDATE",
			"CABAPP_BALASTUPDATE",
			"BACHANGEREASON",
			"BACHGACTIVITY",
			"BACHGCLASS",
			"BAMISCCHECKBOX1",
			"BAMISCCHECKBOX2",
			"BAMISCCHECKBOX8",
			"BAMISCTEXT1",
			"BAMISCTEXT2",
			"BAMISCTEXT3"
			]
		def problemOmits = [
			"BAPROBLEMRESOLUTIONDATE_ET",
			"BAPPRSTATUS",
			"PPRDATECOMPLETE",
			"PPRDATECOMPLETE_ET",
			"URL"		
			]
		
		
		def rtnOmitColumns = ['Incident':incidentOmits,'Change':changeOmits,'Problem':problemOmits]
		
		return rtnOmitColumns
	}
}