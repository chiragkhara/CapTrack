package serviceportal

import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import grails.converters.JSON
import javax.servlet.http.Cookie

class AuthSSOController {


    def index() { 	
			println request.getHeader("host")
			if(request.getHeader("host").toString().indexOf("localhost")>-1){
				LDAPSearch search = new LDAPSearch("nbkxuqk");
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}else if(request.getHeader("uid")){
				LDAPSearch search = new LDAPSearch(request.getHeader("uid"));
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}else{
				render "SSO Authentication NOT Provided"
			}
	}
	
	def isLoggedIn(){
		if(!session['username']){
			index()
		}
		
		def userData = [:]
		
		if(session['username']){
			userData.username = session['username']
			userData.email = session['email']
			userData.name = session['name']
		}else{
			userData.put('error', true)
			userData.put('message', "User not logged in")
		}
		render userData as JSON		
	}
	
	def uid(){
			
		def outPut = [:]
		outPut.put("host", request.getHeader("host"))
		outPut.put("UID", request.getHeader("uid"))
		outPut.put("SMUNIVERSALID", request.getHeader("SMUNIVERSALID"))
		outPut.put("SMUSER", request.getHeader("SMUSER"))
		render outPut as JSON
	}
	
	def testHeaders(){
		
		def headers =  request.getHeaderNames()
		def userData = []
		headers.each{
			println it
			def tmp = [:]
			tmp.put(it, request.getHeader(it))
			userData.add(tmp)
		}
				
		render userData as JSON
	}
	
	def getUser(){
		println "called"
		if(!session['username']){
			index()
		}
		def userData = [:]
		userData.username = session['username']
		userData.email = session['email']
		userData.name = session['name']
		render userData as JSON
	}
}
