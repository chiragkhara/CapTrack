package serviceportal

import grails.converters.JSON

class RedDotController {

    def index() { }
	
	def submit(){
		def redDotRecord = RedDot.get(params.id)
		def valMap = [:]
		def returnMap = [:]
		def dateParsed = null
		if(!params[params.id+"_resolutionDate"].toString().empty){
			def dateParseValue = params[params.id+"_resolutionDate"]
			if(dateParseValue!=null){
				dateParsed = new Date().parse('dd/MM/yyyy',dateParseValue)
			}else{
				dateParsed = new Date()
			}
		}
		
		
		valMap.put('status', params[params.id+"_status"])
		valMap.put('risklevel', params[params.id+"_risk"])
		valMap.put('idtrigger', params[params.id+"_trigger"])
		valMap.put('coordinator', params[params.id+"_coordinator"])
		valMap.put('resolutiondate', dateParsed)
		valMap.put('standardid', params.uid)
		def archiveSet = params[params.id+"_redDotArchive"]
		if(archiveSet==null){
			archiveSet = false
		}
		valMap.put('archive',archiveSet)
		
		
		if(valMap['standardid']==null){
			def ssoForce = new AuthSSOController()
			ssoForce.index()
			valMap['standardid'] = session["username"]
		}
		
		println valMap
		
		if(redDotRecord){
			println "updating"
			redDotRecord.properties = valMap
		}else{
			println "creating"
			redDotRecord = new RedDot(valMap)
			redDotRecord.id = params.id
		}		
		

		if (!redDotRecord.save(flush: true)) {
			returnMap.put('errors',[:])
			println redDotRecord.errors
			redDotRecord.errors.each {
				returnMap['errors'].put(it, it.toString())
			}
		}else{
			returnMap.put('success', redDotRecord.id)
		}
		
		render returnMap as JSON
		
	}
}
