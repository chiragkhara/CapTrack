package serviceportal

import groovy.xml.MarkupBuilder

class HtmlCreateController {

    def index() { }
	
	def outPutHTML(dbRows){
		def html = convertSQL(dbRows)
		render(text: html, contentType: "text/html", encoding: "UTF-8")
	}
	
	def convertSQL(dbRows){

		def s_html=new StringWriter()
		def firstRow = true
		
		new MarkupBuilder(s_html).table(){
			dbRows.each(){
				def row = it
					if(firstRow){
						tr {
							//th()
							row.each { key,value -> th(key) }
						}
						firstRow = false
					}
					tr {
						//td()
						row.each { key,value -> td(value) }
					}

				}
			}
		return s_html
	}
	
}
