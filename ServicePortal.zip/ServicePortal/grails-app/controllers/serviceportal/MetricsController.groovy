package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import java.text.DateFormat
import java.text.SimpleDateFormat

class MetricsController {
	def dataSource_ReadOnly
	
    def index() { }
	
	def activeIncidents(){
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					select 
					  dsrtickets.ticketId `TicketId`, 
					  dsrtickets.servicearea `ServiceArea`, 
					  GROUP_CONCAT(distinct MDH_AIT.AIT_AITSHORTNAME SEPARATOR  ',  ')  `Application(s)`, 
					  mxo_im_incidents.STATUS `Status`, 
					  mxo_im_incidents.DESCRIPTION `Description`, 
					 Cast(concat( mxo_im_incidents.REPORTEDPRIORITY,'|',mxo_im_incidents.BAURGENCY,'|',mxo_im_incidents.BAIMPACT) as Char) as `P|U|I`,
					  /*mxo_im_incidents.REPORTDATE `Reported`,*/
					  TIME_FORMAT(TIMEDIFF(now(), mxo_im_incidents.REPORTDATE_ET),'%Hh %im') `(Running) Duration`
					  /*mxo_im_incidents.TARGETFINISH `Restored`*/
					from hotpdb.dsrtickets
					JOIN extdb.mxo_im_incidents on dsrtickets.ticketid = extdb.mxo_im_incidents.TICKETID
					JOIN extdb.mdh_ait ON mxo_im_incidents.baaitnumber = mdh_ait.AIT_CILABEL OR mxo_im_incidents.baaitnumber_direct = mdh_ait.AIT_CILABEL
					where (dsrtickets.targetfinish  >= SUBDATE(CURDATE(),1) OR dsrtickets.targetfinish IS NULL) 
					AND mxo_im_incidents.STATUS <> 'RESTORED'
					group by dsrtickets.ticketId
					order by mxo_im_incidents.REPORTDATE DESC"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def podTicketStatus(){
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					select POD, 
					    SUM(CASE WHEN status='NEW' THEN 1 ELSE 0 END)  as 'NEW',
					    SUM(CASE WHEN status='QUEUED' THEN 1 ELSE 0 END)  as 'QUEUED',
					    SUM(CASE WHEN status='INPROG' THEN 1 ELSE 0 END)  as 'INPROG',
					    SUM(CASE WHEN status='PENDCLOSED' THEN 1 ELSE 0 END)  as 'PENDCLOSED'
					from (
					SELECT 
					    distinct grps.description as POD, inci.ticketid, inci.status
					    FROM extdb.mxo_im_incidents inci
					    JOIN hotpdb.hotpgroupaits aits ON inci.baaitnumber=aits.ait_id OR inci.baaitnumber_direct=aits.ait_id
					    JOIN hotpdb.hotpgroups grps ON aits.hotpgroup_id = grps.id	
					    WHERE BAPMINTERNALPRIORITY < 3 AND
					    inci.status not in ('CLOSED','RESTORED') AND grps.id IN (20,23,24,25)
					) a
					group by POD """
		def result = db.rows(queryString)
		render result as JSON
		
	}
	
	
	def podTicketDetail(){
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT	distinct inci.ticketid			
					FROM extdb.mxo_im_incidents inci
					JOIN hotpdb.hotpgroupaits aits ON inci.baaitnumber=aits.ait_id OR inci.baaitnumber_direct=aits.ait_id
					JOIN hotpdb.hotpgroups grps ON aits.hotpgroup_id = grps.id
					WHERE BAPMINTERNALPRIORITY < 3 AND
					inci.status = '${params.status}'
					AND grps.description = '${params.POD}' """
		def result = db.rows(queryString)
		render result as JSON
		
	}
	
	def podAITStatus = {
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT 
				       hotpgroups.description,
				       hotpgroups.modifiedtime,
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='D' THEN 1 ELSE 0 END)  as 'In Development',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='P' THEN 1 ELSE 0 END)  as 'In Production',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='R' THEN 1 ELSE 0 END)  as 'Decomissioned',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='RAD' THEN 1 ELSE 0 END)  as 'Retain App & Data',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='RD' THEN 1 ELSE 0 END)  as 'Retain Data',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='S' THEN 1 ELSE 0 END)  as 'Projected Retire',
				      SUM(CASE WHEN ait_dq_vws_app.APP_STATUS_FLAG='T' THEN 1 ELSE 0 END)  as 'Retired'
				
				 
				  FROM    (   hotpdb.hotpgroupaits hotpgroupaits
				           INNER JOIN
				              hotpdb.hotpgroups hotpgroups
				           ON (hotpgroupaits.hotpgroup_id = hotpgroups.id))
				       INNER JOIN
				          extdb.ait_dq_vws_app ait_dq_vws_app
				       ON (hotpgroupaits.ait_id = ait_dq_vws_app.APP_ID)
				 WHERE (hotpgroups.id IN (20, 23, 24, 25))
				 group by hotpgroups.id """
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def lastTenUpdates(){
		
		def db = new Sql(dataSource_ReadOnly) 
		def queryString = """\
					SELECT DISTINCT logs.recordkey as ticketid, max(logs.balastupdate) as balastupdate
					FROM extdb.mxo_im_incident_worklogs logs 
					JOIN extdb.mxo_im_incidents inci on logs.recordkey=inci.TICKETID 
					JOIN hotpdb.hotpgroupaits aits ON inci.baaitnumber=aits.ait_id OR inci.baaitnumber_direct=aits.ait_id 
					JOIN hotpdb.hotpgroups grps ON aits.hotpgroup_id = grps.id 
					WHERE grps.id IN (20, 23, 24, 25) 
					AND inci.REPORTEDPRIORITY < 3
					AND logs.createby NOT LIKE 'NBSP7HN' 
					AND (
					logs.balastupdate > DATE_FORMAT(date_sub(now(), INTERVAL 1 day),'%Y-%m-%d') 
					OR logs.description_ld_balastupdate > DATE_FORMAT(date_sub(now(), INTERVAL 1 day),'%Y-%m-%d')
					) 
					group by logs.recordkey
					ORDER BY logs.modifydate desc"""
		def result = db.rows(queryString)
		render result as JSON
		
		
	}
	
	def monthlyPODPerformance(){
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Calendar originalDate = Calendar.getInstance();
		
		Calendar previousMonthDay = (Calendar) originalDate.clone();
		previousMonthDay.add(Calendar.MONTH, -1);
		
		def nowDate = dateFormat.format(originalDate.getTime());
		def fromDate = dateFormat.format(previousMonthDay.getTime());

		
		def queryString = """\
			select Month_Day ,
			SUM(CASE WHEN Type='Opens' THEN 1 ELSE 0 END)  as 'Opens',
			SUM(CASE WHEN Type='Closes' THEN 1 ELSE 0 END)  as 'Closes'
			
			from
			
			(
			
			SELECT ticketid, DATE_FORMAT(CREATIONDATE,'%d/%m/%Y') as Month_Day, 'Opens' as Type
			
			
			FROM extdb.mxo_im_incidents inci
			JOIN hotpdb.hotpgroupaits aits ON inci.baaitnumber=aits.ait_id OR inci.baaitnumber_direct=aits.ait_id
			JOIN hotpdb.hotpgroups grps ON aits.hotpgroup_id = grps.id
			
			WHERE BAPMINTERNALPRIORITY < 3 AND
			inci.CREATIONDATE BETWEEN '${fromDate}' AND '${nowDate}' 
			AND grps.id IN (20,23,24,25)
			group by Month_Day, ticketid
			
			UNION
			
			SELECT ticketid,  DATE_FORMAT(BACLOSEDDATE,'%d/%m/%Y') as Month_Day, 'Closes' as Type
		
			FROM extdb.mxo_im_incidents inci
			JOIN hotpdb.hotpgroupaits aits ON inci.baaitnumber=aits.ait_id OR inci.baaitnumber_direct=aits.ait_id
			JOIN hotpdb.hotpgroups grps ON aits.hotpgroup_id = grps.id	  
			
			WHERE BAPMINTERNALPRIORITY < 3 AND
			inci.BACLOSEDDATE BETWEEN '${fromDate}' AND '${nowDate}'
			AND grps.id IN (20,23,24,25)
			group by Month_Day, ticketid
			
			
			) as opens
			
			group by Month_Day
			order by Month_Day"""

		def db = new Sql(dataSource_ReadOnly)
		def result = db.rows(queryString)
		render result as JSON
		
	}
	

}
