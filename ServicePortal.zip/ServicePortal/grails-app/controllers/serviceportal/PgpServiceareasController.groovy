package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class PgpServiceareasController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
		
		def searchedList = PgpServiceareas.createCriteria().list (params) {
			if ( params.query ) {
				or { 
					ilike("pgp", "%${params.query}%")
					ilike("pgpname", "%${params.query}%")
					ilike("servicearea", "%${params.query}%")
				}
			}
		}
		
        //[pgpServiceareasInstanceList: PgpServiceareas.list(params), pgpServiceareasInstanceTotal: PgpServiceareas.count()]
		[pgpServiceareasInstanceList: searchedList, pgpServiceareasInstanceTotal: searchedList.totalCount]
		
    }

    def create() {
        [pgpServiceareasInstance: new PgpServiceareas(params)]
    }

    def save() {
        def pgpServiceareasInstance = new PgpServiceareas(params)
        if (!pgpServiceareasInstance.save(flush: true)) {
            render(view: "create", model: [pgpServiceareasInstance: pgpServiceareasInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), pgpServiceareasInstance.id])
        redirect(action: "show", id: pgpServiceareasInstance.id)
    }

    def show() {
        def pgpServiceareasInstance = PgpServiceareas.get(params.id)
        if (!pgpServiceareasInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "list")
            return
        }

        [pgpServiceareasInstance: pgpServiceareasInstance]
    }

    def edit() {
        def pgpServiceareasInstance = PgpServiceareas.get(params.id)
        if (!pgpServiceareasInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "list")
            return
        }

        [pgpServiceareasInstance: pgpServiceareasInstance]
    }

    def update() {
        def pgpServiceareasInstance = PgpServiceareas.get(params.id)
        if (!pgpServiceareasInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (pgpServiceareasInstance.version > version) {
                pgpServiceareasInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas')] as Object[],
                          "Another user has updated this PgpServiceareas while you were editing")
                render(view: "edit", model: [pgpServiceareasInstance: pgpServiceareasInstance])
                return
            }
        }

        pgpServiceareasInstance.properties = params

        if (!pgpServiceareasInstance.save(flush: true)) {
            render(view: "edit", model: [pgpServiceareasInstance: pgpServiceareasInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), pgpServiceareasInstance.id])
        redirect(action: "show", id: pgpServiceareasInstance.id)
    }

    def delete() {
        def pgpServiceareasInstance = PgpServiceareas.get(params.id)
        if (!pgpServiceareasInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "list")
            return
        }

        try {
            pgpServiceareasInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'pgpServiceareas.label', default: 'PgpServiceareas'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
