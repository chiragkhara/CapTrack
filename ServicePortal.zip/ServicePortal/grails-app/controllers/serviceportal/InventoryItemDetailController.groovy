package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class InventoryItemDetailController {

	def dataSource_ReadOnly
	
    def index() { }
	
	def compsys(){
		
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhCompsysDetail.sql",[COMPSYS_HOSTNAME:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(sqlString) as JSON
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as JSON
		}
		
	}
	
	
	def application(){
		
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhAITDetail.sql",[AIT_CILABEL:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(sqlString) as JSON
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as JSON
		}
		
	}
	
	def applicationCompsys(){
		
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhAITCompsysDetail.sql",[AIT_CILABEL:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(sqlString) as JSON
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as JSON
		}
		
	}
	
}
