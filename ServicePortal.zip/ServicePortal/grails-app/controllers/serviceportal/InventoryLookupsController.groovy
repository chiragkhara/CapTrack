package serviceportal
import grails.converters.JSON
import grails.converters.XML
import groovy.sql.Sql
import groovy.text.SimpleTemplateEngine

class InventoryLookupsController {

	def dataSource_ReadOnly
	
    def index() { }
	
	def application(){
		
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhAitLookup.sql",[AIT_CILABEL:params.id, AIT_AITSHORTNAME:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(sqlString) as JSON
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as JSON
		}
		
	}
	
	
	def applicationXML(){
		
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhAitLookup.sql",[AIT_CILABEL:params.id, AIT_AITSHORTNAME:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_RO)
			
			def s_xml=new StringWriter()
			def builder = new groovy.xml.MarkupBuilder(s_xml)
			
			def outPut = []
				builder.RFC{
					db.rows(sqlString).each() {
						def row = it
						item(){
							row.each(){ key, value ->
								"${key}"("${value}")
							}
						}
					}
				}
			render(text: s_xml, contentType: "text/xml", encoding: "UTF-8")
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as XML
		}
		
	}
	
	
	def compsys(){
		SqlReaderController sqlReader = new SqlReaderController()
		def sqlString = sqlReader.getSQLFile("mdhCompsysLookup.sql",[COMPSYS_HOSTNAME:params.id])
		
		if(sqlString!=null){
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(sqlString) as JSON
		}else{
			def errorResponse = [Error:'SQL Source error']
			render errorResponse as JSON
		}
		
	}
	
	
}
