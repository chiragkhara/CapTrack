package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import javax.servlet.http.Cookie

class WorkloadController {

	def dataSource_ReadOnly
    
	def index() { }
	
	def aitLookup(){
		def db = new Sql(dataSource_ReadOnly) 
		def aitLookup = params.id
		def queryString = """\
					Select ait_aitshortname, ait_aitnumber
					FROM extdb.mdh_ait 
					WHERE ait_aitshortname LIKE '"""+aitLookup+"""%'
					OR ait_aitnumber LIKE '"""+aitLookup+"""%'
					order by ait_aitshortname
					LIMIT 10
				"""
		println queryString
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def aitServers(){
		
		def db = new Sql(dataSource_ReadOnly) 
		def queryString = """\
					Select mdh_compsys.compsys_hostname as Hostname, mdh_compsys.compsys_operatingenv as Environment 
					FROM extdb.mdh_compsys
					INNER JOIN extdb.mdh_app_compsys_rel ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
					INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
					WHERE mdh_compsys.compsys_operatingenv IN ('Production','Contingency') AND mdh_ait.ait_aitnumber = ${params.aitnumber}
					ORDER BY compsys_operatingenv, compsys_hostname
				"""
		def result = db.rows(queryString)
		render result as JSON
		
		
	}
}
