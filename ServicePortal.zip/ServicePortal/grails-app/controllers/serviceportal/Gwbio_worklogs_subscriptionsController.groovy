package serviceportal
import grails.converters.JSON
import groovy.sql.Sql


class Gwbio_worklogs_subscriptionsController {
	def dataSource
	
	def index() {
		def authenticated = new AuthSSOController()
		authenticated.index()
	}
	
	def deleteUserAIT(){
		def mapErrors = [:]
		def success = true
		def subscription = Gwbio_worklogs_subscriptions.get(params.id)
		try {
			def map = [ait:subscription.ait,email:subscription.email,stdid:session['username']]
			def recordDelete = new Gwbio_worklogs_remove_subscriptions(map)
			recordDelete.save()
			subscription.delete(flush: true)
		} catch (all) {
			mapErrors.put("Error","Error");
			success = false
		} 
		
		def rtnMessage = [success:success,errors:mapErrors]
		render rtnMessage as JSON
	}
	
	def submitUserAIT(){
		def mapErrors = [:]
		def success = false
		def subscriptions = Gwbio_worklogs_subscriptions.findAllByStdidAndAit(params.user,params.ait)
		def newSubscription = null
		
		if(subscriptions.size()==0){
			def map = [ait:params.ait,email:params.email,stdid:params.user]
			newSubscription = new Gwbio_worklogs_subscriptions(map)
			if (!newSubscription.save(flush: true)) {
				newSubscription.errors.each {
					mapErrors.put(k, it.toString())
					println it
				}
			}else{
				success = true
			}
		}else{
			mapErrors.put("Error", params.user+" already subscribed to "+params.ait)
		}
		
		def rtnMessage = [success:success,errors:mapErrors, info: newSubscription]
		render rtnMessage as JSON
	}

	def getByUser(){
		
		def db = new Sql(dataSource)
		
		if(!session['username'] || !session['email']){
			def authenticated = new AuthSSOController()
			authenticated.index()
		}
		
		def queryString = """\
			SELECT  
				gwbio_worklogs_subscriptions.id,
				mdh_ait.ait_aitnumber `AIT#`,
				mdh_ait.ait_aitshortname `AIT Name`,
		        COALESCE(CONCAT(mdh_ait.AIT_SECOND_LVL_PROD_SUPPORT_LNAME,', ', mdh_ait.AIT_SECOND_LVL_PROD_SUPPORT_FNAME),'') `Production Support`,
		        CONCAT(mdh_ait.AIT_APP_MGR_LNAME,', ', mdh_ait.AIT_APP_MGR_FNAME) `Application Manager`
			FROM hotpdb.gwbio_worklogs_subscriptions
			LEFT JOIN extdb.mdh_ait ON gwbio_worklogs_subscriptions.ait = mdh_ait.ait_aitnumber
			Where gwbio_worklogs_subscriptions.stdId=? OR gwbio_worklogs_subscriptions.email=?
		"""
		
		def result = db.rows(queryString,[session['username'],session['email']])
		render result as JSON
		
		//def subscriptions = Gwbio_worklogs_subscriptions.findAllByStdid(session['username'])?.collect{['AIT': it.ait]}
		//render subscriptions as JSON
	}
}
