package serviceportal

import grails.converters.JSON

class TestLoginController {

	def beforeInterceptor = [action: this.&checkUser, except: ['noCheck'] ]
	
	def checkUser(){
		def loggedIn = [:]
		
		if(session["user"]){
			loggedIn.loggedIn = true;
		}else{
			loggedIn.loggedIn = false;
			
		}
		render loggedIn as JSON
	}
	
    def index() { 
		def jsonResponse = [:]
		jsonResponse.text = "hello"
		render	jsonResponse as JSON
	}
	
	
	def list() { 
		}
	
	def show() { 
		}
}
