package serviceportal

import groovy.text.SimpleTemplateEngine

class SqlReaderController {

   	def getSQLFile(sqlFileName,parameterMap){
		
		def fPath =  request.getSession().getServletContext().getRealPath("/")
		File file = new File(fPath+sqlFileName)
		if(!file.isFile()){
			return null	
		}
		
		String fileContents = file.text
		def engine = new SimpleTemplateEngine()
		def template = engine.createTemplate(fileContents).make(parameterMap.withDefault{ '' })
		return template.toString()
	}
}
