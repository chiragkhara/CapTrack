package serviceportal


import grails.converters.JSON
import groovy.sql.Sql

class Earc_productListController {
	def dataSource_ReadOnly
    def index() { 
	
		if(params.q){
			def db = new Sql(dataSource_ReadOnly)
			def queryTerm = params.q.toString().replaceAll(" ","%")
			def queryDistinctEARCProducts = "SELECT ProductID as id, ProductName as text FROM extdb.earc_all_product_list WHERE ProductName LIKE '%"+queryTerm+"%' ORDER BY ProductName LIMIT 10"
			println queryDistinctEARCProducts
			render db.rows(queryDistinctEARCProducts) as JSON
		}
	}
}
