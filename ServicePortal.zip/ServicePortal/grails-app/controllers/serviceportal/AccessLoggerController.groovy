package serviceportal

import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import grails.converters.JSON

class AccessLoggerController {

    def index() { 
		def hostname = "hostname".execute().text
		def port = "26110"
		//def port = "8080"
		def actionString = "record"
		def url = "http://"+hostname.toString().trim()+":"+port+"/"+grailsApplication.metadata['app.name']+"/"+controllerName+"/"+actionString
		[url:url]
		
	}
	
	def showLogRequested(){
		def hostname = "hostname".execute().text
		
		hostname = hostname.trim()
		if(hostname.indexOf(".") > -1){
			hostname = hostname.substring(0,hostname.indexOf("."))
			hostname = hostname.trim()
		}
		
		def loggerName = 'ServicePortal_'+hostname
		loggerName = loggerName.trim()
				
		def extraLogger = org.apache.log4j.Logger.getLogger(loggerName)
		def loggerExists = extraLogger.exists(loggerName)
		def rtn = [name: loggerName, exists: loggerExists]
		render rtn as JSON
		
	}
	
	def record(){
		
		if(!session['username']){
			AuthSSOController sso = new AuthSSOController()
			sso.index()
		}		
			
		def username = session['username']
		def email = session['email']
		def name = session['name'] 
	
		
		def hostname = "hostname".execute().text
		
		hostname = hostname.trim()
		if(hostname.indexOf(".") > -1){
			hostname = hostname.substring(0,hostname.indexOf("."))
			hostname = hostname.trim()
		}
		
		def loggerName = 'ServicePortal_'+hostname
		loggerName = loggerName.trim()
				
		println loggerName
				
		def extraLogger = org.apache.log4j.Logger.getLogger(loggerName)
		extraLogger.info("STNID: "+username+" | Email: "+email+" | Name: "+name)
		
		def returnObj = ['success': true]
		
		render returnObj as JSON
	}
}
