package serviceportal

import com.bankofamerica.com.gwbio.ia.QueryToFile.QueryToFile

import groovy.sql.Sql
import javax.sql.DataSource
import org.apache.commons.dbcp.BasicDataSource


class QueryToExcelController {

	def dataSource_ReadOnly
	
    def index() { }
	
	
	def callQuery(){
		def filepath = params.sqlFile;
		filepath = "RedDot/PMs"
		def fPath =  request.getSession().getServletContext().getRealPath("/")	
		String fileContents = new File(fPath+filepath+'.sql').text
		
		def db = new Sql(dataSource_ReadOnly)
		def excelCreated = "ExcelGo.xlsx"
		def workSheetArray = "PMs,CARs"
		
		
		def queryToFile = new QueryToFile((DataSource) db.getDataSource(),fileContents,fPath+excelCreated,workSheetArray)

	
		def file = new File(fPath+excelCreated)
		if (file.exists()){
			response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") 
			response.setHeader("Content-disposition", "attachment;filename=\"${excelCreated}\"")
			response.outputStream << file.bytes
		}
		else render "Error!" // appropriate error handling
		
	}
}
