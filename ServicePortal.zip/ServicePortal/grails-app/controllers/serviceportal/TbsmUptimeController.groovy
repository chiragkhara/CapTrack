package serviceportal

import groovy.sql.Sql

class TbsmUptimeController {

	def dataSource_ReadOnly
	
    def index() { }
	
	def exportReport(){
		
		
		if(params?.category){
			
			//add element to the params.parameters - by creating a list - adding each params.parameter to it - then adding "comparision"
			def parameters

			def tbsmCategorisation;
			def timeComparator = "( systemuptime / (60.0 * 60.0 * 24.0) )"
			
			//CREATE/Format the NEW tbsmCategorisation parameter
			if(params.category.toString().contains('>=')){
				def comparison = params.category.substring(0,2)
				def category = params.category.substring(2)
				tbsmCategorisation = timeComparator+ " "+comparison+" "+category
			}else if(params.category.toString().contains('<')){
				def comparison = params.category.substring(0,1)
				def category = params.category.substring(1)
				tbsmCategorisation = timeComparator+ " "+comparison+" "+category
			}else if(params.category.toString().equals("Unknown")){
				//tbsmCategorisation = "tbsmuptime.hostname is null"
			tbsmCategorisation = timeComparator+ " <= 0"
			}
			
			params.put("tbsmCategorisation", tbsmCategorisation)
			params.putAt("omitDataType", ["tbsmCategorisation","date"])
			
		}
		
		
		
		def fileName = params.fileName
		def export = params.export
		params.date = " = STR_TO_DATE('"+params.date+"', '%d-%M-%Y')"
				
		params.remove("category")
		params.remove("fileName")
		params.remove("export")
		
		def db = new Sql(dataSource_ReadOnly)
		MetricsLoaderFieldsController metrics = new MetricsLoaderFieldsController()
		metrics.processParams(db,export,fileName)
	}
}
