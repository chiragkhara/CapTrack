package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import groovy.text.SimpleTemplateEngine
import javax.servlet.http.Cookie

class MetricsLoaderSimpleController {
	def dataSource_ReadOnly, dataSource_dev, dataSource_uat, dataSource
	
    def index() { 
	
		if(params?.sqlFile){
			def db
			if(params.devDB){
				db = new Sql(dataSource_dev)
			}else if(params.prodDB){
				db = new Sql(dataSource)
			}else if(params.uatDB){
				println "USING UAT"
				db = new Sql(dataSource_uat)
			}else{
				db = new Sql(dataSource_ReadOnly)
			}
			//def fPath = "/hosting/configs/tomcat7/hotp-dev-01/webapps/ServicePortal/"
			processParams(db,params?.export,params?.fileName)
		}
			
	}
	
	def processParams(db,export,fileName){

		def fPath =  request.getSession().getServletContext().getRealPath("/")
		//println fPath
		
		String fileContents = new File(fPath+params.sqlFile+'.sql').text
			
		if(params?.parameters){
			def parameterMap = [:]
			
			if(params.parameters.getClass().isArray()){
				params.parameters.each {
					processMapCreation(it,params.get(it),parameterMap)
				}
			}else{
				processMapCreation(params.parameters,params.get(params.parameters),parameterMap)
			}
			
			if(parameterMap.size()>0){
				parameterMap.put('addWhere', true)
			}
			
			def engine = new SimpleTemplateEngine()
			def template = engine.createTemplate(fileContents).make(parameterMap.withDefault{ '' })
			
			println template.toString()
						
			if(export){
				Cookie cookie = new Cookie("fileDownload","true")
				cookie.maxAge = 10
				cookie.setPath("/")
				response.addCookie(cookie)
				ExportController exporter = new ExportController();
				exporter.export(db.rows(template.toString()),fileName)
			}else{
				render db.rows(template.toString()) as JSON
				//render template.toString() 
			}

		}else{
			if(export && export != "html" && export != "file"){
				Cookie cookie = new Cookie("fileDownload","true")
				cookie.maxAge = 10
				cookie.setPath("/")
				response.addCookie(cookie)
				ExportController exporter = new ExportController();
				exporter.export(db.rows(fileContents),fileName)
			}else if(export == "html"){
				HtmlCreateController htmlOutput = new HtmlCreateController()
				htmlOutput.outPutHTML(db.rows(fileContents))
			}else if(export=="file" && fileName != null){
			
				def siteRootPath = grailsAttributes.getApplicationContext().getResource("").getFile().toString()+File.separator
				def fileToWrite = siteRootPath+fileName
				def iCnt = 0
				
				
				
				File file = new File(fileToWrite)
				if (file.exists()) {
					assert file.delete()
					assert file.createNewFile()
				}
				
				boolean append = true
				FileWriter fileWriter = new FileWriter(file, append)
				BufferedWriter buffWriter = new BufferedWriter(fileWriter)
				
				
				db.eachRow(fileContents){ row ->
					
					def rowCollect
					def lineString = ""
					def columnString = ""
					
					if(iCnt==0){
						rowCollect = row.toRowResult().keySet()
						rowCollect.each(){
							lineString += "\""+it+"\","
						}
						buffWriter.write(lineString)
						//out.writeLine(lineString)
						lineString = ""
					}
				
					rowCollect = row.toRowResult()
					
					rowCollect.each(){ k, v ->
						columnString = v.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '')
						lineString += "\""+columnString+"\","
					}
					
					buffWriter.write(lineString)
					
					iCnt++
				}
				
				
				buffWriter.flush()
				buffWriter.close()
				

				render "<a href=\""+request.contextPath+"/"+fileName+"\">Success</a>"
			}else{
				render db.rows(fileContents) as JSON
			}
		}

	}
		
	def dev(){
		if(params?.sqlFile){
			def db = new Sql(dataSource_dev)	
			processParams(db,false,false)
		}
	}
	
	
	
	def processMapCreation(key,value,map){
		
		def comparision = ['<','>','=','<=','>=']
		
		if(value.getClass().isArray()){
			if(key in params.omitDataType || key.equals(params.omitDataType)){
				map.put(key,value.join(","))
			}else if(value.toString() in comparision){
				map.put(key,value.join(","))
			}else if(!value.toString().isNumber()){
				map.put(key,"'"+value.join("','")+"'")
			}else{
				map.put(key,value.join(","))
			}
		}else{
			map.put(key,value)
		}
		
	}
}
