package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class Greendot_oigsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [greendot_oigsInstanceList: Greendot_oigs.list(params), greendot_oigsInstanceTotal: Greendot_oigs.count()]
    }

    def create() {
        [greendot_oigsInstance: new Greendot_oigs(params)]
    }

    def save() {
        def greendot_oigsInstance = new Greendot_oigs(params)
        if (!greendot_oigsInstance.save(flush: true)) {
            render(view: "create", model: [greendot_oigsInstance: greendot_oigsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), greendot_oigsInstance.id])
        redirect(action: "show", id: greendot_oigsInstance.id)
    }

    def show() {
        def greendot_oigsInstance = Greendot_oigs.get(params.id)
        if (!greendot_oigsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_oigsInstance: greendot_oigsInstance]
    }

    def edit() {
        def greendot_oigsInstance = Greendot_oigs.get(params.id)
        if (!greendot_oigsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_oigsInstance: greendot_oigsInstance]
    }

    def update() {
        def greendot_oigsInstance = Greendot_oigs.get(params.id)
        if (!greendot_oigsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (greendot_oigsInstance.version > version) {
                greendot_oigsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'greendot_oigs.label', default: 'Greendot_oigs')] as Object[],
                          "Another user has updated this Greendot_oigs while you were editing")
                render(view: "edit", model: [greendot_oigsInstance: greendot_oigsInstance])
                return
            }
        }

        greendot_oigsInstance.properties = params

        if (!greendot_oigsInstance.save(flush: true)) {
            render(view: "edit", model: [greendot_oigsInstance: greendot_oigsInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), greendot_oigsInstance.id])
        redirect(action: "show", id: greendot_oigsInstance.id)
    }

    def delete() {
        def greendot_oigsInstance = Greendot_oigs.get(params.id)
        if (!greendot_oigsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "list")
            return
        }

        try {
            greendot_oigsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'greendot_oigs.label', default: 'Greendot_oigs'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
