package serviceportal

import com.bankofamerica.gwbio.ia.LDAPFunctions.*
import grails.converters.JSON
import javax.servlet.http.Cookie

class LoginController {

    def index() { 
		
		/*
		 * LEGACY LOG IN CODE...
		 */
		redirect(uri: params.urlTarget)
		
		/*
		def loginResponse = [:]
		def authorised = false
				
		
		if(params.user && params.password){
			LDAPLogin login = new LDAPLogin();
			int pass = login.authenticateWithLDAP(params.user, params.password);
						
			switch(pass){
				case 1: case 2:
					loginResponse.put("Login","Error")
					loginResponse.put("Text","Please enter a correct username (nbk)")
					break
				case 3: case 5:
					loginResponse.put("Login","Error")
					loginResponse.put("Text","Please enter a correct password")
					break
				case 4:
					session["user"] = params.user
					session["email"] = login.getEmail()
					session["name"] = login.getName()
					loginResponse.put("Login","Success")
					loginResponse.put("user",session["user"])
					loginResponse.put("email",session["email"])
					loginResponse.put("name",session["name"])
					Cookie cookieLogin = new Cookie("GWBIOServicePortalLogin",session["user"])
					cookieLogin.maxAge = 60*60*24*14
					response.addCookie(cookieLogin)
					authorised = true
					break
				default:
					loginResponse.put("Login","Error")
					loginResponse.put("Text","Please enter login credentials")
					break
					
			}
		}else{
			loginResponse.put("Login","Attempt")
			loginResponse.put("Text","Please enter login credentials")
		}
		
		if(params.json){
			render loginResponse as JSON
		}else{
			if(!authorised){
				[loginResponse:loginResponse, urlTarget:params.urlTarget]
			}else if(params.urlTarget && authorised){		
			}else{
				[loginResponse:loginResponse, urlTarget:params.urlTarget]
			}
		}
		*/
	}
	
	def loggedIn(){
		def returnMap = [:]
		def cookieLogin = request.cookies.find { it.name == 'GWBIOServicePortalLogin' }
			
		if(session["user"]){
			returnMap.put('user', session["user"])
			returnMap.put('email', session["email"])
			returnMap.put('name', session["name"])
		}else if(cookieLogin!=null && !session["user"]){
			println "validating via cookie: "+cookieLogin.getValue()
			LDAPSearch search = new LDAPSearch(cookieLogin.getValue());
			def ldapValues = search.getResultsList().get(0)
			session['username'] = ldapValues.get("uid")
			session['email'] = ldapValues.get("mail")
			session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			returnMap.put('user', session["user"])
			returnMap.put('email', session["email"])
			returnMap.put('name', session["name"])
		}else{
			returnMap.put('error', true)
			returnMap.put('message', "User not logged in")
		}
		render returnMap as JSON
	}
	
	
	def logout(){
		session.invalidate()
		killCookie()
		def JSONresponse = [:]
		JSONresponse.put("Logout","Success")
		render JSONresponse as JSON
	}
	
	
	def killCookie(){
		def userCookie = request.cookies.find { it.name == 'GWBIOServicePortalLogin' }
		
		if(userCookie){
			userCookie.setMaxAge(0);
			response.addCookie(userCookie)
		}
		
		
	}
	
	def grailsindex(){
		
	}
	
	def searchAssociate(){
		def results
		if(params.searchName){
			   LDAPSearch search = new LDAPSearch();
			   search.LDAPComplexSearch(params.searchName);
			   results = search.getResultsList()
		}else{
					  results = [:]
					  results.put("Error", "No search term")
		}
		
		render results as JSON
 
	}
	
	def searchAssociateFromEmail(){
		def results
		if(params.id){
			LDAPSearch search = new LDAPSearch();
			search.emailSearch(params.id);
			results = search.getResultsList()
			if(results.size()==0){
				results = [:]
				results.put("Error", "No results for "+params.id)
			}
		}else{
			results = [:]
			results.put("Error", "No search term")
		}
		
		render results as JSON

	}
	
	def searchAssociateFromID(){
		def results
		if(params.id){
			LDAPSearch search = new LDAPSearch(params.id);
			results = search.getResultsList()
			if(results.size()==0){
				results = [:]
				results.put("Error", "No results for "+params.id)
			}
		}else{
			results = [:]
			results.put("Error", "No search term")
		}
		
		render results as JSON

	}
 
	
}
