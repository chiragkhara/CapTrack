package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import java.text.DateFormat
import java.text.SimpleDateFormat

class IncidentsController {
	def dataSource_ReadOnly
    def index() { 
		
		//render params.id
		//def mxoImIncidents = MxoImIncidents.getAll(params.id)
		def mxoImIncidents = MxoImIncidents.findAllByTicketid(params.id)
		def appList = []
		mxoImIncidents.each{
			if(it?.baaitnumber){
				appList.add(it.baaitnumber)
			}
			if(it?.baaitnumberDirect){
				appList.add(it.baaitnumberDirect)
			}
		}
		
		def appRtnList = []
		appList.each{
			def appId = Integer.parseInt(it)
			def appInstance = Application.read(appId)
			if(appInstance != null){
				appInstance.appStatusFlag = changeStatusToText(appInstance.appStatusFlag)
				appRtnList.add(appInstance)
			}
		}
		
		def results = [:]
		results.incident = mxoImIncidents[0]
		results.applications = appRtnList
				
		render results as JSON
		
	}
	
	def dateSearchIM(){
		if(params?.imDate){
			
			def queryString = """\
				select
				mxo_im_incidents.ticketid as Ticket,
				CASE WHEN `AIT #` is null THEN 'No' ELSE 'Yes' END as `UCAL App`,
				GROUP_CONCAT(distinct MDH_AIT.AIT_AITSHORTNAME SEPARATOR  ',  ') as AITSHORTNAME,
				COALESCE(gwbioreporting_pgp_servicearea.SERVICEAREA, 'N/A') as SERVICEAREA,
				/*mxo_im_incidents.DESCRIPTION,*/
				Cast(concat(mxo_im_incidents.REPORTEDPRIORITY,'|',mxo_im_incidents.BAURGENCY,'|', mxo_im_incidents.BAIMPACT) as char) as `P.U.I`,
				mxo_im_incidents.REPORTDATE,mxo_im_incidents.createdby
				FROM extdb.mxo_im_incidents
				JOIN (
				  select ticketid from hotpdb.dsrtickets
				  WHERE
				  CASE WHEN STR_TO_DATE('"""+params.imDate+"""','%D-%b-%Y') = DATE(NOW())
				           THEN DATE(targetfinish) = STR_TO_DATE('"""+params.imDate+"""','%D-%b-%Y') OR targetfinish IS NULL
				           ELSE DATE(targetfinish) = STR_TO_DATE('"""+params.imDate+"""','%D-%b-%Y')
				  END
				"""
			if(params?.ServiceArea){
				if(params.ServiceArea=="" || params.ServiceArea.length()==0){
					queryString += "AND ServiceArea is null"
				}else{
					queryString +="AND ServiceArea = '"+params.ServiceArea+"'"
				}
			}else{
				queryString += "AND ServiceArea = 'N/A'"
			}	
						   
				 
			queryString += """) dsrTickets ON mxo_im_incidents.ticketid = dsrTickets.ticketid
				JOIN extdb.mdh_ait ON mxo_im_incidents.baaitnumber = mdh_ait.AIT_CILABEL OR mxo_im_incidents.baaitnumber_direct = mdh_ait.AIT_CILABELL
				LEFT JOIN extdb.gto_ucal on mdh_ait.AIT_CILABEL = gto_ucal.`AIT #`
				LEFT JOIN hotpdb.gwbioreporting_pgp_servicearea ON mxo_im_incidents.BAACCOUNTABLEGROUP = gwbioreporting_pgp_servicearea.PGP
				group by mxo_im_incidents.ticketid
				order by gwbioreporting_pgp_servicearea.SERVICEAREA, mxo_im_incidents.REPORTDATE
				"""
	
			println queryString	
			def db = new Sql(dataSource_ReadOnly)
			render db.rows(queryString) as JSON
		}
		
	}
	
	def searchIM(){
		if(params?.id){
			def mxoImIncidents = MxoImIncidents.executeQuery("select distinct ticketid from MxoImIncidents where ticketid like ?",[params.id+"%"],[max: 10, offset: 0])
			render mxoImIncidents as JSON
		}else{
			def err = [:]
			err.error = "No IM entered"
			return err as JSON
		}
	}
	
	
	def getRelated(){
		if(params.id){
			def related = MxoRelRelatedrecords.findAllByRecordkey(params.id,[sort: "relatedrecclass"])
			[related: related]
			
		}
	}

	
	def byApplication(){
		
		def endDate, startDate
		if(params?.startDate==null && params?.endDate==null){
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			Calendar originalDate = Calendar.getInstance();
			
			endDate =  dateFormat.format(originalDate.getTime());
			startDate = dateFormat.format(originalDate.getTime() - 7)

		}else{
			endDate =	params.endDate
			startDate =	params.startDate
		}
		
		def AIT_ID = params.id
		
		
		def endDateDT = endDate+" 23:59:59"
		def startDateDT = startDate+" 00:00:00"
		

		
		def queryStringTable = "SELECT ticketid as Ticket, ait_id as AIT, DATE_FORMAT(creationdate, '%Y-%m-%d %H:%i') as Date, Severity from hotpdb.gwbio_application_incidents WHERE ait_id = ${AIT_ID} group by ticketid order by DATE_FORMAT(creationdate, '%Y-%m'), Severity"
		def queryStringChart = """\
			SELECT DATE_FORMAT(creationdate, '%m-%Y') as date, 
			SUM(CASE  when severity = 2 THEN 1 ELSE 0 END) sev2,
			SUM(CASE when severity = 1 THEN 1 ELSE 0 END) sev1
			from (select * from hotpdb.gwbio_application_incidents WHERE ait_id = ${AIT_ID} group by ticketid) incidents
			group by date
			order by creationdate
		"""


		def db = new Sql(dataSource_ReadOnly)

		def results = [:]
		results.chart = db.rows(queryStringChart)
		results.table = db.rows(queryStringTable)
		results.appName = params.appName
		render results as JSON
		
	}
	
	def changeStatusToText(appFlag){
		switch (appFlag) {
			case 'D':
				return 'In Development'
				break;
			case 'P':
				return 'In Production'
				break;
			case 'R':
				return 'Decomissioned'
				break;
			case 'RAD':
				return 'Retain App & Data'
				break;
			case 'RD':
				return 'Retain Data'
				break;
			case 'S':
				return 'Projected Retire'
				break;
			case 'T':
				return 'Retired'
				break;
			default:
				return 'Status not coded for!'
				break;
		}
	}
	
def monitorDataCumulate(){
	def sqlString = "select CAST(CONCAT(YEAR(timestamp),'-', MONTH(timestamp),'-',DAYOFMONTH(timestamp),'-',HOUR(timestamp)) as CHAR) as dt"
	
	def frmDate = params.frmDate 
	def toDate = params.toDate
	
	
	if(params?.id.getClass().isArray()){
		def queryIN = ""
		def iCnt = 0
		
		params.id.each {
			sqlString += ", ROUND(AVG(IF(id_Monitor = "+it+", value, NULL)),1) AS '"+it+"' "
			
			if(iCnt>0){ queryIN += "," }
			queryIN += it
			iCnt++
		}
		
		sqlString += "	from arhms.monitordata where id_Monitor IN (${queryIN})"			
		
	}else{
		def monitorID = params.id
		sqlString += """\
			, ROUND(AVG(IF(id_Monitor = ${monitorID}, value, NULL)),1) AS '${monitorID}'
			from arhms.monitordata where id_Monitor = ${monitorID} """

	}
	
	if(frmDate!=null && toDate !=null){
		sqlString += " and timestamp between '"+frmDate+"' AND '"+toDate+"'"
	}else{
		sqlString += " and timestamp >= NOW() - INTERVAL 1 DAY"
	}
	
	sqlString += """\
		group by dt
		order by timestamp desc """
	
	println sqlString
	def db = new Sql(dataSource_ReadOnly)
	render db.rows(sqlString) as JSON
	
}
	
}
