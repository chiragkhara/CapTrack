package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class IadbDataController {

	def dataSource_ReadOnly
	
	def pgpLookup(){

		def searchTerm
		if(!params.id.toString().toUpperCase().startsWith("PGP") && !params.id.toString().toUpperCase().startsWith("TGP")){
			searchTerm = "PGP"+params.id.toString()
		}else{
			searchTerm = params.id.toString()
		}
		
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT pgp_num, pgp_desc
					FROM extdb.mxo_persongroup_persons
					where pgp_num like '"""+searchTerm.toUpperCase()+"""%'
					GROUP BY pgp_num
					order by pgp_num
					limit 10
					"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def serviceareas(){
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					select servicearea 
					from hotpdb.gwbioreporting_pgp_servicearea_list 
					order by servicearea
					"""
		def result = db.rows(queryString)
		render result as JSON
		
	}
	
	
	def fhierarchyfourdot(){
		def searchTerm = params.id
		def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					SELECT  FOURDOT
					FROM extdb.mdh_cto
					where FOURDOT like '"""+searchTerm.toUpperCase()+"""%'
					group by FOURDOT
					order by FOURDOT
					limit 10
					"""
		def result = db.rows(queryString)
		render result as JSON
	}
}
