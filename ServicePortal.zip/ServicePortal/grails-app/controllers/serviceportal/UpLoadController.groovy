package serviceportal

class UpLoadController {

    def index() { 

			
	}
	
	
	def upload() {
		println "hit"
		
		
		def f = request.getFile('myFile')
		if (f.empty) {
			flash.message = 'file cannot be empty'
			render(view: 'uploadForm')
			return
		}
			
		def dest = "/tmp/"+f.getOriginalFilename()
		def fDest = new File(dest)
		f.transferTo(fDest)
		def sizeMb = fDest.length() / (1024L * 1024L)
		def sizeMbRounded = Math.round(sizeMb * 100.0) / 100.0;
		render f.getOriginalFilename()+ " completed, "+(sizeMbRounded)+" Mb"

	}
}
