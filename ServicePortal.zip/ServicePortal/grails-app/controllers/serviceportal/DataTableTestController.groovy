package serviceportal

import grails.converters.JSON

class DataTableTestController {

    def index() { 
		
		def iDisplayStart = 0
		def iDisplayLength = 9
		
		if(params.iDisplayStart && params.iDisplayLength){
			iDisplayStart = params.iDisplayStart.toInteger()
			iDisplayLength = params.iDisplayLength.toInteger()+iDisplayStart
			
		}
		
		def objects = dataConstruct()
		
		println objects
		
		def val = []
		objects.get('aaData')[iDisplayStart..iDisplayLength].each { val << it }
		objects['aaData'] = val
		
		
		//objects['iTotalDisplayRecords'] = iDisplayLength-iDisplayStart
		if(params.sEcho){
			objects['sEcho'] = params.sEcho.toInteger()
		}
		
		println objects
		
		render objects as JSON
		
		
	}
	
	
	def dataConstruct(){
		def dataRtn = [:]
		def dataMain = []
		
		for (i in 0..50) {
			dataMain.add(['name':'Number:'+i,'value':i])
		}
		
		dataRtn['aaData'] = dataMain
		dataRtn['iTotalRecords'] = dataMain.size()
		dataRtn['iTotalDisplayRecords'] = dataMain.size()
		dataRtn['aoColumns'] = []
		dataRtn['aoColumns'].add(['mData':'name','sTitle':'name'])
		dataRtn['aoColumns'].add(['mData':'value','sTitle':'value'])
		dataRtn['sAjaxSource'] = params.controller
		dataRtn['bDeferRender'] = true
		dataRtn['bServerSide'] = true
		dataRtn['iDeferLoading'] = dataMain.size()
		
		return dataRtn

	}
}
