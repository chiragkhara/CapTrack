package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class Mdh_mw_dnp_lookupController {

    def dataSource
	
    def index() { 
		//def db = new Sql(dataSource_ReadOnly)
		//def queryDistinctEARCProducts = "SELECT ProductID, ProductName, FriendlyName, VendorName, classification FROM extdb.earc_mw_product_list ORDER BY ProductName"
		
		def allMapped = Mdh_mw_dnp_lookup.findAllByEarc_idIsNotNull() as JSON
		def allUnmapped = Mdh_mw_dnp_lookup.findAllWhere(earc_id: null)  as JSON
		
		def tableColumns = ['id':'id','mwinstance_product_name':'Product','mwinstance_product_version': 'Version', 'instancecount': 'Number'] as JSON
		def mapColumns = ['id':'id','mwinstance_product_name':'Product','mwinstance_product_version': 'Version', 'earc_productname': 'EARC Product'] as JSON
		def messageFields = ['Product','Version'] as JSON
		
		render(view:"/mdh_mapping_view/index",model:[allMapped: allMapped, allUnmapped: allUnmapped,tableColumnsMap:tableColumns,messageFields:messageFields,mapColumns:mapColumns,dataType:'Middleware'])
		
	}
	
	def updateMappingData(){
		def db = new Sql(dataSource)
		
		def insertsQueryString = """\
		INSERT INTO extdb.mdh_mw_dnp_lookup (MWINSTANCE_PRODUCT_NAME, MWINSTANCE_PRODUCT_VERSION, instanceCount) 
		select 
			mdh_mw.MWINSTANCE_PRODUCT_NAME,
			mdh_mw.MWINSTANCE_PRODUCT_VERSION,
			count(distinct mdh_compsys.COMPSYS_CMSCIID) as instanceCount
		FROM extdb.mdh_compsys
		INNER JOIN extdb.mdh_app_compsys_rel ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
		INNER JOIN extdb.mdh_ait mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
		INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
		INNER JOIN extdb.mdh_compsys_mw_rel ON mdh_compsys_mw_rel.REL_COMPSYS = mdh_compsys.COMPSYS_CMSCIID
		INNER JOIN extdb.mdh_mw ON mdh_compsys_mw_rel.REL_MW = mdh_mw.MWINSTANCE_CMSCIID
		LEFT JOIN extdb.mdh_mw_dnp_lookup 
			ON mdh_mw.MWINSTANCE_PRODUCT_NAME = mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_NAME 
			AND mdh_mw.MWINSTANCE_PRODUCT_VERSION = mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_VERSION 
		WHERE mdh_compsys.compsys_status IN ('IN USE', 'MAINTENANCE') and COMPSYS_FQDN != 'MAINFRAME' 
		and mdh_compsys.COMPSYS_OSNAME IS NOT NULL
		AND mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_NAME IS NULL 
		AND mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_VERSION is null 
		GROUP BY mdh_mw.MWINSTANCE_PRODUCT_NAME,mdh_mw.MWINSTANCE_PRODUCT_VERSION"""


		def updatesQueryString = """\
		UPDATE extdb.mdh_mw_dnp_lookup
		JOIN(
		  select 
		  mdh_mw.MWINSTANCE_PRODUCT_NAME,
			mdh_mw.MWINSTANCE_PRODUCT_VERSION,
		  count(distinct mdh_mw.MWINSTANCE_CMSCIID) as instanceCount
		  FROM extdb.mdh_os_dnp_lookup
		  INNER JOIN extdb.mdh_compsys ON mdh_os_dnp_lookup.COMPSYS_OSNAME = mdh_compsys.COMPSYS_OSNAME
		  INNER JOIN extdb.mdh_app_compsys_rel ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
		  INNER JOIN extdb.mdh_ait mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
		  INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
		  INNER JOIN extdb.mdh_compsys_mw_rel ON mdh_compsys_mw_rel.REL_COMPSYS = mdh_compsys.COMPSYS_CMSCIID
		  INNER JOIN extdb.mdh_mw ON mdh_compsys_mw_rel.REL_MW = mdh_mw.MWINSTANCE_CMSCIID
		  WHERE mdh_compsys.compsys_status IN ('IN USE', 'MAINTENANCE') and COMPSYS_FQDN != 'MAINFRAME' 
		  GROUP BY mdh_mw.MWINSTANCE_PRODUCT_NAME,mdh_mw.MWINSTANCE_PRODUCT_VERSION
		) mwCount 
		ON mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_NAME = mwCount.MWINSTANCE_PRODUCT_NAME 
		AND mdh_mw_dnp_lookup.MWINSTANCE_PRODUCT_VERSION = mwCount.MWINSTANCE_PRODUCT_VERSION 
		SET mdh_mw_dnp_lookup.instanceCount = mwCount.instanceCount
		WHERE mdh_mw_dnp_lookup.instanceCount != mwCount.instanceCount"""
		
		def returnMap
		try {
			def insertsDone = db.execute(insertsQueryString)
			def updatesDone = db.executeUpdate(updatesQueryString)
			returnMap = [insert:insertsDone,updates:updatesDone]
		} catch(Exception e){
			returnMap = [errror:e.getMessage()]
		}
		

		render returnMap as JSON
		
		
	}
	
	def unmapped(){
		def allUnmapped = Mdh_os_dnp_lookup.findAllWhere(dnpStatus: null)
		render allUnmapped as JSON
	}
	
	
	def saveMapping(){
		def returnJSON = [:]
		def record = Mdh_mw_dnp_lookup.get(params.id)
		if(record){
			record.properties = params
		}
		
		if (!record.save(flush: true)) {
			returnJSON.put('error',true)
			returnJSON.put('details',record.errors)
			record.errors.each {
			   println it
			}
		}else{
			returnJSON.put('success',true)
			returnJSON.put('details','Save for '+record.mwinstance_product_name+" "+record.mwinstance_product_version+' complete')
		}
		
		render returnJSON as JSON
	}
}
