package serviceportal

class ExportController {

	def index(){
		
	}
	
	
    def export(ObjectPassed, title) { 
		
		def date = new Date()
		def formattedDate = date.format('yyyyMMdd_HHmm')

		def filename = title+"_"+formattedDate 


		
			response.setHeader("Content-disposition", "attachment; filename=${filename}.csv")
			response.contentType = "application/vnd.ms-excel"
			
			def outs = response.outputStream
							
			/*************************************************
			//TO DO - TEST IF OBJECT PASSED IS GroovyRowResult or DOMAIN OBJECT - then deal with it differently
			//TO DO - CHECK DATA TYPE OF COLUMNS...IF Date - change to text
			***************************************************/
			
			
			//pass all GroovyRowResult to an array of maps
			def arry = []
			ObjectPassed.each {
				def map = [:]
				map.putAll(it)
				arry.add(map)
			}
			
			
			//Push titles to output
			arry[0].each() { key, value ->
				outs << "\""+key+"\","
			}
			
			outs << "\n"
			
			//Push values to output
			arry.each() { 
				it.each(){ key, value ->					 
					value = value.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '') 
					outs << "\""+value+"\","
				}
				
				outs << "\n"
			};
		
			
			outs.flush()
			outs.close()

	}
}
