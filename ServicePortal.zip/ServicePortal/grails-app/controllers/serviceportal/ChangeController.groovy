package serviceportal

import java.sql.Timestamp
import java.text.DateFormat
import java.text.SimpleDateFormat
import grails.converters.JSON
import groovy.sql.Sql


class ChangeController {
	def dataSource_ReadOnly
	
	def test(){
		def changes = Change.findAllById('6888359')
		render changes as JSON
		
	}
	
	def getLOB(){
		if(params?.id){
			Date date = new Date();                      // timestamp now
			Calendar cal = Calendar.getInstance();       // get calendar instance
			cal.setTime(date);                           // set cal to date
			cal.set(Calendar.HOUR_OF_DAY, 0);            // set hour to midnight
			cal.set(Calendar.MINUTE, 0);                 // set minute in hour
			cal.set(Calendar.SECOND, 0);                 // set second in minute
			cal.set(Calendar.MILLISECOND, 0);            // set millis in second
			Date zeroedDate = cal.getTime();             // actually computes the new Date
			
			Calendar previousWeek = (Calendar) cal.clone();
			previousWeek.add(Calendar.DAY_OF_MONTH, 7);
			Date nextWeek = previousWeek.getTime();
			
			DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			def startDate = dateFormat.format(zeroedDate.getTime());
			def endDate = dateFormat.format(nextWeek.getTime());
		
		
			def db = new Sql(dataSource_ReadOnly) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
			def queryString = """\
						 select a.*, count(distinct(b.ait_number)) AS ciCount, COALESCE(activitiesTable.activityCount,0) AS activityCount
						from extdb.mxo_ch_changes a 
						left join extdb.mxo_ch_allact_ci_aits b on a.wonum=b.ancestor
						inner join hotpdb.hotpgroupaits c on b.ait_number=c.ait_id 
						inner join hotpdb.hotpgroups d on c.hotpgroup_id=d.id 
						LEFT JOIN (
						            SELECT COUNT(taskid) AS activityCount, ancestor
						            FROM extdb.mxo_ch_woactivities
						            GROUP BY ancestor, taskid
						        ) AS activitiesTable
						        ON activitiesTable.ancestor = a.wonum
						
						where b.ci_classification='APPLICATION' and a.status IN ('APPR', 'WAPPR') 
						and d.id = ${params.id} 
						and a.changedate between ${startDate} and ${endDate}
						group by a.wonum 
						order by a.changedate desc """
			
			//render queryString
			def result = db.rows(queryString)
			render result as JSON
			/*def woArray = []
			result.each(){
				woArray.add(it.wonum)
			}
			render showLOB(woArray) as JSON*/
		}
		
	}
	
    def showLOB(WOArray) { 
				
			
			//def changes = Change.findAll("from Change where changedate between :startDate and :endDate",[startDate:zeroedDate, endDate:endDateCal],[sort: "changedate", order: "asc"])		
			def changes = Change.findAll("from Change where wonum IN (:woArray)",[woArray:WOArray],[sort: "changedate", order: "asc"])
			
			return changes	
	}
	
	def cis(){
		if(params?.id){
			def changeRec = Change.findById(params.id)
			//def cis = ChangeCI.findAllWhere(change: changeRec)	
			def cis = ChangeCI.findAll("from ChangeCI where change = :changeInstance and id in (:AITList) group by id",[changeInstance: changeRec, AITList: getHotPAITs()])
			if(cis.size()==0){
				render "No CIs associated to this Change"
			}else{
				[cis: cis]
			}
		}
	}

	def getHotPAITs(){
		def hotpGroups = Hotpgroupaits.executeQuery("select concat(aitId) from Hotpgroupaits where hotpgroupIdHotpgroups IN (20,23,24,25)")
		return hotpGroups
	}
	
	def cisTest(){
		def hotpGroups = Hotpgroupaits.executeQuery("select concat(aitId)  from Hotpgroupaits where hotpgroupIdHotpgroups IN (20,23,24,25)")
		render hotpGroups as JSON
	}
	
	
	def activities(){
		if(params?.id){
			def change = Change.findById(params.id)
			def activities = ChangeActivity.findAllByChange(change)
			if(activities.size()==0){
				render "No Activities associated to this Change"
			}else{
				[activities: activities]
			}
		}
	}
	
}
