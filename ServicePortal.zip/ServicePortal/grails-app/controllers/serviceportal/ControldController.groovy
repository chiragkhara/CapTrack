package serviceportal

import groovy.sql.Sql
import groovy.text.SimpleTemplateEngine

class ControldController {
	def dataSource_ReadOnly
	
    def index() { }
	
	def metrics(){
		
		if(params?.sqlFile){
			def db = new Sql(dataSource_ReadOnly)
			MetricsLoaderController metrics = new MetricsLoaderController()
			metrics.processParams(db,params.export,params.fileName)
		}
		
		
	}
}
