package serviceportal
import grails.converters.JSON
class ProblemController {

    def index() { 
		if(params?.id){
			def problemRec = MxoPmProblems.findById(params.id)
			def results = [:]

			problemRec.properties.each() { key, value -> results.put(key, value) };
	
			def activities = MxoPmProblemActivities.findAllByOrigrecordid(problemRec.id,[sort: "balastupdate",order: "desc"])
			results.putAt("CARS", activities)
			results.putAt("id", params.id)
			
			render results as JSON
		}
	}
	
	def searchPMObj(){
		def mxoPmProblems = MxoPmProblems.findAll("from MxoPmProblems where id LIKE ?",[params.id+"%"],[max: 10, offset: 0])
		render mxoPmProblems as JSON
	}
	
	def searchPM(){
		if(params?.id){
			def mxoPmProblems = MxoPmProblems.executeQuery("select distinct id from MxoPmProblems where id like ?",[params.id+"%"],[max: 10, offset: 0])
			render mxoPmProblems as JSON
		}else{
			def err = [:]
			err.put("error", "No IM entered")
			return err as JSON
		}
	}
	
	
	def copyProperties(source, target) {
	    source.properties.each { key, value ->
	        if (target.hasProperty(key) && !(key in ['class', 'metaClass'])) 
	            target[key] = value
	    }
	}
	
	def incident(){
		if(params?.id){
			def related = MxoRelRelatedrecords.findAllByRecordkeyAndRelatedrecclass(params.id,'PROBLEM')
			def relatedINArray = []
			related.each(){
				relatedINArray.add(it.relatedreckey)	
			}
			def problemRecs = MxoPmProblems.findAll("from MxoPmProblems where id (:INArray)", INArray:relatedINArray)
			render problemRecs as JSON
		}
		
	}
}
