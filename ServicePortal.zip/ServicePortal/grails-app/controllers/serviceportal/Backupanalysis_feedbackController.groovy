package serviceportal

import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import grails.converters.JSON

class Backupanalysis_feedbackController {

    def index() { }
	
	def beforeInterceptor = [action: this.&auth]
	
	private auth() {
		
		/*def cookieLogin = request.cookies.find { it.name == 'GWBIOServicePortalLogin' }
		if(!session["user"] && cookieLogin!=null){
			LDAPSearch search = new LDAPSearch(cookieLogin.getValue());
			def ldapValues = search.getResultsList().get(0)
			session['username'] = ldapValues.get("uid")
			session['email'] = ldapValues.get("mail")
			session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			return true
		}else if(!session["user"]){
			def errResponse = ['error':true, 'message':'You are not logged in']
			render errResponse as JSON
			return false
		}else if(session["user"]){
			return true
		}*/
		
		if(!session['username']){
			def sso = new AuthSSOController()
			sso.index()
			if(session['username']){
				return true
			}else{
				return false
			}
		}else if(session['username']){
			return true
		}
		
	}
	
	
	def hasChanged(mapOne, mapTwo, ignoreProps){
		def hasChanged = false
			
		if(mapOne!=null){
			mapTwo.each{k,v->
				//println k+" | " + mapOne[k].toString().trim()+ " : "+v.toString()
				if(!mapOne[k].toString().trim().equals(v.toString().trim()) && !ignoreProps.contains(k)){
					hasChanged = true
				}			
			}
		}else{
			hasChanged = true
		}
		
		return hasChanged
	}
	
	def submit(){
		def aitNumber = null
		if(params.AITNUMBER && !params.AITNUMBER.toString().equals("undefined")){
			aitNumber = params.AITNUMBER.toString().toInteger()
		}
		
		
		def submitter = session["email"]
		
		params.remove("action")
		params.remove("controller")
		params.remove("AITNUMBER")
		
		def policyMap = [:]
		def numberSubmitted = 0
		def numberSuccessful = 0

		
		println params
		
		params.each {
			def key = it.key.toString()
			def value = it.value.toString().trim()
			
			
			key = key.replaceAll("~\\|~", "\\.")
			value = value.replaceAll("~\\|~", "\\.")
			
			println key + " = " + value
			println it
			def isAIT = false
			def isUnderscore = key.indexOf('_')
			def questionId = null
		
			
			
			if(isUnderscore>-1){
				def firstChars = key.substring(0, isUnderscore)
				def stringAITQuestion = key.substring(isUnderscore+1,key.length())
				if(firstChars.isNumber() && stringAITQuestion.trim().equals("AITQuestion")){
					isAIT = true
					println "IS AIT: "+stringAITQuestion
					questionId = firstChars.toInteger()
				}
				
			}
			
				
			//is an AIT field
			if(isAIT){		
				if(!value.trim().equals("")){
					def questionRecord = Backupanalysis_answers.findByAitAndQuestionid(aitNumber,questionId)
					if(hasChanged(questionRecord,[answer:value],['submitter'])){
						if(questionRecord){
							questionRecord.answer = value
							questionRecord.submitter = submitter
						}else{
							questionRecord = new Backupanalysis_answers(questionid: questionId, ait:aitNumber, answer: value, submitter:submitter)
						}
						
						if (!questionRecord.save(flush: true)) {
						    questionRecord.errors.each {
						       // println it
						    }
						}else{
							numberSuccessful++
						}
						numberSubmitted++
					}
				}
			//BACKUP Comment	
			}else{
				def policyDetails = key.split("\\|\\|")
				def hostName = policyDetails[0].toString().trim()
				def policy = policyDetails[1].toString().trim()
				def type = policyDetails[2].toString().trim()
				def policyKey = hostName+policy
				def policyAdd = [:]
				policyAdd[type] = value.toString().trim()
				
				
				
				if(policyMap.containsKey(policyKey)){
					if(!value.empty){
						policyMap[policyKey].put(type, value)
					}
				}else{
					policyMap.put(policyKey,[:]) 
					policyMap[policyKey].put('hostname', hostName)
					policyMap[policyKey].put('policy', policy)
					if(!value.empty){
						policyMap[policyKey].put(type, value)
					}
				}	
				
				
			}
			
		}
		
		println policyMap
		def mapErrors = [:]
		
		policyMap.each {k,v->
					
			if(!v['rag'].toString().trim().empty || !v['comment'].toString().trim().empty){
				def analysisRecord = Backupanalysis_feedback.findByBackupid(k)
				def mapToSubmit = [backupid:k,status:v['rag'],comment:v['comment'],submitter:submitter,hostname: v['hostname'], policyname :v['policy'], retentioncode: v['retentionCode']]
				
		
				def recordActivity = false
				
				if(analysisRecord){
					if(hasChanged(analysisRecord.properties,mapToSubmit,['submitter'])){
						println "HAS CHANGED"
						println mapToSubmit
						analysisRecord.properties = mapToSubmit
						recordActivity = true
					}
				}else{
					println "RETNENT: "+v['retentionCode']
					if(v['rag']!=null || v['comment']!=null || v['retentionCode']!=null){
						analysisRecord = new Backupanalysis_feedback(backupid: k, hostname: v['hostname'], policyname :v['policy'], status: v['rag'], comment: v['comment'], retentioncode: v['retentionCode'], submitter:submitter)
						recordActivity = true
						println "NEW"
						println analysisRecord.properties
					}
				}
				
				if(recordActivity){
					if (!analysisRecord.save(flush: true)) {
						analysisRecord.errors.each {
							mapErrors.put(k, it.toString())
						    println it
						}
					}else{
						numberSuccessful++
					}
					numberSubmitted++
					println "******************"
					println analysisRecord
					println "******************"
				}
				
			}	
		}
		
		def rtnMessage = [submitted:numberSubmitted,successfull:numberSuccessful,errors:mapErrors]
		render rtnMessage as JSON
	}
}

