package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import groovy.text.SimpleTemplateEngine
import javax.servlet.http.Cookie

class MetricsLoaderFieldsController {
	def dataSource_ReadOnly, dataSource_ReadOnly_dev
	
    def index() { 
	
		if(params?.sqlFile){
			def db
			if(params.devDB){
				db = new Sql(dataSource_dev)
			}else{
				db = new Sql(dataSource_ReadOnly)
			}
			//def fPath = "/hosting/configs/tomcat7/hotp-dev-01/webapps/ServicePortal/"
			processParams(db,params?.export,params?.fileName)
		}
			
	}
	
	def processParams(db,export,fileName){

		def fPath =  request.getSession().getServletContext().getRealPath("/")	
		String fileContents = new File(fPath+params.sqlFile+'.sql').text
			
		params.remove('controller')
		params.remove('sqlFile')
		params.remove('action')
		
		//if(params.size()>0){

			def parameterMap = [:]
						
			//println params
			
			//println "**********************"
			
			params.sort{ it.key }
			
			//println params
			
			params.entrySet().each{
				/*if(it.value.getClass().isArray()){
					it.value.each{ s ->
						processMapCreation(it.key,s,parameterMap)
					}
				}*/
				//println it
				if(it.key!="omitDataType" && it.key!="action"){
					processMapCreation(it.key,it.value,parameterMap)
				}
			
			}
			
				
			if(parameterMap.size()>0){
				parameterMap.put('addWhere', true)
			}
			

			//println parameterMap
			
			//println "contain: "+parameterMap.containsKey("ait")
			
			def engine = new SimpleTemplateEngine()
			//def template = engine.createTemplate(fileContents).make(parameterMap.withDefault{ '' })
			
			def template = engine.createTemplate(fileContents).make(parameterMap.withDefault{ null })

			
			println template.toString()
			
			//return
			
			if(export){
				Cookie cookie = new Cookie("fileDownload","true")
				cookie.maxAge = 10
				cookie.setPath("/")
				response.addCookie(cookie)
				ExportController exporter = new ExportController();
				exporter.export(db.rows(template.toString()),fileName)
			}else{
				render db.rows(template.toString()) as JSON
			}


	}
		
	def dev(){
		if(params?.sqlFile){
			def db = new Sql(dataSource_ReadOnly_dev)	
			processParams(db,false,false)
		}
	}
	
	def processMapCreation(key,value,map){
		
		def comparision = ['<','>','=','<=','>=']
		
		
		println "*******************"
		println key + " "+ value
		println "*******************"
		
		//ADD an "AND" on to WHERE critieria
		if(map.size()>0){
			map.eachWithIndex(){  entry, index ->
				if(index==map.size()-1 && (params.autoAnd != null || params.autoAnd == false)){
					entry.value = entry.value+ " AND "
				}
			}
		}
		
				
		if(value.getClass().isArray()){
			if(key in params.omitDataType || key.equals(params.omitDataType)){
				map.put(key,'IN ('+value.join(",")+')')
			}else if(value[0].toString() in comparision){
				map.put(key,'IN ('+value.join(",")+')')
			}else if(!value[0].toString().isNumber()){
				map.put(key,"IN('"+value.join("','")+"')")
			}else{
				map.put(key,andString+'IN ('+value.join(",")+')')
			}
		}else{
			if(key in params.omitDataType || key.equals(params.omitDataType)){
				map.put(key,value)
			}else if(value.toString() in comparision){
				map.put(key,value)
			}else if(!value.toString().isNumber()){
				map.put(key," = '"+value+"'")
			}else{
				map.put(key," = "+value)
			}
		}
		
	}
}
