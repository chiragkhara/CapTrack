package serviceportal

import grails.converters.JSON

class WhoamiController {

    def index() { 
		
		def result = [:]
		result.put('address', request.getRemoteAddr())
		
		InetAddress addr = InetAddress.getByName(request.getRemoteAddr());
		String host = addr.getHostName();
		result.put('host', host)
		
		
		def userLogin = request.cookies.find { it.name == 'bofaidentity_cookie' }
		result.put('username2', userLogin)
		
		render "${params.callback}(${result as JSON})"
		
	}
}
