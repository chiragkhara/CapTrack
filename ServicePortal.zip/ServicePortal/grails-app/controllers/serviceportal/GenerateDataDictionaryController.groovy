package serviceportal

import groovy.sql.Sql
import groovy.io.FileType
import org.springframework.core.io.Resource

class GenerateDataDictionaryController {
	def dataSource
	
	def directory = null
	
    def index() { 

		if(!directory){
			setPath()
		}
		
		def dir = new File(directory)
		def listFiles = []
		dir.eachFileRecurse (FileType.FILES) { file ->
		  listFiles << ['table':file.getName().lastIndexOf('.').with {it != -1 ? file.name[0..<it] : file.name}]
		}
		
		def db = new Sql(dataSource)
		def getMeta= """\
			SELECT * FROM hotpdb.`iadb_datasources`
		"""
		def metaData = db.rows(getMeta)
		
		println listFiles
		
		listFiles.each { fileRef->
			def tableTrimName = fileRef.table.substring(fileRef.table.indexOf('.')+1)
			println tableTrimName
			metaData.each{
				if(tableTrimName.equals(it.table_name)){
					fileRef.description = it.data_source_description
					fileRef.data_source = it.data_source
				}
			}
		}
		
		[fileList: listFiles]
	}
	
	def setPath(){
		directory = request.getSession().getServletContext().getRealPath("").toString()+File.separator+"dataDictionary"
		return directory
	}
	
	def getPath(){
		render setPath()
		
	}
	
	def showTable(){
		if(!directory){
			setPath()
		}
		String fileContents = new File(directory+'/'+params.fileName+'.html').text.replaceFirst('<TABLE>', '<TABLE class="table table-striped table-bordered">')
		[fileContents: fileContents]
		//render text: fileContents, contentType:"text/html", encoding:"UTF-8"
	}
	
	def generateAll(){
		def db = new Sql(dataSource)
		def getTables = """\
			SELECT distinct TABLE_SCHEMA,TABLE_NAME
			FROM `INFORMATION_SCHEMA`.`COLUMNS`
			WHERE `TABLE_SCHEMA`IN('extdb')
			order by TABLE_NAME
		"""
		
		def tableList = db.rows(getTables)
		tableList.each{
			generateFile(it.TABLE_NAME,it.TABLE_SCHEMA,db)
		}
		
		def msg = '<a href="${controllerName}">All finished...</a>'
		render msg
	}
	
	def generateFile(tablename, schemaname, db){
		if(!directory){
			setPath()
		}
		println "Writing schema for ${schemaname}.${tablename}"
		def getColumns = """\
			SELECT COLUMNS.column_name, COLUMNS.column_type, COLUMNS.column_comment, COALESCE(STATISTICS.index_name,'') as Index_name
			FROM `INFORMATION_SCHEMA`.`COLUMNS` 
			LEFT JOIN INFORMATION_SCHEMA.STATISTICS ON COLUMNS.column_name = STATISTICS.column_name AND COLUMNS.TABLE_NAME = STATISTICS.TABLE_NAME
			WHERE COLUMNS.`TABLE_SCHEMA`='${schemaname}' 
			AND COLUMNS.`TABLE_NAME`='${tablename}'
			order by COLUMNS.ordinal_position
		"""
		
		def columnList = db.rows(getColumns)
		def tableHTML = '<TABLE>'
		columnList.eachWithIndex{ elem, index ->
			if(index==0){
				tableHTML <<= '<THEAD><TR>'
				elem.each{
					tableHTML <<= '<TH>'+it.key+'</TH>'
				}
				tableHTML <<= '</TR></THEAD><TBODY>'
			}
			
			tableHTML <<= '<TR>'
			elem.each{
				tableHTML <<= '<TD>'+it.value+'</TD>'
			}
			tableHTML <<= '</TR>'
			
		}
		tableHTML <<= '</TBODY></TABLE>'
		
		def tableFile = new File(directory+'/'+schemaname+'.'+tablename+'.html')
		tableFile.write(tableHTML.toString())
		println "DONE schema for ${schemaname}.${tablename}"
		
	}
}
