package serviceportal

class AitreviewController {

    def index() { }
}
