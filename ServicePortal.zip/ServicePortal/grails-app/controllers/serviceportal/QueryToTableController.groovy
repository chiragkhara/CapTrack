package serviceportal

import grails.converters.JSON
import groovy.sql.*
import java.sql.ResultSetMetaData
import javax.servlet.http.Cookie
import groovy.text.SimpleTemplateEngine

class QueryToTableController {

	def dataSource_ReadOnly
	
    def index() { 
		if(params.Export){
			def db = new Sql(dataSource_ReadOnly)
			def multiFields
			
			def groupByFields = checkWhereFieldsForAIT(params.fieldsSelected)
			if(groupByFields!=null){
				params.put("groupByFields", groupByFields)
			}
			
			if(params.WHEREFIELDS){
				multiFields = processWhereFields()
				params['multiFields'] = multiFields
				println "-->" + multiFields
			}
			
			if(params.System){
				params['Compsys'] = params.System
				params.remove('System')
			}
			
			def fileNameFilters = ""
			multiFields.each(){k,v ->
				fileNameFilters += "_"+k+"|"+v.replaceAll("\\W+", "")
			}
			
			def originalQuery = getQuery()
			def fileName = "IA_Download"//+fileNameFilters
			//LIMIT file name to 255 characters...
			def maxLength = (fileName.length() < 255)?fileName.length():255
			fileName = fileName.substring(0, maxLength);
			
			Cookie cookie = new Cookie("fileDownload","true")
			cookie.maxAge = 10
			cookie.setPath("/")
			response.addCookie(cookie)
			ExportController exporter = new ExportController();
			exporter.export(db.rows(originalQuery),fileName)
		}	
	}
	
	def checkWhereFieldsForAIT(fieldsSelected){
		
		//Get each WHEREFIELD prefix into array
		def fieldArray = fieldsSelected.split(",")
		def typeArray = []
		fieldArray.each{ 
			def prefixColumnType = it.toString().substring(0, it.toString().indexOf("_"))
			typeArray.add(prefixColumnType)
		}
			
		
		if(typeArray.contains("AIT")){
			return null
		}
		
		def returnGroup = ""
		def multiGroup = false
		
		if(typeArray.contains("COMPSYS")){
			returnGroup += "mdh_compsys.COMPSYS_CMSCIID"
			multiGroup = true
		}
		
		if(typeArray.contains("DBINSTANCE")){
			if(multiGroup){
				returnGroup += ","
			}
			returnGroup += "mdh_db_inst.DBINSTANCE_CMSCIID"
			multiGroup = true
		}
		
		if(typeArray.contains("MWINSTANCE")){
			if(multiGroup){
				returnGroup += ","
			}
			returnGroup += "mdh_mw.MWINSTANCE_CMSCIID"
		}
		
		return returnGroup
	
	}
	
	def paged(){	
		
		def iDisplayStart = 0
		def iDisplayLength = 9
		
		def db = new Sql(dataSource_ReadOnly)
		def multiFields
		def groupByFields = null
		
		groupByFields = checkWhereFieldsForAIT(params.fieldsSelected)
		if(groupByFields!=null){
			params.put("groupByFields", groupByFields)
		}
		
		println "_: _ "+ groupByFields
		println "_: ____>>> "+ params.groupByFields
		
		if(params.WHEREFIELDS){
			multiFields = processWhereFields()
			params['multiFields'] = multiFields			
		}
		
		if(params.System){
			params['Compsys'] = params.System
			params.remove('System')
		}
		
		def originalQuery = getQuery()
		
		println originalQuery
		def totalRows
		
		if(!params.recordCount || params.sSearch != null){
			def countQuery = getCountQuery(originalQuery)
			println "Count Query: "+countQuery
			def recordCount = db.rows(countQuery)
			totalRows = recordCount[0]['total']
		}else{
			totalRows = params.recordCount
		}
		
		
		
		def SQLQuery
		def metaDataObj = null
		def sqlObj
		
		
		if(params.metaGot){
			def metaDataData = getMetaParams()
			SQLQuery = appendQuery(originalQuery,iDisplayStart,iDisplayLength,metaDataData)
			//println "Searched Query: "+SQLQuery
			sqlObj = db.rows(SQLQuery)
			
			//recalc Total rows
			if(params.sSearch != null){
				def countQuery = getCountQuery(SQLQuery)
				//println "Searched Count Query: "+countQuery
				def recordCount = db.rows(countQuery)
				totalRows = recordCount[0]['total']
			}
			
		}else{
			SQLQuery = appendQuery(originalQuery,iDisplayStart,iDisplayLength,null)
			println "Query: "+SQLQuery
			metaDataObj = [:]
			metaDataObj.put("metaGot", true)
			sqlObj = db.rows(SQLQuery, { meta ->
				for (i in 0..<meta.columnCount ){
					def columnName = meta.getColumnLabel(i + 1)
					def columnType = meta.getColumnTypeName(i + 1)
					metaDataObj.put("META_"+columnName, columnType)
				}
			})

		}
		
			
		def returnObj = dataConstruct(sqlObj[0])
		returnObj['aaData'] = sqlObj
		returnObj['iTotalRecords'] = totalRows
		returnObj['iTotalDisplayRecords'] = totalRows
		returnObj['iDeferLoading'] = totalRows
		returnObj['recordCount'] = totalRows
		returnObj['aaSorting'] = []
		returnObj['bDeferRender'] = true
		returnObj['bServerSide'] = true
		returnObj['bDestroy'] = true
		returnObj['sScrollX'] = "100%"
		def returnObject = ['dataTable' : returnObj, 'metaData': metaDataObj]
		render returnObject as JSON

	}
	
	def processWhereFields(){
		def newMap = [:]
		def comparisons = ['=','LIKE','<','>','!','NOT LIKE']
		params.WHEREFIELDS.toString().split(",").each {
			def valQuery = params[it].toString().trim()
			def compare = null
			
			//Check if comparision is first part of the string - if so remove it but store comparsion for use in query construction
			for(def compareType : comparisons){
				//CHECK comparison is not longer than the string...
				if(compareType.toString().length()>valQuery.length()){
					continue
				}
				compare = valQuery.toUpperCase().substring(0, compareType.toString().length())
				if(compare.equals(compareType)){
					compare = compareType
					valQuery = valQuery.substring(compareType.toString().length()).trim()
					break
				}
			}
			
			println "*******************"
			println compare
			println valQuery
			println "*******************"
			
			if(/*isBulkSearch(it) && */valQuery.matches(".*(\\r?\\n|\\n|\\r|,).*")){
				def valQueryArr = valQuery.replaceAll("\\r?\\n|\\n|\\r|,", "\\|\\|").split("\\|\\|")
				def tmpIN = ""
				def firstIN = true
				
				if(compare.equals("LIKE")){
					valQueryArr.each{ InValue ->
						if(!firstIN){ tmpIN += " OR "+ it + " "}
						tmpIN +=  " LIKE '"+InValue+"%'"
						firstIN = false
					}
					newMap.put(it, tmpIN)
				}else if(compare.equals("NOT LIKE")){
					valQueryArr.each{ InValue ->
						if(!firstIN){ tmpIN += " OR "+ it+ " " }
						tmpIN +=  compare + "'"+InValue+"%'"
						firstIN = false
					}
					newMap.put(it, tmpIN)
				}else if(compare.equals("!")){
					valQueryArr.each{ InValue ->
						if(!firstIN){ tmpIN += " OR "+ it+ " " }
						if(InValue.isNumber()){
							tmpIN += compare + "= "+ InValue
						}else{
							tmpIN += compare + "= '"+ InValue+"'"
						}
						firstIN = false
					}
					newMap.put(it, tmpIN)
				}else if(compare.equals("<") || compare.equals(">")){
					valQueryArr.each{ InValue ->
						if(!firstIN){ tmpIN += " OR "+ it + " "}
						if(InValue.isNumber()){
							tmpIN += compare + " "+ InValue
						}
						firstIN = false
					}
					newMap.put(it, tmpIN)
				}else{
					valQueryArr.each{ InValue ->
						if(!firstIN){ tmpIN += "," }
						if(InValue.isNumber()){
							tmpIN += InValue
						}else{
							tmpIN += "'"+InValue+"'"
						}
						firstIN = false
					}
					
					newMap.put(it, "IN ("+tmpIN+")")
				}
			}else{
				if(valQuery.contains("%")){
					newMap.put(it, "LIKE '"+valQuery+"%'")
				}else if(compare.equals("LIKE")){
					newMap.put(it, " LIKE '"+valQuery+"%'")	
				}else if(compare.equals("NOT LIKE")){
					newMap.put(it, " NOT LIKE '"+valQuery+"%'")	
				}else if(compare.equals("!")){					
					newMap.put(it, compare+"= '"+valQuery+"'")
				}else if((compare.equals("=") ||  compare.equals("<") || compare.equals(">")) && valQuery.isNumber()){
					newMap.put(it,compare+" "+valQuery)
				}else if((compare.equals("=") ||  compare.equals("<") || compare.equals(">")) && !valQuery.isNumber()){
					newMap.put(it, compare+" '"+valQuery+"'")	
				}else if(compare!=null && valQuery.isNumber()){
					newMap.put(it, compare+" "+valQuery)
				}else{
					newMap.put(it," = '"+valQuery+"'")
				}
			}
		}
		
		
		println newMap
		return newMap
	}
	
	def isBulkSearch(field){
		def bulkSearchFields = ['AIT_AITSHORTNAME','AIT_AITNUMBER','COMPSYS_HOSTNAME']
		return bulkSearchFields.contains(field.toString())
		
	}
	
	def getMetaParams(){
		def metaData = [:]
		params.entrySet().each{
			if(it.key.toString().startsWith("META_")){
				metaData.put(it.key.toString().substring(5), it.value)
			}		
		}
		return metaData
	}
	
	def getCountQuery(SQLQuery){
		def sqlEnd = SQLQuery.substring(SQLQuery.toString().toUpperCase().indexOf("FROM"));
		
		def countFunction = "*"
		
		def indexGroup = sqlEnd.toString().toUpperCase().indexOf("GROUP BY")
		if(indexGroup > -1){
			countFunction = "distinct "+sqlEnd.substring(indexGroup+8).trim()
			sqlEnd = sqlEnd.substring(0,indexGroup)
		}
		
		def indexOrder = sqlEnd.toString().toUpperCase().indexOf("ORDER BY")
		if(indexOrder > -1){
			sqlEnd = sqlEnd.substring(0,indexOrder)
		}
		
		def indexLimit = sqlEnd.toString().toUpperCase().indexOf("LIMIT")
		if(indexLimit > -1){
			sqlEnd = sqlEnd.substring(0,indexLimit)
		}
		
		if(sqlEnd.toString().toUpperCase().contains("WHERE")){
			sqlEnd = sqlEnd.toString().toUpperCase().replace("HAVING", "AND")
		}else{
			sqlEnd = sqlEnd.toString().toUpperCase().replace("HAVING", "WHERE")
		}
		
		//sqlEnd = sqlEnd.toString().toUpperCase().replace("HAVING", "WHERE")
		sqlEnd = "Select count("+countFunction+") as total "+sqlEnd
	}
	
	def getQuery(){
		def fPath =  request.getSession().getServletContext().getRealPath("/")
		String fileContents = new File(fPath+params.sqlFile.toString().trim()+'.sql').text
		def engine = new SimpleTemplateEngine()
		def template = engine.createTemplate(fileContents).make(params.withDefault{ '' })
		return template.toString()
	}
	
	def appendQuery(originalQuery, iDisplayStart,iDisplayLength,metaDataData){
		def sqlQuery = originalQuery
		
		//Get the Select fields from the sqlQuery and put into array
		//this is to ensure metaDataSeqence fits to dataTable
		def fieldsToSplit = sqlQuery.substring(0,sqlQuery.toString().toUpperCase().indexOf("FROM"));
		def selectArray = fieldsToSplit.split("\\s*,\\s*")
		selectArray.collect { it.trim() }

		
		//Edit first element: 'SELECT COLUMN1' to 'COLUMN1'
		selectArray[0] = selectArray[0].toString().substring(selectArray[0].toString().lastIndexOf(" "))
		
		
		//If Select * query - overwrite array with meta data
		if((!selectArray[0].toString().trim() || selectArray[0].toString().contains("*")) && metaDataData != null){
			selectArray = []
			metaDataData.each { k,v->
				selectArray.push(k)
			}
		}
		
		if(params.iDisplayStart && params.iDisplayLength){
			iDisplayStart = params.iDisplayStart.toInteger()
			iDisplayLength = params.iDisplayLength.toInteger()
		}
		
		if(params.sSearch && metaDataData != null){
			if(!sqlQuery.toString().toUpperCase().contains("WHERE")){
				sqlQuery += " HAVING ("
			}else{
				sqlQuery += " HAVING ("
			}
			def iCount = 0
			metaDataData.each(){k,v ->
				println "-- "+k + " " + v
				if(iCount>0){ sqlQuery += " OR "} 
				if(v=='VARCHAR' || v=='TIMESTAMP'){
					sqlQuery += "`"+k + "` LIKE '"+params.sSearch+"%'"
					iCount++
				}else if(params.sSearch.toString().isNumber()){
					sqlQuery += "`" +k + "` LIKE '"+params.sSearch+"%'"
					iCount++
				}
			}
			sqlQuery +=")"
		}
		
		
		if(params.iSortingCols != null && params.sSortDir_0 != null && metaDataData != null){
			def sortingColumn = selectArray[params.iSortCol_0.toInteger()].toString().trim()
			if(metaDataData.containsKey(sortingColumn)){
				sqlQuery += " ORDER BY "+sortingColumn+" "+params.sSortDir_0
			}
		}
		
		if(iDisplayStart!=null && iDisplayLength!=null){
			sqlQuery += " LIMIT "+iDisplayStart+","+iDisplayLength
		}
		
		return sqlQuery
	}
	
		
	
	def dataConstruct(sqlData){
		def dataRtn = [:]
		dataRtn['aoColumns'] = []
		
		sqlData.each(){k,v ->
			dataRtn['aoColumns'].add(['mData': k,'sTitle': k])
		}
		
		dataRtn['sAjaxSource'] = params.controller+"/"+params.action
		
		if(params.sEcho){
			dataRtn['sEcho'] = params.sEcho.toInteger()
		}
		
		return dataRtn

	}
	
	
}
