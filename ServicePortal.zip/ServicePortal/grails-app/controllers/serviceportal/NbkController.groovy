package serviceportal

import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch

class NbkController {

    def index() { 
		LDAPSearch searchWho = new LDAPSearch("nbkxuqk");
		render searchWho.getResultsList()
    }
		
		
}
