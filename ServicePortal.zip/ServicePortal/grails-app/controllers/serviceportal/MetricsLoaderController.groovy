package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import groovy.text.SimpleTemplateEngine
import javax.servlet.http.Cookie

class MetricsLoaderController {
	def dataSource_ReadOnly, dataSource_dev, dataSource_uat
	
    def index() { 
	
		if(params?.sqlFile){
			def db
			if(params.devDB){
				db = new Sql(dataSource_dev)
			}else if(params.uatDB){
				println "USING UAT"
				db = new Sql(dataSource_uat)
			}else{
				db = new Sql(dataSource_ReadOnly)
			}
			//def fPath = "/hosting/configs/tomcat7/hotp-dev-01/webapps/ServicePortal/"
			processParams(db,params?.export,params?.fileName)
		}
			
	}
	
	def addParameters(){
		
		def newParams = []
		params.entrySet().each{
			if(it.key != 'action' && it.key != 'controller'){
				newParams.add(it.key.toString())
			}		
		}
		
		if(!newParams.empty){
			params.parameters = newParams.toArray()
		}

	}
	
	def fudgeIt(parameterMap){
		def newMap = [:]
		parameterMap.each {k,v->
			if(k != 'sqlFile' && k != 'Application' && k != 'Database' && k != 'Middleware' && k != 'System' && k != 'fieldsSelected'){
				newMap.put(k, v)
			}
		}
		
		def removeQuotes = parameterMap.get('fieldsSelected').toString()
		removeQuotes = removeQuotes.substring(1, removeQuotes.length()-1)
		parameterMap['fieldsSelected'] = removeQuotes
		parameterMap.put('multiFields', newMap)
	}
	
	def processParams(db,export,fileName){
		
		if(!params.containsKey('parameters') && !params.containsKey('plainLoad') ){
			addParameters()
		}

		def fPath =  request.getSession().getServletContext().getRealPath("/")
		//println fPath
		
		String fileContents = new File(fPath+params.sqlFile+'.sql').text
		
		//println fileContents
		
		println "EXPOR = "+export
		println "contains: "+params.containsKey('parameters')
		println params.parameters
		
		if(params.containsKey('parameters')){
			println "WRONG"
			def parameterMap = [:]
			
			if(params.parameters.getClass().isArray()){
				params.parameters.each {
					processMapCreation(it,params.get(it),parameterMap)
				}
			}else{
				processMapCreation(params.parameters,params.get(params.parameters),parameterMap)
			}


			println "PARAM MAP: "+parameterMap
				
			if(params.fudgeIt){
				parameterMap.remove('fudgeIt')
				fudgeIt(parameterMap)
			}
					
			if(parameterMap.size()>0){
				parameterMap.put('addWhere', true)
			}
			
			
			
			def engine = new SimpleTemplateEngine()
			def template = engine.createTemplate(fileContents).make(parameterMap.withDefault{ '' })
			
			println template.toString()
						
			if(export){
				Cookie cookie = new Cookie("fileDownload","true")
				cookie.maxAge = 10
				cookie.setPath("/")
				response.addCookie(cookie)
				ExportController exporter = new ExportController();
				exporter.export(db.rows(template.toString()),fileName)
			}else{
				render db.rows(template.toString()) as JSON
				//render template.toString() 
			}

		}else{
			if(export && export != "html" && export != "file"){
				Cookie cookie = new Cookie("fileDownload","true")
				cookie.maxAge = 10
				cookie.setPath("/")
				response.addCookie(cookie)
				ExportController exporter = new ExportController();
				exporter.export(db.rows(fileContents),fileName)
			}else if(export == "html"){
				println "HTML EPR"
				HtmlCreateController htmlOutput = new HtmlCreateController()
				htmlOutput.outPutHTML(db.rows(fileContents))
			}else if(export=="file" && fileName != null){
			
				def siteRootPath = grailsAttributes.getApplicationContext().getResource("").getFile().toString()+File.separator
				def fileToWrite = siteRootPath+fileName
				def iCnt = 0
				
				
				
				File file = new File(fileToWrite)
				if (file.exists()) {
					assert file.delete()
					assert file.createNewFile()
				}
				
				boolean append = true
				FileWriter fileWriter = new FileWriter(file, append)
				BufferedWriter buffWriter = new BufferedWriter(fileWriter)
				
				
				db.eachRow(fileContents){ row ->
					
					def rowCollect
					def lineString = ""
					def columnString = ""
					
					if(iCnt==0){
						rowCollect = row.toRowResult().keySet()
						rowCollect.each(){
							lineString += "\""+it+"\","
						}
						buffWriter.write(lineString)
						//out.writeLine(lineString)
						lineString = ""
					}
				
					rowCollect = row.toRowResult()
					
					rowCollect.each(){ k, v ->
						columnString = v.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '')
						lineString += "\""+columnString+"\","
					}
					
					buffWriter.write(lineString)
					
					iCnt++
				}
				
				

				
				buffWriter.flush()
				buffWriter.close()
				
				
				
				/*
				 
				def file = new File(fileToWrite)
				if(file.exists()){
					file.delete()
				}
				file.withWriter { out ->
					db.eachRow(fileContents){ row ->
						
						def rowCollect
						def lineString = ""
						def columnString = ""
						
						if(iCnt==0){
							rowCollect = row.toRowResult().keySet()
							rowCollect.each(){
								lineString += "\""+it+"\","
							}					
							out.writeLine(lineString)
							lineString = ""
						}
					
						rowCollect = row.toRowResult()
						
						rowCollect.each(){ k, v ->
							columnString = v.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '')
							lineString += "\""+columnString+"\","
						}
						
						out.writeLine(lineString)
						
						iCnt++	
					}
				}
			
				*/
				
				//def siteRootPath = System.properties['base.dir']+File.separator	
				//FileWriterController filewrite = new FileWriterController();
				//filewrite.writeFile(db.rows(fileContents),siteRootPath+fileName)
				render "<a href=\""+request.contextPath+"/"+fileName+"\">Success</a>"
			}else{
				render db.rows(fileContents) as JSON
			}
		}

	}
		
	def dev(){
		if(params?.sqlFile){
			def db = new Sql(dataSource_dev)	
			processParams(db,false,false)
		}
	}
	
	
	
	def processMapCreation(key,value,map){
		
		
		def comparision = ['<','>','=','<=','>=']
		
		if(value.getClass().isArray()){
			if(key in params.omitDataType || key.equals(params.omitDataType)){
				map.put(key,value.join(","))
			}else if(value.toString() in comparision){
				map.put(key,value.join(","))
			}else if(!value.toString().isNumber()){
				map.put(key,"'"+value.join("','")+"'")
			}else{
				map.put(key,value.join(","))
			}
		}else{
			if(key in params.omitDataType || key.equals(params.omitDataType)){
				map.put(key,value)
			}else if(value.toString() in comparision){
				map.put(key,value)
			}else if(!value.toString().isNumber()){
				map.put(key,"'"+value+"'")
			}else{
				map.put(key,value)
			}
		}
		
	}
}
