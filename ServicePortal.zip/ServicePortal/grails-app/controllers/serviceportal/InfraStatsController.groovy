package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class InfraStatsController {
	def dataSource
	
    def index() {
	
		if(params.id){
			def db = new Sql(dataSource)
					def queryString = """\
					SELECT id, name, description, sqlQuery, jsFunction 
					FROM hotpdb.gwbio_inventory_metrics_definition
					WHERE id = ${params.id}"""
					
			def result = db.firstRow(queryString)
			def stringToExec = result.sqlQuery
			def data = null
		
			def firstWordMain = stringToExec.trim().substring(0,stringToExec.trim().indexOf(" "))
			println stringToExec
			if(stringToExec.contains(";") && !firstWordMain.toLowerCase().equals("select")){
				def sqlArray = stringToExec.split(";")
				if(sqlArray.size()>1){
					sqlArray.each{
						def firstWord = it.trim().substring(0,it.trim().indexOf(" "))
						if(firstWord.trim().toLowerCase().equals("select")){
							data = db.rows(it)
						}else{
							db.execute(it)
						}
				
					}
				}else{
					data = db.rows(stringToExec)
				}
			}else{
				//Assume Simple select
				data = db.rows(stringToExec)
			}
			
			
			render data as JSON
			
		}	
	}
	
	
	def infraState() {
		
			if(params.id){
				def db = new Sql(dataSource)
						def queryString = """\
						SELECT id, name, description, sqlQuery, jsFunction
						FROM hotpdb.gwbio_state_infra
						WHERE id = ${params.id}"""
						
				def result = db.firstRow(queryString)
				def stringToExec = result.sqlQuery
				def data = []
			
			
				if(stringToExec.contains(";\r")){
					def sqlArray = stringToExec.split(";\r")	
					if(sqlArray.size()>1){
						
						println "*********************************"
						println "Running Many SQLs"
						println sqlArray
						println "*********************************"
						sqlArray.each{
							def firstWord = it.toString().trim().substring(0,it.toString().trim().indexOf(" "))
							if(firstWord.trim().toLowerCase().equals("select") || firstWord.trim().toLowerCase().equals("call") ){
								data.add(db.rows(it))
							}else{
								db.execute(it)
							}
					
						}
					}else{
						data = db.rows(stringToExec)
					}
				}else{
					//Assume Simple select
					data = db.rows(stringToExec)
				}
				
				
				render data as JSON
				
			}
		}
	
	def commentary(){
		if(params?.id){
			def db = new Sql(dataSource)
			def checkRecord = "SELECT id from hotpdb.gwbio_state_infra_commentary where metric_id = ?"
			def recordExist = db.firstRow(checkRecord,params.id)
			def sqlString
			println recordExist
			if(recordExist==null){
				sqlString = "INSERT INTO hotpdb.gwbio_state_infra_commentary (submitter, comment, metric_id) VALUES (?,?,?)"
			}else{
				sqlString = "UPDATE hotpdb.gwbio_state_infra_commentary SET submitter = ?, comment = ? WHERE metric_id = ?"
			}
			println sqlString
			db.executeInsert(sqlString, [session["email"], params.comment, params.id])
			def rtn = ['result':db.updateCount]
			render rtn as JSON 
		}
			
	}
}
