package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class Iadb_datasourcesController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [iadb_datasourcesInstanceList: Iadb_datasources.list(params), iadb_datasourcesInstanceTotal: Iadb_datasources.count()]
    }

    def create() {
        [iadb_datasourcesInstance: new Iadb_datasources(params)]
    }

    def save() {
        def iadb_datasourcesInstance = new Iadb_datasources(params)
        if (!iadb_datasourcesInstance.save(flush: true)) {
            render(view: "create", model: [iadb_datasourcesInstance: iadb_datasourcesInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), iadb_datasourcesInstance.id])
        redirect(action: "show", id: iadb_datasourcesInstance.id)
    }

    def show() {
        def iadb_datasourcesInstance = Iadb_datasources.get(params.id)
        if (!iadb_datasourcesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "list")
            return
        }

        [iadb_datasourcesInstance: iadb_datasourcesInstance]
    }

    def edit() {
        def iadb_datasourcesInstance = Iadb_datasources.get(params.id)
        if (!iadb_datasourcesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "list")
            return
        }

        [iadb_datasourcesInstance: iadb_datasourcesInstance]
    }

    def update() {
        def iadb_datasourcesInstance = Iadb_datasources.get(params.id)
        if (!iadb_datasourcesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (iadb_datasourcesInstance.version > version) {
                iadb_datasourcesInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'iadb_datasources.label', default: 'Iadb_datasources')] as Object[],
                          "Another user has updated this Iadb_datasources while you were editing")
                render(view: "edit", model: [iadb_datasourcesInstance: iadb_datasourcesInstance])
                return
            }
        }

        iadb_datasourcesInstance.properties = params

        if (!iadb_datasourcesInstance.save(flush: true)) {
            render(view: "edit", model: [iadb_datasourcesInstance: iadb_datasourcesInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), iadb_datasourcesInstance.id])
        redirect(action: "show", id: iadb_datasourcesInstance.id)
    }

    def delete() {
        def iadb_datasourcesInstance = Iadb_datasources.get(params.id)
        if (!iadb_datasourcesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "list")
            return
        }

        try {
            iadb_datasourcesInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'iadb_datasources.label', default: 'Iadb_datasources'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
