package serviceportal

class FileWriterController {

    def index() { }
	
	def writeFile(ObjectPassed,filePathAndName){
		
		def out = new File(filePathAndName)
		
		if(out.exists()){
			out.delete()
		}
		
		//pass all GroovyRowResult to an array of maps
		def arry = []
		ObjectPassed.each {
			def map = [:]
			map.putAll(it)
			arry.add(map)
		}
		
		
		//Push titles to output
			arry[0].each() { key, value ->
				out.append("\""+key+"\",")
			}
		
		out.append("\n")
		
		//Push values to output
		arry.each() {
			it.each(){ key, value ->
				value = value.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '')
				out.append("\""+value+"\",")
			}
			
			out.append("\n")
		};
	
		
		
	}
}
