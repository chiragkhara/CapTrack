package serviceportal

import grails.converters.JSON
import groovy.sql.Sql
import org.springframework.dao.DataIntegrityViolationException

class ApplicationController {
	def dataSource_ReadOnly
    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        render "Nothing here"
    }

	def search(){
		if(params?.id){
			def isInt = appParamsId(params.id)
			def orderBy = "ORDER BY APP_SHORT_NAME"
			if(isInt){
				orderBy = "ORDER BY APP_ID"
			}
			def db = new Sql(dataSource_ReadOnly)
			def varString = params.id+"%"
			def queryString = """\
				select * from (
					select APP_ID, APP_SHORT_NAME
					FROM extdb.ait_dq_vws_app apps
					WHERE CAST(APP_ID as CHAR) LIKE '${varString}'
					OR APP_SHORT_NAME LIKE '${varString}'
					group by APP_ID 
					LIMIT 10
				) subQ 
			"""	
			queryString = queryString+orderBy
			//println queryString
			def result = db.rows(queryString)
			render result as JSON

		}
	}
	
	def appParamsId(appID){
		try{
			def testAppId = appID.toInteger();
			return testAppId
		}catch(e){
			return false
		}
		return false
	}
		
    
	def getPODs(){
		def db = new Sql(dataSource_ReadOnly)
		def queryString = """\
			SELECT id, name, description
			FROM hotpdb.hotpgroups
			order by description
		"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def getAppsFromPOD(){
		def pod_id = params.id
		def db = new Sql(dataSource_ReadOnly)
		def queryString = """\
			SELECT aits.appid as `AIT ID`, aits.appshortname as `Application Short Name`
			FROM hotpdb.hotpgroupaits grpAIT
			inner join  hotpdb.inv_dm_ait_info aits on grpAIT.ait_id = aits.appid
			where grpAIT.hotpgroup_id = ${pod_id}
			order by aits.appshortname
		"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def getAppsPODs(){
		def ait_id = params.id
		def db = new Sql(dataSource_ReadOnly)
		def queryString = """\
			SELECT pods.id as `POD ID`, pods.description as `POD Description`
			FROM hotpdb.hotpgroupaits grpAIT
			inner join  hotpdb.hotpgroups pods on grpAIT.hotpgroup_id = pods.id
			where grpAIT.ait_id = ${ait_id}
			order by pods.description
		"""
		def result = db.rows(queryString)
		render result as JSON
	}
	
}
