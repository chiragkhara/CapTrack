package serviceportal

import grails.converters.JSON

class AdminController {

    def index() { 
		def changeFile = new File("/hosting/content/hotp-prod-01/htdocs/sqlExtract/greenDot_BMC.xlsx")
		def changeFileModDate = new Date(changeFile.lastModified()).format('yyyy-MM-dd HH:mm')
		
		def changeFileCI = new File("/hosting/content/hotp-prod-01/htdocs/sqlExtract/greenDot_BMC_Trend.xlsx")
		def changeCIFileModDate = new Date(changeFileCI.lastModified()).format('yyyy-MM-dd HH:mm')
		
		[changeFileModDate:changeFileModDate,changeCIFileModDate:changeCIFileModDate]
	}
	
	def greenDotDates(){
		def changeFile = new File("/hosting/content/hotp-prod-01/htdocs/sqlExtract/greenDot_BMC.xlsx")
		def changeFileModDate = new Date(changeFile.lastModified()).format('yyyy-MM-dd HH:mm')
		
		def changeFileCI = new File("/hosting/content/hotp-prod-01/htdocs/sqlExtract/greenDot_BMC_Trend.xlsx")
		def changeCIFileModDate = new Date(changeFileCI.lastModified()).format('yyyy-MM-dd HH:mm')
		
		def rtnDates = [changeFileModDate:changeFileModDate,changeCIFileModDate:changeCIFileModDate]
		
		render "${params.callback}(${rtnDates as JSON})"
	}
	
	def dsr(){
		
	}
	
	def ae(){
	
	}
}
