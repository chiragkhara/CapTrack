package serviceportal

import grails.converters.JSON

class WorklogsController {

    def index() {
		if(params?.id){ 
			//def mxoImIncident = MxoImIncidents.findByTicketid(params.id)
			//def workLogs = MxoImIncidentWorklogs.findAllByRecordkeyMxoImIncidents(mxoImIncident,[sort:"balastupdate",order: "desc"])
			def workLogs = MxoImIncidentWorklogs.findAllByRecordkey(params.id,[sort:"balastupdate",order: "desc"])
			if(workLogs.empty){
				render "No work logs for "+params.id
			}else{
				[worklogs: workLogs]	
			}
			//render workLogs as JSON
		}
	}
}
