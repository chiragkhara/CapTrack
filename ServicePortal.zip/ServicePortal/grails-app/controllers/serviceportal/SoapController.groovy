package serviceportal

import grails.converters.JSON
import groovy.sql.Sql

class SoapController {

	def dataSource_ReadOnly
	
    def index() { }
	
	
	def gwbServers(){
		
		def db = new Sql(dataSource_ReadOnly) 
		def bAppendSQL = false
		def sqlAppend = null
		
		def simpleParams = [:]
		params.each { name, value ->
			if(!name.equals("action") && !name.equals("controller")){
				simpleParams.put(name.toString().toLowerCase(), value)
			}
		}
		
		
		if(!simpleParams.isEmpty()){
		
			def tmpColumnName, tmpColumnValue
			def cntAppends = 0
			sqlAppend = ""
			def schemaQuery = """\
				SELECT lower(COLUMN_NAME)as COLUMN_NAME, DATA_TYPE
				FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = 'hotpdb' AND TABLE_NAME = 'serviceportal_soap_gwball'
				"""
			def schemaData = db.rows(schemaQuery)
			
			schemaData.each {
				tmpColumnName = it.COLUMN_NAME.toLowerCase()
				if(simpleParams.containsKey(tmpColumnName)){
					
					if(cntAppends>0){
						sqlAppend += " AND "
					}
					
					tmpColumnValue = simpleParams[tmpColumnName].toString();
					if(tmpColumnValue.substring(tmpColumnValue.length()-1).equals("%")){
						sqlAppend += tmpColumnName+sqlParseDataType(tmpColumnValue,it.DATA_TYPE,true)
					}else{
						sqlAppend += tmpColumnName+sqlParseDataType(tmpColumnValue,it.DATA_TYPE,false)
					}
					cntAppends++
				}
			}
			
			bAppendSQL = true
			//println sqlAppend
			
		}
			
		
		
		
		def queryString = """\
				SELECT *
				FROM hotpdb.serviceportal_soap_gwball
			"""
		if(bAppendSQL){
			queryString += " WHERE "+sqlAppend
		}
		
		def result = db.rows(queryString)
		
		if(params?.outputformat=="xls"){
			def csvText = ""
			def headerText = ""
			def iCnt;
			result.eachWithIndex { elem, index ->
				iCnt = 0;
				csvText += "\n"
				elem.entrySet().each {
					if(index==0){
						if(iCnt>0){
							headerText += ","
						}
						headerText += "\""+it.key+"\""
					}
					if(iCnt>0){
						csvText += ","
					}
					csvText += "\""+it.value+"\""
					iCnt++
				}
			}
			
			def date = new Date()
			def formattedDate = date.format('yyyy-MM-dd_HHmm')
			def fileName = "inventoryExtract_"+formattedDate
			response.setHeader("Content-disposition", "attachment; filename=${fileName}.csv")
			response.contentType = 'application/vnd.ms-excel'
			response.outputStream << headerText+csvText
			response.outputStream.flush()
			
		}else{
			render result as JSON
		}
		
	}
	
	def sqlParseDataType(value, datatype,like){
		def returnString = ""
		def startString = " = "
		def endString = ""
		
		if(datatype.toString().contains("char")){
			if(like){
				startString = " like "
			}
			returnString = startString+"'"+value+endString+"'"
		}else{
			returnString = startString+value+endString
		}
		
		return returnString
	}
	
}
