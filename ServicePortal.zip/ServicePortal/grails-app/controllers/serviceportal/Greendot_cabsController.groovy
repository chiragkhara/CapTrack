package serviceportal

import org.springframework.dao.DataIntegrityViolationException

class Greendot_cabsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [greendot_cabsInstanceList: Greendot_cabs.list(params), greendot_cabsInstanceTotal: Greendot_cabs.count()]
    }

    def create() {
        [greendot_cabsInstance: new Greendot_cabs(params)]
    }

    def save() {
        def greendot_cabsInstance = new Greendot_cabs(params)
        if (!greendot_cabsInstance.save(flush: true)) {
            render(view: "create", model: [greendot_cabsInstance: greendot_cabsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), greendot_cabsInstance.id])
        redirect(action: "show", id: greendot_cabsInstance.id)
    }

    def show() {
        def greendot_cabsInstance = Greendot_cabs.get(params.id)
        if (!greendot_cabsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_cabsInstance: greendot_cabsInstance]
    }

    def edit() {
        def greendot_cabsInstance = Greendot_cabs.get(params.id)
        if (!greendot_cabsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "list")
            return
        }

        [greendot_cabsInstance: greendot_cabsInstance]
    }

    def update() {
        def greendot_cabsInstance = Greendot_cabs.get(params.id)
        if (!greendot_cabsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (greendot_cabsInstance.version > version) {
                greendot_cabsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'greendot_cabs.label', default: 'Greendot_cabs')] as Object[],
                          "Another user has updated this Greendot_cabs while you were editing")
                render(view: "edit", model: [greendot_cabsInstance: greendot_cabsInstance])
                return
            }
        }

        greendot_cabsInstance.properties = params

        if (!greendot_cabsInstance.save(flush: true)) {
            render(view: "edit", model: [greendot_cabsInstance: greendot_cabsInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), greendot_cabsInstance.id])
        redirect(action: "show", id: greendot_cabsInstance.id)
    }

    def delete() {
        def greendot_cabsInstance = Greendot_cabs.get(params.id)
        if (!greendot_cabsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "list")
            return
        }

        try {
            greendot_cabsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'greendot_cabs.label', default: 'Greendot_cabs'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
