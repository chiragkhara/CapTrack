package serviceportal

class LatestDSRController {

    def index() {
		//def fileURL = "http://lrcha76629.rch-p01.chp.bankofamerica.com:26110/MostRecentDSR/callMostRecentDSR"
		def fileURL = "http://lrcha76629.rch-p01.chp.bankofamerica.com:26000/newDSR/DSR_Daily.html"
		def thisUrl = new URL(fileURL);
		def connection = thisUrl.openConnection();
		def htmlInputStream = connection.inputStream
		
		//response.setHeader "Content-disposition", "attachment;
		//response.contentType = 'text/html'
		response.outputStream << htmlInputStream
		response.outputStream.flush()
		
	}
}
