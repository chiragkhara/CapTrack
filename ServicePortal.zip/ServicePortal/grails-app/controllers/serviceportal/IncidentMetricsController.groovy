package serviceportal


import grails.converters.JSON
import groovy.sql.Sql
import javax.servlet.http.Cookie

class IncidentMetricsController {

	def dataSource
	
	def index() { }
	
	def byServiceArea(){
		
		def db = new Sql(dataSource) // Create a new instance of groovy.sql.Sql with the DB of the Grails app
		def queryString = """\
					Select SERVICEAREA as value
					FROM hotpdb.gwbio_incident_list
					GROUP BY SERVICEAREA
					ORDER BY SERVICEAREA"""
		def result = db.rows(queryString)
		render result as JSON
	}
	




}
