package serviceportal

import grails.converters.JSON
import java.util.regex.Pattern
import java.util.regex.Matcher

class ProcessExecController {

    def index() { 
		
		if(session["user"] && session["email"] && session["name"]){

			def processesAvailableCriteria = IaDynamicReport_processexec.createCriteria()
			def processesAvailable = processesAvailableCriteria.list{
				createAlias("authorisedUsers", "c")
				eq("c.username", session["user"])
			}
			
			def parameterNumbers = [:]
			Pattern pattern = Pattern.compile("\\[]");
			
			
			processesAvailable.each{
				Matcher matcher = pattern.matcher(it.processString)
				int iCnt = 0;
				while (matcher.find()){
					iCnt++;
				}
				parameterNumbers.put(it.id, iCnt)
			}
			
			[processesAvailable:processesAvailable, parameterNumbers:parameterNumbers]
			
		}else{
			redirect(uri: "/login?fwdTarget=/processExec")
		}
	}
	
	
	def exec(){
		def process = IaDynamicReport_processexec.get(params.processId)
		def processBuild = process.processString.replaceAll("\\[]", params.incidentSearch)
		def processArray = processBuild.split(" ")
		println processArray
		def results = execProcess(processArray)
		render results as JSON
	}
	
	def processCaller(){
		def strOut = "<b>Command entered:</b> "
		params.commandArray.each(){
			strOut += it+ "&nbsp;"
		}
		
		def phantomCall = execProcess(params.commandArray)
		strOut += "<br><b>Exit code: </b>"+phantomCall.exitCode
		strOut += "<br><b>output: </b>"+phantomCall.output
		strOut += "<br><b>errors: </b>"+phantomCall.errors
		
		render strOut
	}
	
	
	def execProcess(commandString){
			
		ProcessBuilder phantomBuild = new ProcessBuilder(commandString)
		Process p = phantomBuild.start();
		InputStream errorOutput = new BufferedInputStream(p.getErrorStream(), 10000);
		InputStream consoleOutput = new BufferedInputStream(p.getInputStream(), 10000);
		
		int exitCode = p.waitFor();
		
		int ch;
		def errorsString = ""
		def outputString = ""
		
		
		//System.out.println("Errors:");
		while ((ch = errorOutput.read()) != -1) {
			errorsString += (char) ch;
		}
		
		//System.out.println("Output:");
		while ((ch = consoleOutput.read()) != -1) {
			outputString += (char) ch;
		}
		
		return [errors:errorsString, output:outputString,exitCode:exitCode]
		
	}
	
	def searchIM(){
		if(params?.id){
			def mxoImIncidents = MxoImIncidents.executeQuery("select distinct ticketid from MxoImIncidents where ticketid like ?",[params.id+"%"],[max: 10, offset: 0])
			render mxoImIncidents as JSON
		}else{
			def err = [:]
			err.error = "No IM entered"
			return err as JSON
		}
	}
}
