package serviceportal



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Mdh_mw_dnp_lookup)
class Mdh_mw_dnp_lookupTests {

    void testSomething() {
       fail "Implement me"
    }
}
