package serviceportal



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.web.ControllerUnitTestMixin} for usage instructions
 */
@TestFor(Gwbio_worklogs_subscriptionsController)
class Gwbio_worklogs_subscriptionsControllerTests {

    void testSomething() {
       fail "Implement me"
    }
}
