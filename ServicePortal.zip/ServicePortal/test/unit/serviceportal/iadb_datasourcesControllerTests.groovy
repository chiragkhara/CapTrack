package serviceportal



import org.junit.*
import grails.test.mixin.*

@TestFor(Iadb_datasourcesController)
@Mock(Iadb_datasources)
class Iadb_datasourcesControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/iadb_datasources/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.iadb_datasourcesInstanceList.size() == 0
        assert model.iadb_datasourcesInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.iadb_datasourcesInstance != null
    }

    void testSave() {
        controller.save()

        assert model.iadb_datasourcesInstance != null
        assert view == '/iadb_datasources/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/iadb_datasources/show/1'
        assert controller.flash.message != null
        assert Iadb_datasources.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/iadb_datasources/list'


        populateValidParams(params)
        def iadb_datasources = new Iadb_datasources(params)

        assert iadb_datasources.save() != null

        params.id = iadb_datasources.id

        def model = controller.show()

        assert model.iadb_datasourcesInstance == iadb_datasources
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/iadb_datasources/list'


        populateValidParams(params)
        def iadb_datasources = new Iadb_datasources(params)

        assert iadb_datasources.save() != null

        params.id = iadb_datasources.id

        def model = controller.edit()

        assert model.iadb_datasourcesInstance == iadb_datasources
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/iadb_datasources/list'

        response.reset()


        populateValidParams(params)
        def iadb_datasources = new Iadb_datasources(params)

        assert iadb_datasources.save() != null

        // test invalid parameters in update
        params.id = iadb_datasources.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/iadb_datasources/edit"
        assert model.iadb_datasourcesInstance != null

        iadb_datasources.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/iadb_datasources/show/$iadb_datasources.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        iadb_datasources.clearErrors()

        populateValidParams(params)
        params.id = iadb_datasources.id
        params.version = -1
        controller.update()

        assert view == "/iadb_datasources/edit"
        assert model.iadb_datasourcesInstance != null
        assert model.iadb_datasourcesInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/iadb_datasources/list'

        response.reset()

        populateValidParams(params)
        def iadb_datasources = new Iadb_datasources(params)

        assert iadb_datasources.save() != null
        assert Iadb_datasources.count() == 1

        params.id = iadb_datasources.id

        controller.delete()

        assert Iadb_datasources.count() == 0
        assert Iadb_datasources.get(iadb_datasources.id) == null
        assert response.redirectedUrl == '/iadb_datasources/list'
    }
}
