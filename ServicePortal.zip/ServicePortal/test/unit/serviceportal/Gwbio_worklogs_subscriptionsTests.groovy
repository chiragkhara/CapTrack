package serviceportal



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Gwbio_worklogs_subscriptions)
class Gwbio_worklogs_subscriptionsTests {

    void testSomething() {
       fail "Implement me"
    }
}
