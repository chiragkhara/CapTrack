SELECT cfid, hostname, infra_product, app_instance, pgp, news_paging_grp, umid, nodealias_key 
FROM hotpdb.auto_callflow_apps
