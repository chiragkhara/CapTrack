select 
aits as `AIT Id`,
ait_shortname `AIT Name`, 
ucal_flag `UCAL`,
db_link as `link`,
nexus_req_no `Nexus#`,
requestor_name,
manager_name
from hotpdb.Capacity_dashboard_masterhub
order by ait_shortname