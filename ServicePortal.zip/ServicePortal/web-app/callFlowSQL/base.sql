SELECT cfid, cf_lob, infra_product, pgp, news_paging_grp 
FROM hotpdb.auto_callflow_base