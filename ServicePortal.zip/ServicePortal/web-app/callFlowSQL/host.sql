SELECT *
FROM hotpdb.auto_callflow_hosts