select * 
from extdb.mdh_ait
where ait_aitnumber = ${id}