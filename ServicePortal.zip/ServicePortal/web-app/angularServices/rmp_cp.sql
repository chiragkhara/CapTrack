SELECT `Year Month`, `Input File`, AIT, Detail1,  `Product Desc`, `Total qty`,  `Total charge`
FROM extdb.rpm_gwb_billing
WHERE AIT = 11697 AND `Year Month` = '201502'