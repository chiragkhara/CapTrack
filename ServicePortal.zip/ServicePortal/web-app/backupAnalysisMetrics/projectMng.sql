call hotpdb.generateDynamicPivotFromQuery('status','Select 
  backupanalysis_answers.answer
  , status
FROM (
Select 
  mdh_ait.ait_aitnumber
  ,case 
    when answer is null then ''Not Started''
    else backupanalysis_answers.answer
 end as status
FROM
extdb.mdh_ait 
INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = ''GWBT&O'' AND mdh_cto.TWODOT <> ''VS''
INNER JOIN hotpdb.backupanalysis_answers on mdh_ait.ait_aitnumber = backupanalysis_answers.ait AND questionId = 7
WHERE backupanalysis_answers.answer != ''Out of Scope''
GROUP BY ait_aitnumber
) tmpOrder
JOIN hotpdb.backupanalysis_answers on tmpOrder.ait_aitnumber = backupanalysis_answers.ait AND questionId = 8
GROUP BY ait_aitnumber', 'FIELD(status,''Not Started'',''Not yet scheduled'',''Scheduled'',''Interview pre-work'',''Ready for AIT interview'',''AIT processing'',''Final review'',''Certified'',''Out of Scope'')' ,NULL, NULL,NULL);