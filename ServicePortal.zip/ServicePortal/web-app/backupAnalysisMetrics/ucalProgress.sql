Select * FROM (
Select 
  case 
    when answer is null then 'Not Started'
    else backupanalysis_answers.answer
 end as status
  ,count(mdh_ait.ait_aitnumber) as `# AITS`
FROM
extdb.mdh_ait 
INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
LEFT JOIN hotpdb.backupanalysis_answers on mdh_ait.ait_aitnumber = backupanalysis_answers.ait AND questionId = 7
WHERE mdh_ait.ait_ucal = 1 and (backupanalysis_answers.answer != 'Out of Scope' OR backupanalysis_answers.id IS NULL)
AND mdh_ait.ait_status NOT IN ('BUILD','RETIRED')
GROUP BY backupanalysis_answers.answer
) tmpOrder
ORDER BY FIELD(status,'Not Started','Not yet scheduled','Scheduled','Interview pre-work','Ready for AIT interview','AIT processing','Final review','Certified','Out of Scope')