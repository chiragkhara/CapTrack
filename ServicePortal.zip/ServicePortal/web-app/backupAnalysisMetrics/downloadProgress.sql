select 
  backupCompleteness.*
  ,backupanalysis_answers.answer as Project_Manager
FROM (
  Select 
  ait_aitnumber
  , mdh_ait.ait_ucal 
  , ait_aitshortname
  , case 
    when answer is null then 'Not started'
    else answer
  end as Status
  ,dt
  FROM
  extdb.mdh_ait 
  INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
  LEFT JOIN hotpdb.backupanalysis_answers on mdh_ait.ait_aitnumber = backupanalysis_answers.ait AND questionId = 7
  WHERE mdh_ait.ait_ucal = 1 AND mdh_ait.ait_status NOT IN ('BUILD','RETIRED')
  GROUP BY ait_aitnumber
  
  UNION 
  
  Select 
  ait_aitnumber
  , mdh_ait.ait_ucal
  , ait_aitshortname
  , case 
    when answer is null then 'Not started'
    else answer
  end as Status
  ,dt
  FROM
  extdb.mdh_ait 
  INNER JOIN extdb.mdh_cto ON MDH_AIT.AIT_FIVE_DOT_HIER = mdh_cto.FIVEDOT AND mdh_cto.CTO = 'GWBT&O' AND mdh_cto.TWODOT <> 'VS'
  LEFT JOIN hotpdb.backupanalysis_answers on mdh_ait.ait_aitnumber = backupanalysis_answers.ait AND questionId = 7
  WHERE mdh_ait.ait_ucal = 0 AND mdh_ait.ait_status NOT IN ('BUILD','RETIRED')
  GROUP BY ait_aitnumber
  
) backupCompleteness
LEFT JOIN hotpdb.backupanalysis_answers on backupCompleteness.ait_aitnumber = backupanalysis_answers.ait AND questionId = 8
