import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Properties; 

import javax.mail.Authenticator;
import javax.mail.Message; 
import javax.mail.MessagingException; 
import javax.mail.PasswordAuthentication;
import javax.mail.SendFailedException;
import javax.mail.Session; 
import javax.mail.Transport; 
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress; 
import javax.mail.internet.MimeMessage;
import javax.mail.Address;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Multipart;
import javax.mail.BodyPart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.activation.DataHandler;

import org.apache.log4j.Logger;

public class EmailUtil {
	
	ArrayList<String> toList;
	String fromAddress;
	String fromName;
	String htmlContent;
	String smtpHost = "mail.bankofamerica.com";
	String subject;
	String replyToAddress;
	boolean errorOccured = false;
	String auth = "false";
	String user;
	String pwd;
	private static Logger logger = Logger.getLogger(EmailUtil.class);
	
	public EmailUtil(ArrayList<String> toList, String fromAddress, String subject, String message){	
		toList = toList;
		fromAddress = fromAddress;
		fromName = fromAddress;
		htmlContent = message;
		subject = subject;
		replyToAddress = fromAddress;
	}
	
	public EmailUtil(ArrayList<String> toList, String fromAddress, String subject, String message, String user, String pwd, String auth){
		toList = toList;
		fromAddress = fromAddress;
		fromName = fromAddress;
		htmlContent = message;
		subject = subject;
		replyToAddress = fromAddress;
		auth = auth;
		user = user;
		pwd = pwd;
	}
	
	public void sendEmail(){
		Address[] addresses = new Address[1];
		Properties prop = System.getProperties();
		prop.setProperty("mail.smtp.host", smtpHost);
		prop.setProperty("mail.smtp.auth", auth);
		prop.setProperty("mail.smtp.port", "25");
		
		Session session;
		System.out.println("auth: "+auth);
		if(auth.equals("true")){	
			Authenticator auth = new Authenticator() {
		    	  public PasswordAuthentication getPasswordAuthentication() {
		    	    return new PasswordAuthentication(user,pwd);
		    	  }
		    	};
		    	//System.out.println("pwding"+user+ " "+pwd);
		    	session = Session.getDefaultInstance(prop, auth);
		}else{
			session = Session.getDefaultInstance(prop);
		}
		try
		{
			addresses[0] = new InternetAddress(replyToAddress);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromAddress,fromName));
			message.setReplyTo(addresses);
			for (int i=0; i< toList.size(); i++){
				message.addRecipient(Message.RecipientType.TO, new InternetAddress(toList.get(i)));
			}
			message.setSubject(subject);
			message.setContent(htmlContent, "text/html");
			Transport.send(message);
		}
		catch(MessagingException me)
		{
			logger.error(me.getMessage());
			me.printStackTrace();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
	}
	
	public void sendEmail(String fileName, String displayName)
	{
		Address[] addresses = new Address[1];
		Properties prop = System.getProperties();
		//System.out.println("host: "+smtpHost);
		prop.setProperty("mail.smtp.host", smtpHost);
		prop.setProperty("mail.smtp.auth", auth);
		prop.setProperty("mail.smtp.port", "25");
		
		Session session;
		//System.out.println("auth: "+auth);
		if(auth.equals("true")){	
			Authenticator auth = new Authenticator() {
		    	  public PasswordAuthentication getPasswordAuthentication() {
		    	    return new PasswordAuthentication(user,pwd);
		    	  }
		    	};
		    	//System.out.println("pwding"+user+ " "+pwd);
		    	session = Session.getDefaultInstance(prop, auth);
		}else{
			session = Session.getDefaultInstance(prop);
		}
		
		
		
		//System.out.println(session.getDebug());
		try
		{
			DataSource ds = new FileDataSource(fileName);
			addresses[0] = new InternetAddress(replyToAddress);
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromAddress,fromName));
			message.setReplyTo(addresses);
			InternetAddress emailAddr = null;
			for (int i=0; i< toList.size(); i++){
				System.out.println(toList.get(i));
				emailAddr = new InternetAddress(toList.get(i));
				if(validateEmail(emailAddr)){
					message.addRecipient(Message.RecipientType.TO, emailAddr);
				}
			}
			message.setSubject(subject);
			BodyPart msgBodyPart = new MimeBodyPart();
			msgBodyPart.setDataHandler(new DataHandler(ds));
			msgBodyPart.setFileName(displayName);
			
			Multipart multiPart = new MimeMultipart();
			multiPart.addBodyPart(msgBodyPart);
			
			MimeBodyPart html = new MimeBodyPart();		
			html.setContent(htmlContent, "text/html");
			multiPart.addBodyPart(html);
			
			message.setContent(multiPart);
	
			Transport.send(message);
		}
		catch(MessagingException me)
		{
			logger.error(me.getMessage());
			me.printStackTrace();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
	}
	
	
	public void sendEmail(List<String> fileNames)
	{
		Address[] addresses = new Address[1];
		Properties prop = System.getProperties();
		//System.out.println("host: "+smtpHost);
		prop.setProperty("mail.smtp.host", smtpHost);
		prop.setProperty("mail.smtp.auth", auth);
		prop.setProperty("mail.smtp.port", "25");
		
		Session session;
		System.out.println("auth: "+auth);
		if(auth.equals("true")){	
			Authenticator auth = new Authenticator() {
		    	  public PasswordAuthentication getPasswordAuthentication() {
		    	    return new PasswordAuthentication(user,pwd);
		    	  }
		    	};
		    	//System.out.println("pwding"+user+ " "+pwd);
		    	session = Session.getDefaultInstance(prop, auth);
		}else{
			session = Session.getDefaultInstance(prop);
		}
		
		
		MimeMessage message = null;
		InternetAddress emailAddr = null;
		//System.out.println(session.getDebug());
		try{
			addresses[0] = new InternetAddress(replyToAddress);
			message = new MimeMessage(session);
			message.setFrom(new InternetAddress(fromAddress,fromName));
			message.setReplyTo(addresses);
			for (int i=0; i< toList.size(); i++){	
				emailAddr = new InternetAddress(toList.get(i));
				logger.info("ADDING EMAIL: " +emailAddr);
				if(validateEmail(emailAddr)){
					logger.info("IS TRUE EMAIL: " +emailAddr);
					message.addRecipient(Message.RecipientType.TO, emailAddr);
				}
			}
			
			
			message.setSubject(subject);
			
			
			Multipart multipart = new MimeMultipart("mixed");
			for (String str : fileNames) {
				//System.out.println("addng: "+str);
			    MimeBodyPart messageBodyPart = new MimeBodyPart();
			    DataSource source = new FileDataSource(str);
			    messageBodyPart.setDataHandler(new DataHandler(source));
			    messageBodyPart.setFileName(source.getName());
			    multipart.addBodyPart(messageBodyPart);
			}
	
						
			MimeBodyPart html = new MimeBodyPart();		
			html.setContent(htmlContent, "text/html");
			multipart.addBodyPart(html);
			
			message.setContent(multipart);
	
			Transport.send(message);
		}
		catch(SendFailedException sendFails){
		
			Address[] fails = sendFails.getInvalidAddresses();
			ArrayList<Address> goodList = new ArrayList<Address>();
			
			//LOOP MAIL ADDRESS and Only add those that DID NOT cause error
			for (int i=0; i< toList.size(); i++){				
				try {
					emailAddr = new InternetAddress(toList.get(i));
					if(!Arrays.asList(fails).contains(emailAddr)){
						logger.info("NOT IN BAD LIST EMAIL :" +emailAddr);
						goodList.add(emailAddr);
					}else{
						logger.info("REMOVING EMAIL :" +emailAddr);
					}
				} catch (AddressException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}	
			
			
			//RESEND WITHOUT THE ERRONEOUS EMAIL LIST
			Address[] goodListArr = goodList.toArray(new Address[goodList.size()]);
			try {
				logger.info("TRYING SENDING AGAIN WITHOUT ERRONEOUS MAILS");
				message.setRecipients(Message.RecipientType.TO, goodListArr);
				Transport.send(message);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		catch(MessagingException me)
		{
			logger.error(me.getMessage());
			me.printStackTrace();
		}
		catch(Exception e)
		{
			logger.error(e.getMessage());
			e.printStackTrace();
		}
	}
	

	 private boolean validateEmail(InternetAddress email) {
		boolean isValid = false;
		logger.info("testingL "+email);
		try {
			email.validate();
			isValid = true;
		}catch (AddressException e) {
			logger.error("Email address: "+email.getAddress()+" Failed validation");
		}
		
		logger.info("Result "+email+" is = "+isValid);
		return isValid;
	 }
	
	public ArrayList<String> getToList() {
		return toList;
	}
	

	public void setToList(ArrayList<String> toList) {
		this.toList = toList;
	}

	public String getFromAddress() {
		return fromAddress;
	}

	public void setFromAddress(String fromAddress) {
		this.fromAddress = fromAddress;
	}

	public String getFromName() {
		return fromName;
	}

	public void setFromName(String fromName) {
		this.fromName = fromName;
	}

	public String getHtmlContent() {
		return htmlContent;
	}

	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}

	public String getSmtpHost() {
		return smtpHost;
	}

	public void setSmtpHost(String smtpHost) {
		this.smtpHost = smtpHost;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getReplyToAddress() {
		return replyToAddress;
	}

	public void setReplyToAddress(String replyToAddress) {
		this.replyToAddress = replyToAddress;
	}

}

