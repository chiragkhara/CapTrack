
	var iExecSummary = 2;
	var iAssessmentInfo = 2;

	$(document).ready(
		function() {
			$("#add_row").click(
				function() {
					var tdString = "<td>" + iExecSummary + "</td><td><select name='obsv" + iExecSummary + "' id='obsv" + iExecSummary +
					"'><option value='CPU'>CPU</option><option value='Memory'>Memory</option><option value='Disk'>Disk</option><option value='Filesystem'>Filesystem</option><option value='Other'>Other</option></select></td><td><textarea name='issues" + iExecSummary + 
					"' placeholder='Issues' class='text_inputs'></textarea> </td>"
					var trString = '<tr id="addr'+ iExecSummary + '">'+ tdString + '</tr>'

					/* -- Add/Remove Executive Summary -- */
					$('#tab_logic tbody').append(trString);
					iExecSummary++;
			});

			$("#delete_row").click(function() {
				if (iExecSummary > 1) {
					$("#addr" + (iExecSummary - 1)).remove()
					iExecSummary--;
				}
			});
	});

$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup")
			.autocomplete(
					{
						source : function(request, response) {
							$
									.ajax({
										url : "../assessments/aitLookup/",
										data : {
											aitName : request.term
										},
										success : function(data) {
											response($
													.map(
															data,
															function(item) {
																return {
																	label : item.ait_aitnumber,
																	inTitle : item.ait_aitnumber
																			+ " ("
																			+ item.ait_aitshortname
																			+ ")",
																	aitsname : item.ait_aitshortname,
																	aittier : item.aittier,
																	ucal : item.ucal_flag,
																	dbflag : item.dashboard_flag,
																	dblink : item.db_link
																}
															}));
										}
									});
						},
						minLength : 3,
						select : function(event, ui) {
							getAssocServers(ui.item.label, ui.item.aitsname)
							getcsvHosts(ui.item.label)
							$("#submitBtn").attr("disabled",false);
							$("#saservicediv").show();
							$("#cfservicediv").show();
							$("#displayArea").show();
							$("#host_instruction").hide();
							$("#config_instruction").hide();
							$("#aitSName").val(ui.item.aitsname);
							$("#aitTier").val(ui.item.aittier);
							if (ui.item.ucal == "1") {
								$("#aitUCAL").val("YES");
							} else {
								$("#aitUCAL").val("NO");
							}

							/*derive for Capacity Metric graphs*/
							var capMetricLink
							capMetricLink = "http://gwb-analytics.bankofamerica.com/ServicePortal/?type=Capacity&subType=Capacity%20Metrics&ait="
									+ ui.item.aitsname
							if (ui.item.aitsname) {
								$("#capMetric_link").attr("href",
										capMetricLink);
								$("#capMetric_link").attr("target",
										"_blank");
								$("#capMetric_link").text("Click Here.");
								$("#memMetric_link").attr("href",
										capMetricLink);
								$("#memMetric_link").attr("target",
										"_blank");
								$("#memMetric_link").text("Click Here.");
							} else {
								$("#capMetric_link").attr("href", "#");
								$("#capMetric_link").text("Please select your AIT in the Previous section first!");
								$("#memMetric_link").attr("href", "#");
								$("#memMetric_link").text("Please select your AIT in the Previous section first!");
							}

							if (ui.item.dbflag == "1"){
								$("#a_dblink").attr("href","http://wrcha78495.rch-p01.chp.bankofamerica.com/ReportServer?/Dashboards/GWBIO/DataSources/GWBTest+Dashboard&AITNumber=" + ui.item.label);
								$("#a_dblink").attr("target","_blank");
								$("#a_dblink").text("Dashboard Already Exists! Click Here.");
							}else{
								$("#a_dblink").text("Register here");
								$("#a_dblink").attr("target","_blank");
								$("#a_dblink").attr("href",'/CapTrack/capacityDashboard/newregister/?aitnumber='+ui.item.label)
							}
						}
					}).data("ui-autocomplete")._renderItem = function(ul,item) {
		return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
	};

	$("#aitLookup")
			.keyup(
					function() {
						if (!this.value) {
							$("#saservicediv").hide();
							$("#cfservicediv").hide();
							$("#displayArea").hide();
							$("#invalid_aitCheck").hide();
							$("#host_instruction").show();
							$("#config_instruction").show();
							$("#a_dblink").text("Input the AIT number to check for Capacity Dashboard");
							$("#capMetric_link").attr("href", "#");
							$("#capMetric_link")
									.text(
											"Please select your AIT in the Previous section first!");
						}
					});
					
	$("#fsInputs").focus(function() {
    var $this = $(this);
    $this.select();

    // Work around Chrome's little problem
    $this.mouseup(function() {
        // Prevent further mouseup intervention
        $this.unbind("mouseup");
        return false;
    });
});
	
})



function drawTable(data, tableId, functionKeys) {

	var stringHeader = "<thead><tr>"
	var stringTable = "<tbody>"
	var firstRow = false

	for ( var key in data) {
		var obj = data[key];
		stringTable += "<tr>"

		for ( var prop in obj) {
			if (!firstRow) {
				stringHeader += "<th>" + prop + "</th>"
			}

			stringTable += "<td>"

			if (typeof functionKeys != 'undefined'
					&& typeof functionKeys[prop] != 'undefined') {
				stringTable += functionKeys[prop](obj)
			} else {
				stringTable += obj[prop]
			}

			stringTable += "</td>"
		}
		;

		stringTable += "</tr>"
		firstRow = true;

	}

	stringHeader += "</tr></thead>"
	var staticData = "<p style='color: red; font-size: 0.9em;'><i>NOTE : If any discrepancies are found in <b>Server to AIT</b> relationship, please correct on RTT <a href='http://rtt.bankofamerica.com/DataMaintenance/ApplicationSearch.aspx'>here</a><br />NOTE : If any discrepancies found in <b>Environment</b> information, Maximo system of records needs to be updated via RFC for environment level detail changes. <br />NOTE : If the <b>Server Role</b> is incorrect, please correct it in Runbook <a href='http://dssapps.bankofamerica.com/runbook/RunBookMenu.asp'>here</a></p>"
	var stringReturn = staticData + "<table id=\""+tableId+"\" class=\"datatable\">"
			+ stringHeader + stringTable + "</tbody></table>"
	return stringReturn
}



/* Calling for HELP DIALOG on What is this?. for each Form element */
$(function() {
	$( ".helpful a" ).click(function(){
  		$.ajax({
			url:"/CapTrack/assessments/getHelpContent/",
		   data: {
				helpident : $(this).attr('id')
		 	},
		 	dataType: 'json',
		 	type: 'POST',
	   		success: function( data ) {
	   			if ( data.length != 0 ) {
					var tmpId = $('<div />').html(data[0].help_text);
		        	$(tmpId).dialog({
		        		autoOpen: true,
		            		autoResize: true,
		            		width: 600,
		            		modal: true,
		            		title: data[0].help_subj,
		            		close: function() {
		               			$(this).dialog('destroy')
		            		}
		        	});// Prepare dialog
	   			}// End of Data Length check
	   		} // End of success	        	
		}); // End AJAX call
	}); // End dblink
}); // End Function


//-- Create Link table for All Hosts
function drawDNTTable(prodHosts,tblLabel){

	var enddate = $.datepicker.formatDate('yy-mm-dd', new Date());
	var today = new Date();
	var yesterday = new Date(today);
	yesterday.setMonth(today.getMonth() - 3);
	var threemonthdate = $.datepicker.formatDate('yy-mm-dd', yesterday);
	var onedaybefore = new Date(today);
	onedaybefore.setDate(today.getDate() - 1);
	var onedaydate =  $.datepicker.formatDate('yy-mm-dd', onedaybefore);
	
	var prodhostArray = prodHosts.split(',');
	arrLength = prodhostArray.length;
	var proddata;
	
	proddata = "<p style='font-style: italic;'>Please find below the DNT link(s) for your "+ tblLabel +" Hosts</p>"
	
	proddata = proddata + '<table class="dnttable"><tr><td colspan=3>'+tblLabel+' DATA</td></tr><tr><td><b>3 Month Data</b></td><td><b> 1 Day Data</b></td><td><b> Hosts Covered</b></td></tr>'
	var anchorString = 'http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=';
	var hosts="";
	var viewhosts="";
	
	for (i = 1; i <= arrLength; i++){
		if(i % 10 != 0){
			hosts = hosts + prodhostArray[i - 1] + "%252C";
			viewhosts = viewhosts + prodhostArray[i - 1] + ", ";
		}else{
			hosts = hosts + prodhostArray[i - 1] + "%252C";
			viewhosts = viewhosts + prodhostArray[i - 1] + ", ";
			viewhosts = viewhosts.replace(/,\s*$/, "");
			hosts = hosts.replace(/%252C\s*$/, "");
			proddata = proddata + 
			'<tr><td><a href="'+anchorString+hosts+'&BeginDate=' + threemonthdate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td>'+
			'<td><a href="'+anchorString+hosts+'&BeginDate=' + onedaydate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td><td>'+viewhosts+'</td></tr>'
			hosts = "";
			viewhosts="";
		}
	}
	
	if(arrLength % 10 != 0){
		hosts = "";
		viewhosts = "";
		for (i = (Math.floor(arrLength/10) * 10); i < arrLength; i++){
			hosts = hosts + prodhostArray[i] + "%252C";
			viewhosts = viewhosts + prodhostArray[i] + ", ";
		}
		hosts = hosts.replace(/%252C\s*$/, "");
		viewhosts = viewhosts.replace(/,\s*$/, "");
		proddata = proddata + '<tr><td><a href="'+anchorString+hosts+'&BeginDate=' + threemonthdate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td>' + 
		'<td><a href="'+anchorString+hosts+'&BeginDate=' + onedaydate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td><td>'+viewhosts+'</td></tr>'
	}
	proddata = proddata + "</table>"
	return proddata;
}


/* GET SERVERS SECTION BEGINS */
function getAssocServers(aitnumber, name) {
	var url = "../assessments/getHostlist/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {
			if ( data.length != 0 ) {
				$("#invalid_aitCheck").show()
				var stringReturn = drawTable(data, "fab_logic_1")
				$("#displayArea").html(stringReturn)
			} else{
				$("#invalid_aitCheck").hide()
				$("#displayArea").html("<p class='myp'> This AIT does not have any valid hosts. </p>")
				$("#submitBtn").attr("disabled", true);
			}
		}
	});
}

function getcsvHosts(aitnumber) {
	var url = "../assessments/getcsvHosts/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {
			var enddate = $.datepicker.formatDate('yy-mm-dd', new Date());
			var today = new Date();
			var yesterday = new Date(today);
			yesterday.setMonth(today.getMonth() - 3);
			var threemonthdate = $.datepicker.formatDate('yy-mm-dd', yesterday);
			var onedaybefore = new Date(today);
			onedaybefore.setDate(today.getDate() - 1);
			var onedaydate =  $.datepicker.formatDate('yy-mm-dd', onedaybefore);

			//-- Get Production and Contingency Hosts
			var splitHosts = data.split(':')
			
			$("#fsInputs").val(data.replace(':',','));
			var prodHosts = splitHosts[0];
			var contHosts = splitHosts[1];
			
			// Checking for NULL Production Hosts
			
			if (!prodHosts){
				console.log("No values found!!")
			} else {
				var prodTable = drawDNTTable(prodHosts,'PRODUCTION')
				$("#prodDNT").html(prodTable)
				
				var prod_configLink = "http://dnt.bankofamerica.com/Portal/ConfigLoader.aspx?hostNames=" + prodHosts + "&BeginDate=" + threemonthdate + "&EndDate=" + enddate;
				
				$("#prod_configLink").attr("href",prod_configLink);
				$("#prod_configLink").attr("target","_blank");
				$("#prod_configLink").text("Prod Link.");
			}
			
			//Checking for NULL Contingency Hosts
			
			if (!contHosts){
				console.log("No values found!!")
			} else {
				var contTable = drawDNTTable(contHosts,'CONTINGENCY')
				$("#contDNT").html(contTable)
				
				var cont_configLink = "http://dnt.bankofamerica.com/Portal/ConfigLoader.aspx?hostNames=" + contHosts + "&BeginDate=" + threemonthdate + "&EndDate=" + enddate;
				
				$("#cont_configLink").attr("href",cont_configLink);
				$("#cont_configLink").attr("target","_blank");
				$("#cont_configLink").text("Cont Link.");
			}
			
		}
	});
}