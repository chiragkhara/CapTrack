
$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup").autocomplete({
			source : function(request, response) {
				$.ajax({
					url : "/CapTrack/capacityDashboard/aitLookup/",
					data : {
						aitName : request.term
					},
					success : function(data) {
						response($
								.map(
										data,
										function(item) {
											return {
												label : item.ait_aitnumber,
												inTitle : item.ait_aitnumber
														+ " ("
														+ item.ait_aitshortname
														+ ")",
												aitsname : item.ait_aitshortname,
												aittier : item.aittier,
												ucal : item.ucal_flag,
												dbflag : item.dashboard_flag,
												process : item.processed
											}
										}));
					}
				});
			},
			minLength : 3,
			select : function(event, ui) {
				getAssocServers(ui.item.label, ui.item.aitsname)
				$("#saservicediv").show();
				$("#displayArea").show();
				$("#host_instruction").hide();
				$("#aitSName").val(ui.item.aitsname);
				$("#aitTier").val(ui.item.aittier);
				if (ui.item.ucal == "1") {
					$("#aitUCAL").val("YES");
				} else {
					$("#aitUCAL").val("NO");
				}
				
				if (ui.item.dbflag == 1){
					$("#editRedirect").show();
					$("#displayArea").hide();
					$('#submitBtn').attr('disabled',true);
				} else {	
					$("#editRedirect").hide();
					$("#displayArea").show();
					$('#submitBtn').attr('disabled',false);
				}
				
				if (ui.item.process == "True") {
					$("#aitCapTrack").val("YES");
					$("#captrackmsg").hide();
				} else {
					$("#aitCapTrack").val("NO");
					$("#captrackmsg").show();
				}
			}
		}).data("ui-autocomplete")._renderItem = function(ul, item) {
	return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
};

	$("#aitLookup").keyup(function() {
		if (!this.value) {
			$("#host_instruction").show();
			$('#submitBtn').attr('disabled',true);
			$("#editRedirect").hide();
			$("#saservicediv").hide();
			$("#displayArea").hide();
		}
	});
})


	function getAssocServers(aitnumber, name) {
		var url = "/CapTrack/collectProdHosts/getHostlist/?aitnumber=" + aitnumber
		$.ajax({
			url : url,
			success : function(data) {
				var stringReturn = drawTable(data, "fab_logic_1")
				$("#displayArea").html(stringReturn)
				appendChoiceColumn($("#fab_logic_1"));
			}
		});
	}

	function appendChoiceColumn(obj) {
			//Add Column Title and SELECT ALL drop down
			obj.find('tr:eq(0)').append('<th>Application Role</th>');
			
			$.ajax({
				url : "/CapTrack/capacityDashboard/getRoleTypes",
				success : function(hachoices) {
					obj
					.find('tr:gt(0)')
					.each(
							function() {
								var hostname = $(this).find('td').eq(1).text()
								var haName = "HACLUS-" + hostname
								$(this)
									.append('<td><select id="'+haName+'" name="'+haName+'" /></td>');

						for ( var haval in hachoices) {
							$("<option />", {
								value : hachoices[haval],
								text : hachoices[haval]
							}).appendTo($("#" + haName));
						}

					});	
				}
			})
		}


/*
 * function loops through created HTML table and injects a column and creates a drop down for each host...
 */

function drawTable(data, tableId, functionKeys) {

	var stringHeader = "<thead><tr>"
	var stringTable = "<tbody>"
	var firstRow = false

	for ( var key in data) {
		var obj = data[key];
		stringTable += "<tr>"

		for ( var prop in obj) {
			if (!firstRow) {
				stringHeader += "<th>" + prop + "</th>"
			}

			stringTable += "<td>"

			if (typeof functionKeys != 'undefined'
					&& typeof functionKeys[prop] != 'undefined') {
				stringTable += functionKeys[prop](obj)
			} else {
				stringTable += obj[prop]
			}

			stringTable += "</td>"
		}
		;

		stringTable += "</tr>"
		firstRow = true;

	}

	stringHeader += "</tr></thead>"
	var staticData = "<h4><span style='color: #C00000;'> NOTE : This assessment is applicable only for AITs which cover MIDRANGE servers. Mainframe OR Desktop Only AITs should not run this assessment. </span></h4><br />";
	var stringReturn = "<table id=\""+tableId+"\" class=\"datatable\">"
			+ stringHeader + staticData + stringTable + "</tbody></table>"
	return stringReturn
}


