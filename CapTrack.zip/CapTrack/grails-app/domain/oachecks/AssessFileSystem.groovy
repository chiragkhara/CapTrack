package oachecks

class AssessFileSystem {

	Integer Q1
	Integer Q2
	
	static mapping = {		
		table name: 'capassess_filesys_checklist', schema: 'hotpdb'
		version false
		id column:'fsid'
	}
	 
}
