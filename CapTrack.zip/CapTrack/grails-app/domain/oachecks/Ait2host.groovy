package oachecks

import java.util.Date;

class Ait2host {

    Integer aitnumber
	String hostname
	String environment
	
	static mapping = {		
		table name: 'auto_ait2host', schema: 'hotpdb'
		version false
		id column:'hostid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)		
	}
}
