package oachecks

import java.util.Date;

class AssessMaster {
	
	Integer aitnumber
	Date rundate
	String author
	String author_email
	String capcomments
	String cfgchoice
	String cfgcomments
	
	static mapping = {		
		table name: 'capassess_master_checklist', schema: 'hotpdb'
		version false
		id column:'assessid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		rundate(size:0..12)
		author(size:0..127)
		author_email(size:0..256)
	}
}
