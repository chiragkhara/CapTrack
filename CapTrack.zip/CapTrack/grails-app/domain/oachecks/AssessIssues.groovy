package oachecks

class AssessIssues {

	Long sumid 
	String summary_text
	String category
	
	static mapping = {		
		table name: 'capassess_summary_checklist', schema: 'hotpdb'
		version false
		id column:'issueid'	
	}
}
