package oachecks

import java.util.Date;

class Assessments {

    Integer aitnumber
	String author_name
	Date date_added
	Integer cap_flag
	Integer ucal_flag
	Integer dnt_flag
	String dnt_comments
	String cap_comments
	
	static mapping = {		
		table name: 'assessment_checklist', schema: 'hotpdb'
		version false
		id column:'aid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)		
	}
}
