package captrack
import java.util.Date;

class AdminAccounts {
	String aitnumber
	String aitshortname
	Integer aittier
	Integer ucal_flag
	String enable_flag
	String processed
	String advanceservice
	Date createdate
	String assigned_admin
	String admin_email
	
   
	static mapping = {
		table name: 'capacity_workflow_master', schema: 'hotpdb'
		version false
		id column:'wfid'
	}
	 
	static constraints = {
		aitnumber(size:0..10)
		aitshortname(size:0..50)
		advanceservice(size:0..50)
		createdate(size:0..50)
		assigned_admin(size:0..127)
		admin_email(size:0..512)
	}
}
