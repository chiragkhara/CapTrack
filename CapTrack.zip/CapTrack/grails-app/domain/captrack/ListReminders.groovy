package captrack
import java.util.Date;

class ListReminders {
	String aitnumber
	String aitshortname
	Date gwbscan_rem
	Date dashboard_rem
	Date forecast_rem
	Date selfassessment_rem
	Date adhocassessment_rem
	Date advanceservice_rem
	String reminder_flag
	String sas_contact
	String processed
   
	static mapping = {
		table name: 'capacity_workflow_reminders', schema: 'hotpdb'
		version false
		id column:'wf_rid'
	}
	 
	static constraints = {
		aitnumber(size:0..10)
		aitshortname(size:0..100)
		gwbscan_rem(size:0..50)
		dashboard_rem(size:0..50)
		forecast_rem(size:0..50)
		selfassessment_rem(size:0..50)
		adhocassessment_rem(size:0..50)
		advanceservice_rem(size:0..50)
		reminder_flag(size:0..50)
		sas_contact(size:0..100)
		
		aitnumber nullable: true
		dashboard_rem nullable: true
		forecast_rem nullable: true
		selfassessment_rem nullable: true
		adhocassessment_rem nullable: true
		advanceservice_rem nullable: true
		
	}
}
