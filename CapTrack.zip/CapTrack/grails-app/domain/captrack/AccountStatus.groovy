package captrack

class AccountStatus {
    String aitnumber
	String aitshortname
	String gwbscan_status
	String dashboard_status
	String forecast_status
	String selfassessment_status
	String adhocassessment_status
	String advanceservice_status
	Integer gwbscan_flag
	Integer dashboard_flag
	Integer forecast_flag
	Integer selfassessment_flag
	Integer adhocassessment_flag
	Integer advanceservice_flag
	
	static mapping = {		
		table name: 'capacity_workflow_status', schema: 'hotpdb'
		version false
		id column:'wf_sid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		aitshortname(size:0..100)
		gwbscan_status(size:0..50)
		dashboard_status(size:0..50)
		forecast_status(size:0..50)
		selfassessment_status(size:0..50)
		advanceservice_status(size:0..50)
		gwbscan_flag(size:0..11)
		dashboard_flag(size:0..11)
		forecast_flag(size:0..11)
		selfassessment_flag(size:0..11)
		advanceservice_flag(size:0..11)	
	}
}
