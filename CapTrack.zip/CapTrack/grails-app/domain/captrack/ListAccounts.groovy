package captrack
import java.util.Date;

class ListAccounts {
	String aitnumber
	String aitshortname
	String aitstatus
	String appmanager
	Integer aittier
	Integer ucal_flag
	String gwbscan
	String dashboard
	String forecast
	String advanceservice
	String selfassessment
	String adhocassessment
	Date createdate
	Integer dashboard_flag
	String db_link
	String processed
	String enable_flag
	String primary_contact
	String primary_email
	String secondary_contact
	String secondary_email
   
	static mapping = {
		table name: 'capacity_workflow_master', schema: 'hotpdb'
		version false
		id column:'wfid'
	}
	 
	static constraints = {
		aitnumber(size:0..10)
		aitshortname(size:0..50)
		aitstatus(size:0..50)
		appmanager(size:0..100)
		gwbscan(size:0..50)
		dashboard(size:0..50)
		forecast(size:0..50)
		advanceservice(size:0..50)
		selfassessment(size:0..50)
		adhocassessment(size:0..50)
		createdate(size:0..50)
		db_link(size:0..1024)
		processed(size:0..20)
		enable_flag(size:0..40)
		primary_contact(size:0..100)
		secondary_contact(size:0..100)
		primary_email(size:0..500)
		secondary_email(size:0..500)
		
		
		db_link nullable: true
		dashboard_flag nullable:true
		secondary_contact nullable:true
		secondary_email nullable:true
		gwbscan nullable:true
	}
}
