package captrack

class AdminStatus {

    String aitnumber
	
	String gwbscan_status
	String dashboard_status
	String forecast_status
	String selfassessment_status
	String adhocassessment_status
	String advanceservice_status
	
	Integer gwbscan_flag
	Integer dashboard_flag
	Integer forecast_flag
	Integer selfassessment_flag
	Integer adhocassessment_flag
	Integer advanceservice_flag
	
	Date gwbscan_ack_date
	Date dashboard_ack_date
	Date forecast_ack_date
	Date selfassessment_ack_date
	Date adhocassessment_ack_date
	Date advanceservice_ack_date
	
	Integer gwbscan_sla
	Integer dashboard_sla
	Integer forecast_sla
	Integer selfassessment_sla
	Integer adhocassessment_sla
	Integer advanceservice_sla
	
	static mapping = {		
		table name: 'capacity_workflow_status', schema: 'hotpdb'
		version false
		id column:'wf_sid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		
		gwbscan_status(size:0..20)
		dashboard_status(size:0..20)
		forecast_status(size:0..20)
		selfassessment_status(size:0..20)
		adhocassessment_status(size:0..20)
		advanceservice_status(size:0..20)
		
		gwbscan_ack_date(size:0..20)
		dashboard_ack_date(size:0..20)
		forecast_ack_date(size:0..20)
		selfassessment_ack_date(size:0..20)
		adhocassessment_ack_date(size:0..20)
		advanceservice_ack_date(size:0..20)
		
		gwbscan_flag(size:0..11)
		dashboard_flag(size:0..11)
		forecast_flag(size:0..11)
		selfassessment_flag(size:0..11)
		adhocassessment_flag(size:0..11)
		advanceservice_flag(size:0..11)	
		
		gwbscan_sla(size:0..11)
		dashboard_sla(size:0..11)
		forecast_sla(size:0..11)
		selfassessment_sla(size:0..11)
		adhocassessment_sla(size:0..11)
		advanceservice_sla(size:0..11)
	}
}
