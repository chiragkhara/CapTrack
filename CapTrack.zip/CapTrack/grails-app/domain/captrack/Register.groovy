package captrack

import java.util.Date;

class Register {

	String ait
	String shortname
	String owner
	String email
    Date createdate
	
	static mapping = {
		table name: 'ait_dnt_mstr', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
	}
	
	static constraints = {
		ait(size:0..11)
		shortname(size:0..300)
		email(size:0..1024)
		owner(size:0..1024)
		createdate(size:0..30)
			
		shortname nullable:true
		email nullable:true
		owner nullable:true

	}
}
