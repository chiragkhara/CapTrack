package captrack

import java.util.Date;

class CapacityDashboard {

	String ait
	String shortname
	String hostname
	String role
    Date host_added_date
	String role_selected
	Integer edit_flag
	Integer include_flag
	String manual_edit_user
	Date manual_edit_date
	
	
	static mapping = {
		table name: 'ait_dnt_roles', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
	}
	
	static constraints = {
		ait(size:0..11)
		shortname(size:0..300)
		hostname(size:0..200)
		role(size:0..1024)
		host_added_date(size:0..30)
			
		shortname nullable:true
		role nullable:true
		host_added_date nullable:true
		manual_edit_user nullable:true
		manual_edit_date nullable:true

	}
}
