package oachecks

import grails.converters.JSON
import groovy.sql.Sql
import groovy.transform.Canonical

import org.apache.catalina.realm.JAASCallbackHandler;
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class AssessmentsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource
	def aitLookup
	
    def index() {
		getUser()
        redirect(action: "inventory_assessment", params: params)
    }
	
	def retrieve_assessments() {
		getUser()
	}
	
	def inventory_assessment() {
		getUser()
	}
	
	
	def getAssessment(){
		def report_number = params['reportno']
		def masterList = AssessMaster.get(report_number)
		def cpuList = AssessCPU.get(report_number)
		def memList = AssessMemory.get(report_number)
		def dskList = AssessDisk.get(report_number)
		def fsList = AssessFileSystem.get(report_number)
		def issuesList = AssessIssues.findAll("from AssessIssues as AI where AI.sumid = ${report_number}")
		[master: masterList, cpu: cpuList, mem: memList, dsk: dskList, fs: fsList, issues: issuesList]
	}
	
	def print_preview(){
		def report_number = params['reportno']
		def masterList = AssessMaster.get(report_number)
		def cpuList = AssessCPU.get(report_number)
		def memList = AssessMemory.get(report_number)
		def dskList = AssessDisk.get(report_number)
		def fsList = AssessFileSystem.get(report_number)
		def issuesList = AssessIssues.findAll("from AssessIssues as AI where AI.sumid = ${report_number}")
		[master: masterList, cpu: cpuList, mem: memList, dsk: dskList, fs: fsList, issues: issuesList]
	}
	
	def getAssesslist(){
		def db = new Sql(dataSource)
		def assessStr = """\
			Select concat("<a href='../assessments/getAssessment/?reportno=",CAST(assessid AS CHAR),"' target='_blank'>",CAST(assessid as CHAR),"</a>") as ReportNumber, 
				DATE_FORMAT(rundate,'%m-%d-%Y') as DateGenerated, aitnumber as AITNum, author as Author 
			from hotpdb.capassess_master_checklist where aitnumber = ${params.aitnumber} 
				order by rundate desc limit 10;
 		"""
		
		def AssessList = db.rows(assessStr)
		render AssessList as JSON
	}
			
	def sendData(){
		def db = new Sql(dataSource)
				
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		params.remove('username')
		
		def aitnum = params.get('aitLookup')
		
		/*--- CONFIG Information Section ---*/
		def capcomments = params.get('comments_CapPlan')
		def cfgChoice = params.get('as_cfgPlan')
		def cfgcomments = params.get('comments_Config')
		def user_name = params.get('user_name')
		def email = params.get('email')
		
		java.util.Date date_got = new java.util.Date();
		def uniqueKey = date_got.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_added = df.format(date_got);
		
		//println "Unique Key --> " + uniqueKey + " Today's date - "  + date_added
		
		def insertCfg = """\
				insert into hotpdb.capassess_master_checklist 
				(assessid,aitNumber,author,author_email,capcomments,cfgchoice,cfgcomments,rundate) 
				values (?,?,?,?,?,?,?,?)
			"""
		def valuesCfg = [uniqueKey, aitnum, user_name,email,capcomments,cfgChoice,cfgcomments,date_added]			
		def dataCreate = db.execute(insertCfg, valuesCfg)
		
		/*--- CPU Information ---*/
		
		def cpu_Q1 = params.get('cpu_Q1')
		def cpu_Q2 = params.get('cpu_Q2')
		def cpu_Q3 = params.get('cpu_Q3')
		def cpu_Q4 = params.get('cpu_Q4')
		def cpu_Q5 = params.get('cpu_Q5')
		def cpu_Q6 = params.get('cpu_Q6')
		
		
		def insertCPU = """\
			insert into hotpdb.capassess_cpu_checklist (cpuid,Q1,Q2,Q3,Q4,Q5,Q6)
			values (?,?,?,?,?,?,?)
		"""
		//println insertCPU
		def valueCPU = [uniqueKey,cpu_Q1,cpu_Q2,cpu_Q3,cpu_Q4,cpu_Q5,cpu_Q6]
		def cpuCreate = db.execute(insertCPU, valueCPU)

		/*--- Memory Information ---*/
		
		def mem_Q1 = params.get('mem_Q1')
		def mem_Q2 = params.get('mem_Q2')
		def mem_Q3 = params.get('mem_Q3')
		def mem_Q4 = params.get('mem_Q4')
		def mem_Q5 = params.get('mem_Q5')
		
		
		def insertMemory = """\
			insert into hotpdb.capassess_memory_checklist (memid,Q1,Q2,Q3,Q4,Q5)
			values (?,?,?,?,?,?)
		"""
		
		def valueMemory = [uniqueKey,mem_Q1,mem_Q2,mem_Q3,mem_Q4,mem_Q5]
		def memCreate = db.execute(insertMemory, valueMemory)
		
		/*--- DISK Information ---*/
		
		def disk_Q1 = params.get('disk_Q1')
		def disk_Q2 = params.get('disk_Q2')
		
		
		def insertDisk = """\
			insert into hotpdb.capassess_diskp_checklist (dskid,Q1,Q2)
			values (?,?,?)
		"""
		def valueDisk = [uniqueKey, disk_Q1, disk_Q2]
		//println insertDisk
		def diskCreate = db.execute(insertDisk, valueDisk)

		/*--- FILESYSTEM Information ---*/
		
		def fs_Q1 = params.get('file_Q1')
		//def fs_Q2 = params.get('file_Q2')
		//def fscomments = params.get('file_comments')
		
		
		def insertFS = """\
			insert into hotpdb.capassess_filesys_checklist (fsid,Q1)
			values (?,?)
		"""
		//println insertFS
		def valueFS = [uniqueKey,fs_Q1] 
		def fsCreate = db.execute(insertFS, valueFS)
		
		/* EXECUTIVE SUMMARY SECTION */
		def issuenumber
		def issue_text
		def issue_category
		
		params.entrySet().each{
			if (it.key.toString().contains("issues")){
				issuenumber = it.key.toString().substring(6)
				issue_category = params.get('obsv' + issuenumber)
				issue_text = it.value
				
				// Insert Issues only if they exist with valid text
				if (!issue_text) {
				} else {
					def insertIssues = """\
						insert into hotpdb.capassess_summary_checklist (sumid,category,summary_text)
						values (?,?,?)
					"""
					def valueIssues = [uniqueKey,issue_category,issue_text]
					def issueCreate = db.execute(insertIssues, valueIssues)
				}
			}
		}
		
		redirect(action: "getAssessment", params: [reportno: uniqueKey])
	}

	def aitLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,capacity_workflow_master.aittier, 
			capacity_workflow_master.ucal_flag, capacity_workflow_master.dashboard_flag,
			capacity_workflow_master.db_link FROM hotpdb.capacity_workflow_master
			WHERE capacity_workflow_master.enable_flag = 'True' and 
			(capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%')
			LIMIT 15
		"""
		def result = db.rows(queryString)
		render result as JSON
	
	}
	
	
	def getHostlist(){
		def db = new Sql(dataSource)
		
		def dntBaseLink="http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=";
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd")
		Date date = new Date()
		def todaydate = df.format(date);
		def begindate;
		
		use ( TimeCategory ){
			begindate = df.format(date - 3.months)
		}
		
		def dntFollowLink = "&BeginDate=" + begindate + "&EndDate=" + todaydate;

		/*def hostString = """\
			Select auto_ait2host.aitnumber as AIT, auto_ait2host.hostname as Hostname, 
			auto_ait2host.environment as Environment, auto_ait2host.role as ServerRole,
			concat("<a href='http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?
			Export=false&hostNames=",auto_ait2host.hostname,"${dntFollowLink}' target='_blank'>",
			"DNT Graph </a>") as DNTLink
			from hotpdb.auto_ait2host where auto_ait2host.environment in ('Production','Contingency') AND 
			auto_ait2host.aitnumber = ${params.aitnumber} 
			order by auto_ait2host.environment desc, auto_ait2host.hostname asc
		"""*/
		
		def hostString = """\
			select extdb.mdh_ait.AIT_AITNUMBER as aitno, mdh_compsys.compsys_hostname as Hostname,
			mdh_compsys.compsys_operatingenv as Environment, extdb.dss_nos.serverfunction as Role,
			concat("<a href='http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?
			Export=false&hostNames=",mdh_compsys.compsys_hostname,"${dntFollowLink}' target='_blank'>",
			"DNT Graph </a>") as DNTLink 
			FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel ON 
			mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS 
			INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID 
			LEFT JOIN extdb.dss_nos ON dss_nos.servername = mdh_compsys.compsys_hostname
			WHERE extdb.mdh_ait.ait_cto = 'GWBT&O' AND 
			mdh_compsys.compsys_operatingenv in ('Contingency','Production')  AND
			extdb.mdh_ait.AIT_AITNUMBER = ${params.aitnumber}
		"""
		
		def configureList = db.rows(hostString)
		render configureList as JSON
	}
	
	def getcsvHosts(){
		def chk = new Sql(dataSource)
		def query = """\
			Select auto_ait2host.hostname as Hostname,auto_ait2host.environment as Environment from hotpdb.auto_ait2host
			where auto_ait2host.environment in ('Production','Contingency') AND 
			auto_ait2host.aitnumber = ${params.aitnumber} order by auto_ait2host.environment, auto_ait2host.hostname
		"""
		List hostProd = new ArrayList()
		List hostCont = new ArrayList()
		chk.eachRow(query) {
			if(it.Environment == "Production"){
				hostProd.push(it.Hostname)
			}
			
			if(it.Environment == "Contingency"){
				hostCont.push(it.Hostname)
			}
		}
		def listSize = hostProd.size()
		
		//println "AIT : " + params.aitnumber + " Total Prod Hosts : " + listSize
		def prodString = hostProd.join(",")
		def contString = hostCont.join(",")
		
		//println prodString + ":" + contString
		
		render (prodString + ":" + contString)
		
	}
	
	def getHelpContent(){
		def dbh = new Sql(dataSource)
		if (params.helpident){
			def getHelpdata = """\
				select capacity_workflow_help.help_subj,capacity_workflow_help.help_text
				from hotpdb.capacity_workflow_help where
			capacity_workflow_help.help_key = '"""+params.helpident+"""'
			"""
			
			def result = dbh.rows(getHelpdata)
			render result as JSON
		}
	}
	
	def getUser(){
		def myid = request.getHeader("uid")	
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
	
	def oassessment(){
		getUser()
	}
	
	def assessments(){
		getUser()
	}
	
	def testassessment(){
		getUser()
	}
}
