package captrack

import org.springframework.dao.DataIntegrityViolationException

import captrack.ListReminders;

class ListRemindersController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "backuplist", params: params)
    }

    def backuplist() {
        [listRemindersInstanceList: ListReminders.list(params)]
    }
	
	def list() {
		[listRemindersInstanceList: ListReminders.list(params)]
	}

    def create() {
        [listRemindersInstance: new ListReminders(params)]
    }

    def save() {
        def listRemindersInstance = new ListReminders(params)
        if (!listRemindersInstance.save(flush: true)) {
            render(view: "create", model: [listRemindersInstance: listRemindersInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), listRemindersInstance.id])
        redirect(action: "show", id: listRemindersInstance.id)
    }

    def show() {
        def listRemindersInstance = ListReminders.get(params.id)
        if (!listRemindersInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "list")
            return
        }

        [listRemindersInstance: listRemindersInstance]
    }

    def edit() {
        def listRemindersInstance = ListReminders.get(params.id)
        if (!listRemindersInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "list")
            return
        }

        [listRemindersInstance: listRemindersInstance]
    }

    def update() {
        def listRemindersInstance = ListReminders.get(params.id)
        if (!listRemindersInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (listRemindersInstance.version > version) {
                listRemindersInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'listReminders.label', default: 'ListReminders')] as Object[],
                          "Another user has updated this ListReminders while you were editing")
                render(view: "edit", model: [listRemindersInstance: listRemindersInstance])
                return
            }
        }

        listRemindersInstance.properties = params

        if (!listRemindersInstance.save(flush: true)) {
            render(view: "edit", model: [listRemindersInstance: listRemindersInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), listRemindersInstance.id])
        redirect(action: "show", id: listRemindersInstance.id)
    }

    def delete() {
        def listRemindersInstance = ListReminders.get(params.id)
        if (!listRemindersInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "list")
            return
        }

        try {
            listRemindersInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'listReminders.label', default: 'ListReminders'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
