package captrack

import grails.converters.JSON
import groovy.sql.Sql
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class CapTrackController {
	def dataSource
	def aitLookup
	
	
    def index() {
		getUser()
		redirect(action: "customize", params: params)
	}
	
	def getUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size() > 0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")	
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
	
	def customize() {
		getUser()
	}
	
	def getHelpContent(){
		def dbh = new Sql(dataSource)
		println "Got here"
		if (params.helpident){
			def getHelpdata = """\
				select capacity_workflow_help.help_subj,capacity_workflow_help.help_text
				from hotpdb.capacity_workflow_help where 
			capacity_workflow_help.help_key = '"""+params.helpident+"""'
			"""
			
			def result = dbh.rows(getHelpdata)
			render result as JSON			
		}
	}
	
	def convert(){
		def db1 = new Sql(dataSource)
		def aitID = params.id
		
		DateFormat df = new SimpleDateFormat("yyyyMMdd")
		Date date = new Date()
		def todaydate = df.format(date);
		
		if (aitID){
			def enableString = """\
				update hotpdb.capacity_workflow_master set enable_flag = 'False',
				dashboard_flag = 0, dashboard = null, forecast = null, 
				advanceservice = null, selfassessment = null, adhocassessment = null 
				where capacity_workflow_master.aitnumber = ${aitID}
			"""
			def dataCreate = db1.executeUpdate(enableString)
			
			def delReminders = "delete from hotpdb.capacity_workflow_reminders where hotpdb.capacity_workflow_reminders.aitnumber = ${aitID}"
			db1.execute(delReminders)
			
			def delStatus = "delete from hotpdb.capacity_workflow_status where hotpdb.capacity_workflow_status.aitnumber = ${aitID}"
			db1.execute(delStatus)
			
			redirect(controller: "ListAccounts", action: "list")
			
		} else{
			render "No data sent!!!"
		}
		
		
		
	}
	
	def sendMainframes(){
		def db1 = new Sql(dataSource)
		
		def aitID = params.aitnum
		def userName = params.userName
		
		DateFormat df = new SimpleDateFormat("yyyyMMdd")
		Date date = new Date()
		def todaydate = df.format(date);
		
		if (params.aitnum){
			def enableString = """\
				update hotpdb.capacity_workflow_master set enable_flag='False', processed='True',
				primary_contact = '${userName}',createdate = '${todaydate}' 
				where capacity_workflow_master.aitnumber = ${aitID}
			"""
		
			//println enableString
			def dataCreate = db1.executeUpdate(enableString)
			redirect(controller: "ListAccounts", action: "list")
			
		} else{
			render "No data sent!!!"
		}
	}
	
	
	def aitLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname, 
			capacity_workflow_master.aitnumber as ait_aitnumber,capacity_workflow_master.gwbscan,
			capacity_workflow_master.aittier, capacity_workflow_master.ucal_flag,
			capacity_workflow_master.dashboard_flag,capacity_workflow_master.db_link,
			capacity_workflow_master.appmanager,capacity_workflow_master.second_support, 
			capacity_workflow_master.sec_email,capacity_workflow_master.processed FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%') 
			LIMIT 10
		"""
		//println queryString
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def dashboardLookup(){
		def db1 = new Sql(dataSource)
		def dbLookup = params.dbLookup
		
		def queryString = """\
			select capacity_dashboard_masterhub.db_link 
			from hotpdb.capacity_dashboard_masterhub 
			where capacity_dashboard_masterhub.aits LIKE '"""+dbLookup+"""%'
			OR capacity_dashboard_masterhub.ait_shortname LIKE '"""+dbLookup+"""%'
			LIMIT 10
		"""
		//println queryString
		def result = db1.rows(queryString)
		render result as JSON
	}
	
	def nextDate(inputfreq,refdate){
		def nextupdate
		//println "Inputs received " + inputfreq + " and " + refdate
		DateFormat df = new SimpleDateFormat("yyyyMMdd")
		
		use ( TimeCategory ) {
			if (inputfreq == "Monthly"){
				nextupdate = df.format(refdate + 1.months)
			}else if (inputfreq == "Quarterly"){
				nextupdate = df.format(refdate + 3.months)
			}else if (inputfreq == "Semi-Annually"){
				nextupdate = df.format(refdate + 6.months)
			}
			else if (inputfreq == "Annually"){
				nextupdate = df.format(refdate + 12.months)
			}else{
				nextupdate = 0
			}
		}
		return nextupdate	
	}
	
	/** Run updates for already existing AIT **/
	def runUpdate(publisheddate,aitno,statfield,color){
		def dbupdate = new Sql(dataSource)
		def updateReminders
		
		if (publisheddate == null){
			updateReminders = "update hotpdb.capacity_workflow_reminders set "+statfield+"_rem = 0 where aitnumber = ${aitno}"
		}else{
			updateReminders = "update hotpdb.capacity_workflow_reminders set "+statfield+"_rem = ${publisheddate} where aitnumber = ${aitno}"
		}
		
		dbupdate.execute(updateReminders)
		
		def statusString = """\
			update hotpdb.capacity_workflow_status set """+statfield+"""_status='${color}'
			where aitnumber = ${aitno}
		"""
		dbupdate.execute(statusString)
	}
	
	def getUpdates(){
		def db = new Sql(dataSource)
		
		// Collect all the required FORM DATA
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		params.remove('username')
		
		def aitID = params.int('aitLookup')
		def aitName = params.get('appsname')
		def ssdashboard = params.get('ssdashboard')
		def ssforecast = params.get('ssforecast')
		def saservice = params.get('saservice')
		def selfassessment = params.get('selfassessment')
		def adhocassessment = params.get('adhocassessment')
		def capliaison = params.get('capliaison')
		def remindemail = params.get('remindemail')
		
		def secLookup = params.get('secLookup')
		def secemail = params.get('secemail')
		
		def date_got = params.get('date_added')
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date_received = df.parse(date_got);
		
		def date_added = date_got.replace("-","");
		
		//-- RUN THE UPDATE QUERY to MASTER TABLE
		
		def queryString = """\
			Update hotpdb.capacity_workflow_master set capliaison='${capliaison}',
			dashboard='${ssdashboard}',forecast='${ssforecast}',advanceservice='${saservice}',
			adhocassessment='${adhocassessment}',selfassessment='${selfassessment}',
			createdate='${date_added}',secondary_contact='${secLookup}',
			secondary_email='${secemail}', primary_contact='${capliaison}',primary_email='${remindemail}', 
			processed='True' where aitnumber = ${aitID}
		"""
		
		//println "Initiating Master Table Update:" + queryString
		def data2Update = db.executeUpdate(queryString)
		
		//Calculate REMINDER DATES for each Entry
		def dashboardColor, forecastColor, selfassessColor, adhocassessColor, sasColor
		def dashboarddate = nextDate(ssdashboard,date_received)
		
		if (dashboarddate != 0){
			dashboardColor='green'
		}else{
			dashboardColor='gray'
		}
		
		def forecastdate = nextDate(ssforecast,date_received)
		if (forecastdate != 0){
			forecastColor='green'
		}else{
			forecastColor='gray'
		}
		
		def selfassessdate = nextDate(selfassessment,date_received)
		if (selfassessdate != 0){
			selfassessColor='green'
		}else{
			selfassessColor='gray'
		}
		
		def adhocassessdate = nextDate(adhocassessment,date_received)
		if (adhocassessdate != 0){
			adhocassessColor='green'
		}else{
			adhocassessColor='gray'
		}
		
		def sasdate =  nextDate(saservice,date_received)
		if (sasdate != 0){
			sasColor='green'
		}else{
			sasColor='gray'
		}
		
		//-- CHECK IF THE REMINDER TABLE HAS OLD ENTRIES, IF SO UPDATE. IF NOT, CREATE NEW
		def lookupString = """\
			select capacity_workflow_reminders.aitnumber,capacity_workflow_reminders.wf_rid 
			from hotpdb.capacity_workflow_reminders where 
			aitnumber = ${aitID}
		"""
		List resultSet = db.rows(lookupString)
		
		def createString, statusString
		if (resultSet.isEmpty()){
			createString = """\
				insert into hotpdb.capacity_workflow_reminders (aitnumber,aitshortname,reminder_flag,
				sas_contact,sas_emailgroup,dashboard_rem,forecast_rem,selfassessment_rem,adhocassessment_rem,
				advanceservice_rem) values (${aitID},'${aitName}','Yes','DG GWB Capacity Planning',
				'dg.GWB_Capacity_Planning@bankofamerica.com',
				${dashboarddate},${forecastdate},${selfassessdate},${adhocassessdate},${sasdate})
			"""
			//println "New Reminders:"
			//println createString
			def dataCreate = db.execute(createString)
				
			statusString = """\
				insert into hotpdb.capacity_workflow_status (aitnumber,aitshortname,dashboard_status,forecast_status,
				selfassessment_status, adhocassessment_status, advanceservice_status) values 
				(${aitID},'${aitName}','${dashboardColor}','${forecastColor}','${selfassessColor}',
				'${adhocassessColor}','${sasColor}')
			"""
			//println "New Status Entry made!!"
			db.execute(statusString)
			
		}else{
		
		//--**** OLD ENTRY FOUND... UPDATING.... ****--//
			createString = """\
				update hotpdb.capacity_workflow_reminders set dashboard_rem = ${dashboarddate}, 
				forecast_rem = ${forecastdate}, selfassessment_rem = ${selfassessdate}, 
				adhocassessment_rem = ${adhocassessdate}, advanceservice_rem = ${sasdate} 
				where aitnumber = ${aitID}
			"""
			
			//println "Updating Already existing Reminders:" 
			//println createString
			def dataCreate = db.execute(createString)
			
			statusString = """\
				update hotpdb.capacity_workflow_status set dashboard_status='${dashboardColor}',
				forecast_status='${forecastColor}', selfassessment_status='${selfassessColor}',
				adhocassessment_status='${adhocassessColor}', advanceservice_status='${sasColor}' 
				where aitnumber = ${aitID}
			"""
			//println "Updating Already existing Status:"
			//println statusString
			db.execute(statusString)
		}
		
		redirect(controller: "ListAccounts", action: "list")
	}
}