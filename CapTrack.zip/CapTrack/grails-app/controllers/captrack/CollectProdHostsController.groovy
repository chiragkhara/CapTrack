package captrack

import grails.converters.JSON
import groovy.sql.Sql
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import org.apache.commons.lang.StringUtils
import groovy.time.TimeCategory

import java.sql.ResultSet;
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date


class CollectProdHostsController {
	
	def dataSource_ReadOnly
	
    def index() {
	
	}
	
	def getHostlist(){
		def db = new Sql(dataSource_ReadOnly)
		
		def hostString = """\
			select extdb.mdh_ait.AIT_AITNUMBER as AIT, mdh_compsys.compsys_hostname as Hostname,
			mdh_compsys.compsys_operatingenv as Environment, mdh_compsys.compsys_city as HostCity,
			extdb.dss_nos.ServerFunction as RunbookRoleData
			FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel ON
			mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
			INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
			LEFT JOIN extdb.dss_nos ON dss_nos.ServerName = mdh_compsys.compsys_hostname
			WHERE extdb.mdh_ait.ait_cto = 'GWBT&O' AND
			mdh_compsys.compsys_operatingenv in ('Contingency','Production') AND 
			mdh_compsys.COMPSYS_STATUS in ('In Use','Maintenance') AND 
			extdb.mdh_ait.AIT_AITNUMBER = ${params.aitnumber}
			order by mdh_compsys.compsys_operatingenv desc, mdh_compsys.compsys_hostname asc
		"""
		
		def configureList = db.rows(hostString)
		render configureList as JSON	
	}
	
	def getData(aitnumber){
		def db = new Sql(dataSource_ReadOnly)
		
		def hostString = """\
			select extdb.mdh_ait.AIT_AITNUMBER as AIT, mdh_compsys.compsys_hostname as Hostname, 
			mdh_compsys.compsys_operatingenv as Environment, mdh_compsys.compsys_city as HostCity,
			extdb.dss_nos.ServerFunction as RunbookRoleData FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel 
			ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS INNER JOIN extdb.mdh_ait 
			ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID LEFT JOIN extdb.dss_nos 
			ON dss_nos.ServerName = mdh_compsys.compsys_hostname WHERE extdb.mdh_ait.ait_cto = 'GWBT&O' 
			AND mdh_compsys.compsys_operatingenv in ('Contingency','Production') AND
			mdh_compsys.COMPSYS_STATUS in ('In Use','Maintenance') AND extdb.mdh_ait.AIT_AITNUMBER = ${aitnumber}
			order by mdh_compsys.compsys_operatingenv desc, mdh_compsys.compsys_hostname asc
		"""
		
		def configureList = db.rows(hostString)
		return configureList
	}
	
	def getAITData(aitnumber){
		def db = new Sql(dataSource_ReadOnly)
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,capacity_workflow_master.aittier,
			capacity_workflow_master.ucal_flag,capacity_workflow_master.dashboard_flag,
			capacity_workflow_master.processed FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitnumber+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitnumber+"""%')
		"""
		
		def result = db.rows(queryString)
		return result
	}
}
