package captrack

import org.springframework.dao.DataIntegrityViolationException
import groovy.sql.Sql
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import org.apache.commons.lang.StringUtils
import grails.converters.JSON
import java.sql.ResultSet;
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class AdminController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        [registerInstanceList: Register.list(params)]
    }

    def create() {
        [registerInstanceList: new Register(params)]
    }

    def save() {
        def registerInstance = new Register(params)
        if (!registerInstance.save(flush: true)) {
            render(view: "create", model: [registerInstance: registerInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'register.label', default: 'Register'), registerInstance.id])
        redirect(action: "show", id: registerInstance.id)
    }

    def show() {
        def registerInstance = Register.get(params.id)
        if (!registerInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
            redirect(action: "list")
            return
        }

        [registerInstance: registerInstance]
    }

    def edit() {
		def db = new Sql(dataSource)
        def registerInstance = params.id
		
		if (!registerInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
			redirect(action: "list")
			return
		}
		
		def rolecodeQuery = """\
			select hotpdb.ait_dnt_roles.ait as AITNum,hotpdb.ait_dnt_roles.shortname as SName,
			hotpdb.ait_dnt_roles.hostname as Hostname, hotpdb.ait_dnt_roles.role as RoleCode 
			FROM hotpdb.ait_dnt_roles WHERE ait_dnt_roles.ait = ${registerInstance}
		"""
		
		def roledata = db.rows(rolecodeQuery)
        [ registerInstance: roledata ]
		
		
    }

    def update() {
        def registerInstance = Register.get(params.id)
        if (!registerInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (registerInstance.version > version) {
                registerInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'register.label', default: 'Register')] as Object[],
                          "Another user has updated this MasterTable while you were editing")
                render(view: "edit", model: [registerInstance: registerInstance])
                return
            }
        }

        registerInstance.properties = params

        if (!registerInstance.save(flush: true)) {
            render(view: "edit", model: [registerInstance: registerInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'register.label', default: 'Register'), registerInstance.id])
        redirect(action: "show", id: registerInstance.id)
    }

    def delete() {
        def registerInstance = Register.get(params.id)
        if (!registerInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
            redirect(action: "list")
            return
        }

        try {
            registerInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'register.label', default: 'Register'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'register.label', default: 'Register'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
