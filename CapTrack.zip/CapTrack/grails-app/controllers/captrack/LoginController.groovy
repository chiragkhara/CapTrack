package captrack

import com.bankofamerica.gwbio.ia.LDAPFunctions.*
import grails.converters.JSON
import java.text.DateFormat
import java.text.SimpleDateFormat
import javax.servlet.http.Cookie
import grails.converters.JSON
import groovy.sql.Sql
import groovy.time.TimeCategory


class LoginController {
	def dataSource
	
	def confirm(){
		def statfield = params.statusfield
		def aitID = params.aitnumber
	
		[statusfield: statfield, aitnumber: aitID]
	}
	
	def testAcknowledges(){
		render "The acknowledgement Action was cancelled!!<br />" + 
			"Click <a href='/CapTrack/accountStatus/list'>here</a> to go to the CapTrack status page and search for your AIT."
	}
	
	
	/* --- Acknowledges The Reminders and updates with next date --- */
	def updateAcknowledges(){
		def db1 = new Sql(dataSource)
		def statfield = params.statusfield
		def aitID = params.aitnumber
		
		DateFormat df = new SimpleDateFormat("yyyyMMdd")
		Date date = new Date()
		def todaydate = df.format(date);
		
		if (params.statusfield){
			def querydate = """\
			select a."""+statfield+""" as rowval, b."""+statfield+"""_rem as dataval, c."""+statfield+"""_status as colorval 
			from hotpdb.capacity_workflow_master a, hotpdb.capacity_workflow_reminders b, hotpdb.capacity_workflow_status c
			where a.aitnumber = b.aitnumber and a.aitnumber = c.aitnumber and a.aitnumber = ${aitID}
			"""
			println querydate
			def dategot = db1.firstRow(querydate).dataval
			def mnthgot = db1.firstRow(querydate).rowval
			def colorgot = db1.firstRow(querydate).colorval
			def nextupdate
			
			if (colorgot == "green"){
				redirect(controller: "AccountStatus", action: "duedatepast")
			}else{
			
				use ( TimeCategory ) {
					if (mnthgot == "Monthly"){
					nextupdate = df.format(dategot + 1.months)
					}else if (mnthgot == "Quarterly"){
					nextupdate = df.format(dategot + 3.months)
					}else if (mnthgot == "Semi-Annually"){
					nextupdate = df.format(dategot + 6.months)
					}
					else if (mnthgot == "Annually"){
					nextupdate = df.format(dategot + 12.months)
					}else{
					nextupdate = df.format(dategot + 3.months)
					}
				}
				
				def updateString = """\
					update hotpdb.capacity_workflow_reminders 
					set """+statfield+"""_rem='${nextupdate}' where aitnumber = ${aitID}
				"""
				//println updateString
				def upd = db1.executeUpdate(updateString)
					
				def createString = """\
					update hotpdb.capacity_workflow_status set capacity_workflow_status
					."""+statfield+"""_ack_date='${todaydate}',
					capacity_workflow_status."""+statfield+"""_status='green',
					capacity_workflow_status."""+statfield+"""_flag=0 
						where capacity_workflow_status.aitnumber = ${aitID}
				"""
					
				//println createString
				def dataCreate = db1.executeUpdate(createString)
				redirect(controller: "AccountStatus", action: "listack")
			} 
		}
		else {
			render "Please acknowledge manually!"
		}
	}
	
	/*---Redirect to the CapTracker index page  ---*/
    def index() { 
		redirect(controller: "capTracker", action: "index")
    }
	
	def tooltip() {
		redirect(controller: "capTracker", action: "tooltip")
	}
	
	def getHelpContent(){
		def dbh = new Sql(dataSource)
		
		if (params.helpident){
			def getHelpdata = """\
				select capacity_workflow_help.help_subj,capacity_workflow_help.help_text
				from hotpdb.capacity_workflow_help where
			capacity_workflow_help.help_key = '"""+params.helpident+"""'
			"""
			
			def result = dbh.rows(getHelpdata)
			
			render result as JSON
		}
	}
		
	def searchAssociate(){
		def results
		if(params.searchName){
			   LDAPSearch search = new LDAPSearch();
			   search.LDAPComplexSearch(params.searchName);
			   results = search.getResultsList()
		}else{
					  results = [:]
					  results.put("Error", "No search term")
		}
		render results as JSON
	}
		
	def searchByNBK(){
		def results
		if(params.searchName){
			   LDAPSearch search = new LDAPSearch(params.searchName);
			   results = search.getResultsList()
		}else{
					  results = [:]
					  results.put("Error", "No search term")
		}
		render results as JSON
	}
}
