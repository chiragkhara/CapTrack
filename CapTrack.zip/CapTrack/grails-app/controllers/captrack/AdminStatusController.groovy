package captrack

import org.springframework.dao.DataIntegrityViolationException

import captrack.AdminStatus;

class AdminStatusController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        [adminStatusInstanceList: AdminStatus.list(params)]
    }

    def create() {
        [adminStatusInstance: new AdminStatus(params)]
    }

    def save() {
        def adminStatusInstance = new AdminStatus(params)
        if (!adminStatusInstance.save(flush: true)) {
            render(view: "create", model: [adminStatusInstance: adminStatusInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), adminStatusInstance.id])
        redirect(action: "show", id: adminStatusInstance.id)
    }

    def show() {
        def adminStatusInstance = AdminStatus.get(params.id)
        if (!adminStatusInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "list")
            return
        }

        [adminStatusInstance: adminStatusInstance]
    }

    def edit() {
        def adminStatusInstance = AdminStatus.get(params.id)
        if (!adminStatusInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "list")
            return
        }

        [adminStatusInstance: adminStatusInstance]
    }

    def update() {
        def adminStatusInstance = AdminStatus.get(params.id)
        if (!adminStatusInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (adminStatusInstance.version > version) {
                adminStatusInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'adminStatus.label', default: 'AdminStatus')] as Object[],
                          "Another user has updated this AdminStatus while you were editing")
                render(view: "edit", model: [adminStatusInstance: adminStatusInstance])
                return
            }
        }

        adminStatusInstance.properties = params

        if (!adminStatusInstance.save(flush: true)) {
            render(view: "edit", model: [adminStatusInstance: adminStatusInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), adminStatusInstance.id])
        redirect(action: "show", id: adminStatusInstance.id)
    }

    def delete() {
        def adminStatusInstance = AdminStatus.get(params.id)
        if (!adminStatusInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "list")
            return
        }

        try {
            adminStatusInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'adminStatus.label', default: 'AdminStatus'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
