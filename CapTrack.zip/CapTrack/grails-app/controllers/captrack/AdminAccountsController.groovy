package captrack

import org.springframework.dao.DataIntegrityViolationException

class AdminAccountsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
		def configureList = AdminAccounts.findAll("from AdminAccounts as LA where LA.processed = 'true' and LA.advanceservice is not null and LA.advanceservice <> 'N/A'")
		[adminAccountsInstanceList: configureList]
    }
	
	def reporting() {
		def configureList = AdminAccounts.findAll("from AdminAccounts as LA where LA.processed = 'true' and LA.enable_flag = 'true'")
		[adminAccountsInstanceList: configureList]
	}

    def create() {
        [adminAccountsInstance: new AdminAccounts(params)]
    }

    def save() {
        def adminAccountsInstance = new AdminAccounts(params)
        if (!adminAccountsInstance.save(flush: true)) {
            render(view: "create", model: [adminAccountsInstance: adminAccountsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), adminAccountsInstance.id])
        redirect(action: "show", id: adminAccountsInstance.id)
    }

    def show() {
        def adminAccountsInstance = AdminAccounts.get(params.id)
        if (!adminAccountsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "list")
            return
        }

        [adminAccountsInstance: adminAccountsInstance]
    }

    def edit() {
        def adminAccountsInstance = AdminAccounts.get(params.id)
        if (!adminAccountsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "list")
            return
        }

        [adminAccountsInstance: adminAccountsInstance]
    }

    def update() {
        def adminAccountsInstance = AdminAccounts.get(params.id)
        if (!adminAccountsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (adminAccountsInstance.version > version) {
                adminAccountsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'adminAccounts.label', default: 'AdminAccounts')] as Object[],
                          "Another user has updated this AdminAccounts while you were editing")
                render(view: "edit", model: [adminAccountsInstance: adminAccountsInstance])
                return
            }
        }

        adminAccountsInstance.properties = params

        if (!adminAccountsInstance.save(flush: true)) {
            render(view: "edit", model: [adminAccountsInstance: adminAccountsInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), adminAccountsInstance.id])
		redirect(action: "list")
        //redirect(action: "show", id: adminAccountsInstance.id)
    }

    def delete() {
        def adminAccountsInstance = AdminAccounts.get(params.id)
        if (!adminAccountsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "list")
            return
        }

        try {
            adminAccountsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'adminAccounts.label', default: 'AdminAccounts'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
