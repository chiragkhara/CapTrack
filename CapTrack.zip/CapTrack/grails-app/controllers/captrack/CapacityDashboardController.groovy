package captrack

import grails.converters.JSON
import groovy.sql.Sql
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import org.apache.commons.lang.StringUtils
import groovy.time.TimeCategory

import java.sql.ResultSet;
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class CapacityDashboardController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource
	def aitLookup
	
    def index() {
        getUser()
		redirect(action: "list", params: params)
    }
	
	def selectmove(){
	}
	
	def dashboardData(){
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		
		def aitnum = params.get('aitLookup')
		def aitshortname = params.get('aitSName')
		
		java.util.Date date_got = new java.util.Date();
		def uniqueKey = date_got.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_added = df.format(date_got);
		
		def user_id = params.get('user_name')
		def email = params.get('email')
		
		def getProdReference = new CollectProdHostsController()
		def getProdHosts = getProdReference.getData(aitnum)
		
		def roletype, hostname, rolecode, envcode, role_notation, notIncludeFlag, cityCode
		
		getProdHosts.each { row ->
			hostname = row.Hostname
			rolecode = params.get('IHOSTS-' + hostname)
			cityCode = row.HostCity
			envcode = row.Environment.substring(0,4)
			
			if (rolecode.contains("Do Not Include")){
				println "Reached Here!!!"
				def insertnotInclude = """\
				insert into hotpdb.ait_dnt_roles
				(ait,shortname,hostname,role_selected,include_flag,host_added_date)
				values (?,?,?,?,?,?)
			"""
				def notIncData = [aitnum,aitshortname,hostname,rolecode,0,date_added]
				db.execute(insertnotInclude, notIncData)
			} else {
				roletype = getRoleCode(rolecode)
				if ((cityCode == "null") || (cityCode == null) || (cityCode == "")){
					role_notation = aitshortname + " " + envcode + " " + roletype
				} else {
				
					role_notation = aitshortname + " " + cityCode + " " + envcode + " " + roletype
				}
				
				def insertRole = """\
					insert into hotpdb.ait_dnt_roles
					(ait,shortname,hostname,role,role_selected,host_added_date)
					values (?,?,?,?,?,?)
				"""
				def roleData = [aitnum,aitshortname,hostname,role_notation.toUpperCase(),rolecode,date_added]
				db.execute(insertRole, roleData)
				
			}
		}
		
		/*-- Register the AIT into the MASTER TABLE -- */
		
		def insertAIT, masterData, masterReport
		insertAIT = """\
			insert into hotpdb.ait_dnt_mstr (ait,shortname,createdate,owner,email)
			values (?,?,?,?,?)
		"""
		masterData = [aitnum,aitshortname,date_added,user_id,email]
		masterReport = db.execute(insertAIT, masterData)
		
		/*-- PREVENT the DEFINITIONS TO BE REPEATED FOR AIT --*/
		
		def updateCapTrack = """\
			update hotpdb.capacity_workflow_master set hotpdb.capacity_workflow_master.dashboard_flag = 1
			where hotpdb.capacity_workflow_master.aitnumber = ${aitnum}
		""";
		db.execute(updateCapTrack)
		
		
		redirect(controller: "listAccounts", action: "list")	
	}
	
	
	/*Get Role Types -  */
	def getRoleTypes(){
		def db = new Sql(dataSource)
		def roleString = "select ait_dnt_roletypes.roletype as Role from hotpdb.ait_dnt_roletypes"
		def roleData = db.rows(roleString).Role
		render roleData as JSON
	}
	
	/* Get Role Code - Get the ASSOCIATED CODE for each Role Type selected by the user */
	
	def getRoleCode(roletype){
		def db = new Sql(dataSource)
		
		def rolecodeQuery = """\
			select hotpdb.ait_dnt_roletypes.role_identifier as ROLEID
			FROM hotpdb.ait_dnt_roletypes WHERE ait_dnt_roletypes.roletype = ${roletype}
		"""
				
		return db.firstRow(rolecodeQuery).ROLEID
	}
	
	
	def aitLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,capacity_workflow_master.aittier, 
			capacity_workflow_master.ucal_flag,capacity_workflow_master.dashboard_flag,
			capacity_workflow_master.processed FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%')
			LIMIT 10
		"""
		
		def result = db.rows(queryString)
		render result as JSON
	}
	
	
	def register() {
		getUser()
		
	}
	
	def newregister() {
		getUser()
		
		def getProdReference, getProdHosts, aitData
		if (params.aitnumber){
			getProdReference = new CollectProdHostsController()
			getProdHosts = getProdReference.getData(params.aitnumber)
			//println getProdHosts.Runbookvals
			aitData = getProdReference.getAITData(params.aitnumber)
			[registerHostsList : getProdHosts, aitDataList : aitData]
			
		} else {
			render "Error in calling the function. Add params aitnumber!"
		}		
	}
	

    def list() {
		def aitnumber = params.id
		def hostRoles = CapacityDashboard.findAll("from CapacityDashboard as CD where CD.ait = ${aitnumber}")
		
        [capacityDashboardInstanceList: hostRoles]
    }
	
	
	def userlist() {
		def aitnumber = params.id
		def hostRoles = CapacityDashboard.findAll("from CapacityDashboard as CD where CD.ait = ${aitnumber}")
		
		[capacityDashboardInstanceList: hostRoles]
	}
	
	def edit() {
		def capacityDashboardInstance = CapacityDashboard.get(params.id)
		if (!capacityDashboardInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
			redirect(action: "list")
			return
		}

		[capacityDashboardInstance: capacityDashboardInstance]
	}
	
	def useredit() {
		getUser()
		def capacityDashboardInstance = CapacityDashboard.get(params.id)
		if (!capacityDashboardInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'register.label', default: 'Register'), params.id])
			redirect(action: "list")
			return
		}

		[capacityDashboardInstance: capacityDashboardInstance]
	}
	
	def save() {
		def capacityDashboardInstance = new CapacityDashboard(params)
		if (!capacityDashboardInstance.save(flush: true)) {
			render(view: "create", model: [capacityDashboardInstance: capacityDashboardInstance])
			return
		}

		flash.message = message(code: 'default.created.message', args: [message(code: 'CapacityDashboard.label', default: 'CapacityDashboard'), capacityDashboardInstance.id])
		redirect(action: "list", id: capacityDashboardInstance.id)
	}
	
	def userupdate() {
		getUser()
		def db = new Sql(dataSource)
		def capacityDashboardInstance = CapacityDashboard.get(params.id)
		
		if (!capacityDashboardInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'CapacityDashboard.label', default: 'CapacityDashboard'), params.id])
			redirect(action: "list")
			return
		}

		if (params.version) {
			def version = params.version.toLong()
			if (capacityDashboardInstance.version > version) {
				capacityDashboardInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
						  [message(code: 'CapacityDashboard.label', default: 'CapacityDashboard')] as Object[],
						  "Another user has updated this entry while you were editing")
				render(view: "edit", model: [capacityDashboardInstance: capacityDashboardInstance])
				return
			}
		}
		
		println "Role before " + capacityDashboardInstance.role_selected
		capacityDashboardInstance.properties = params
		
		def rolecode = params.get("role_selected")
		def aitnumber = capacityDashboardInstance.ait;
		def hostname = capacityDashboardInstance.hostname;
		def aitshortname = capacityDashboardInstance.shortname;
		
		def manual_user = session['name']
		
		println "Role after " + capacityDashboardInstance.role_selected
		
		def queryupdate = """\
			select mdh_compsys.compsys_operatingenv as Environment, mdh_compsys.compsys_city as HostCity
			FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel ON
			mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
			INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
			where extdb.mdh_ait.AIT_AITNUMBER = ${aitnumber} and 
			mdh_compsys.compsys_hostname = '${hostname}'
			""";
		
		def envName = db.firstRow(queryupdate).Environment
		def cityCode = db.firstRow(queryupdate).HostCity
		def envcode = envName.substring(0,4)
		
		println envcode + " - " + cityCode
		
		java.util.Date date_got = new java.util.Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_formatted = df.format(date_got);
		Date date_added = df.parse(date_formatted);
		
		/*-- UPDATE CODE -- */
		
		def role_notation
		if (rolecode.contains("Do Not Include")){
		/*	def updatenotInclude = """\
			update hotpdb.ait_dnt_roles set role = null, include_flag = 0, edit_flag = 1,
			manual_edit_user = '${manual_user}', manual_edit_date = ${date_added} where 
			ait = ${aitnumber} and hostname = '${hostname}'
		"""
		*/
			capacityDashboardInstance.role = null
			capacityDashboardInstance.edit_flag = 1
			capacityDashboardInstance.include_flag = 0
			capacityDashboardInstance.manual_edit_user = manual_user
			capacityDashboardInstance.manual_edit_date = date_added
			
		} else {
			def roletype = getRoleCode(rolecode)
			if ((cityCode == "null") || (cityCode == null) || (cityCode == "")){
				role_notation = aitshortname + " " + envcode + " " + roletype
			} else {
			
				role_notation = aitshortname + " " + cityCode + " " + envcode + " " + roletype
			}
			
			capacityDashboardInstance.role = role_notation.toUpperCase()
			capacityDashboardInstance.edit_flag = 1
			capacityDashboardInstance.include_flag = 1
			capacityDashboardInstance.manual_edit_user = manual_user
			capacityDashboardInstance.manual_edit_date = (java.util.Date) date_added
			
			println "Hostname = " + hostname + ", Role Code = " + role_notation.toUpperCase()
		}
		 
		redirect(action: "userlist", params: [id: aitnumber])
	}
	
	def update() {
		getUser()
		def db = new Sql(dataSource)
		def capacityDashboardInstance = CapacityDashboard.get(params.id)
		def aitnumber = params.get("ait")

		if (!capacityDashboardInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'CapacityDashboard.label', default: 'CapacityDashboard'), params.id])
			redirect(action: "list")
			return
		}

		if (params.version) {
			def version = params.version.toLong()
			if (capacityDashboardInstance.version > version) {
				capacityDashboardInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
						  [message(code: 'CapacityDashboard.label', default: 'CapacityDashboard')] as Object[],
						  "Another user has updated this entry while you were editing")
				render(view: "edit", model: [capacityDashboardInstance: capacityDashboardInstance])
				return
			}
		}
		
		def manual_user = session['name']
		java.util.Date date_got = new java.util.Date();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_formatted = df.format(date_got);
		Date date_added = df.parse(date_formatted);
		
		capacityDashboardInstance.properties = params
		
		/* -- CAPACITY DASHBOARD - In case user does not add a ROLE or removes the existing -- */
		if ((capacityDashboardInstance.role != null) || (capacityDashboardInstance.role != "")){
			capacityDashboardInstance.edit_flag = 2
			capacityDashboardInstance.include_flag = 1
			capacityDashboardInstance.manual_edit_user = manual_user
			capacityDashboardInstance.manual_edit_date = date_added
		} else {
			capacityDashboardInstance.include_flag = 0
		}

		
		if (!capacityDashboardInstance.save(flush: true)) {
			render(view: "edit", model: [capacityDashboardInstance: capacityDashboardInstance])
			return
		}

		redirect(action: "list", params: [id: aitnumber])
	}
	
	
	
	def getUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
}
