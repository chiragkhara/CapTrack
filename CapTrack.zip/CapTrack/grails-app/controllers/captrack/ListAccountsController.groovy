package captrack

import org.springframework.dao.DataIntegrityViolationException;

import captrack.ListAccounts;

import com.bankofamerica.gwbio.ia.LDAPFunctions.*;
import grails.converters.JSON;
import java.sql.PreparedStatement
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import javax.servlet.http.Cookie;
import grails.converters.JSON;
import groovy.sql.Sql;
import groovy.time.TimeCategory;
import java.util.Date;

class ListAccountsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource

    def index() {
        redirect(action: "list", params: params)
    }
	
	def list() {
		def configureList = ListAccounts.findAllByCreatedateIsNotNull()
		[listAccountsInstanceList: configureList]
	}
	

    def create() {
        [listAccountsInstance: new ListAccounts(params)]
    }

	
	def checkAdvanceService(){
		def db1 = new Sql(dataSource)
		if (params.aitnumber){
			def aitID = params.aitnumber
			
			def enableString = """\
				select hotpdb.capacity_workflow_master.aittier as aittier,hotpdb.capacity_workflow_master.ucal_flag as ucalflag
				from hotpdb.capacity_workflow_master where hotpdb.capacity_workflow_master.aitnumber = ${aitID}
			"""
			
			def firstRow  = db1.firstRow(enableString)
			def aittier = firstRow.aittier
			def ucalflag = firstRow.ucalflag
			def result = [:]
			if ((aittier == 0) || (aittier == 1) || (ucalflag == 1)){
				result['success'] = true;
			}else{
				result['success'] = false;
			}
			render result as JSON
		}
	}
	
    def save() {
        def listAccountsInstance = new ListAccounts(params)
        if (!listAccountsInstance.save(flush: true)) {
            render(view: "create", model: [listAccountsInstance: listAccountsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), listAccountsInstance.id])
        redirect(action: "show", id: listAccountsInstance.id)
    }

    def show() {
        def listAccountsInstance = ListAccounts.get(params.id)
        if (!listAccountsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "backuplist")
            return
        }

        [listAccountsInstance: listAccountsInstance]
    }
	
/* Calculating Reminder date on update action */
	
	def nextDate(inputfreq,refdate){
		def nextupdate
		println "Inputs received " + inputfreq + " and " + refdate
		DateFormat df = new SimpleDateFormat("yyyyMMdd")
		
		use ( TimeCategory ) {
			if (inputfreq == "Monthly"){
				nextupdate = df.format(refdate + 1.months)
			}else if (inputfreq == "Quarterly"){
				nextupdate = df.format(refdate + 3.months)
			}else if (inputfreq == "Semi-Annually"){
				nextupdate = df.format(refdate + 6.months)
			}
			else if (inputfreq == "Annually"){
				nextupdate = df.format(refdate + 12.months)
			}else{
				nextupdate = 0
			}
		}
		return nextupdate
	}
	

	//-- Get AIT data after UPDATE for 
	def updateAITwithReminderDate(instancenumber)
	{
		def dbupdate = new Sql(dataSource)
		def getAITData = """\
			select capacity_workflow_master.dashboard, capacity_workflow_master.forecast,
				capacity_workflow_master.selfassessment, capacity_workflow_master.adhocassessment,
				capacity_workflow_master.advanceservice,capacity_workflow_master.createdate as myDate from
				hotpdb.capacity_workflow_master where aitnumber = ${instancenumber}
			"""
		def updated_date = dbupdate.firstRow(getAITData).myDate
		
		
			//-- Calculate REMINDER DATES for each Entry
		def dashboardcolor, forecastcolor, selfassesscolor, adhocassesscolor, sascolor
		def dashboarddate = nextDate(dbupdate.firstRow(getAITData).dashboard,updated_date)
		if (dashboarddate != 0){
			dashboardcolor='green'
		}else{
			dashboardcolor='gray'
		}
		
		def forecastdate = nextDate(dbupdate.firstRow(getAITData).forecast,updated_date)
		if (forecastdate != 0){
			forecastcolor='green'
		}else{
			forecastcolor='gray'
		}
		
		
		
		def selfassessdate = nextDate(dbupdate.firstRow(getAITData).selfassessment,updated_date)
		if (selfassessdate != 0){
			selfassesscolor='green'
		}else{
			selfassesscolor='gray'
		}
		
		def adhocassessdate = nextDate(dbupdate.firstRow(getAITData).adhocassessment,updated_date)
		if (adhocassessdate != 0){
			adhocassesscolor='green'
		}else{
			adhocassesscolor='gray'
		}
		
		def sasdate = nextDate(dbupdate.firstRow(getAITData).advanceservice,updated_date)
		if (sasdate != 0){
			sascolor='green'
		}else{
			sascolor='gray'
		}
		
		def updateDBString = """\
			update hotpdb.capacity_workflow_reminders set dashboard_rem = ${dashboarddate}, 
			forecast_rem = ${forecastdate}, selfassessment_rem = ${selfassessdate}, 
			adhocassessment_rem = ${adhocassessdate}, advanceservice_rem = ${sasdate} 
			where aitnumber = ${instancenumber}
		"""
		
		//println "Updating Already existing Reminders:"
		//println updateDBString
		dbupdate.execute(updateDBString)
		
		def statusDBString = """\
			update hotpdb.capacity_workflow_status set dashboard_status='${dashboardcolor}',
			forecast_status='${forecastcolor}', selfassessment_status='${selfassesscolor}',
			adhocassessment_status='${adhocassesscolor}', advanceservice_status='${sascolor}'
			where aitnumber = ${instancenumber}
		"""
		
		//println "Updating Already existing Status:"
		println statusDBString
		dbupdate.execute(statusDBString)
		
	}
	
	//-- 
	def runUpdate(publisheddate,aitno,statfield,color){
		def dbupdate = new Sql(dataSource)
		def updateReminders
		
		if (publisheddate == 0){
			updateReminders = "update hotpdb.capacity_workflow_reminders set "+statfield+"_rem = 0 where aitnumber = ${aitno}"
		}else{
			updateReminders = "update hotpdb.capacity_workflow_reminders set "+statfield+"_rem = ${publisheddate} where aitnumber = ${aitno}"
		}
		//println "Updating Already existing Reminders:"
		//println updateReminders
		dbupdate.execute(updateReminders)
		
		def statusString = """\
			update hotpdb.capacity_workflow_status set """+statfield+"""_status='${color}' 
			where aitnumber = ${aitno}
		"""
		
		//println "Updating Already existing Status:"
		//println statusString
		dbupdate.execute(statusString)
	}
	
    def edit() {
        def listAccountsInstance = ListAccounts.get(params.id)
        if (!listAccountsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "list")
            return
        }
        [listAccountsInstance: listAccountsInstance]
    }
	

    def update() {
        def listAccountsInstance = ListAccounts.get(params.id)
        if (!listAccountsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (listAccountsInstance.version > version) {
                listAccountsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'listAccounts.label', default: 'ListAccounts')] as Object[],
                          "Another user has updated this ListAccounts while you were editing")
                render(view: "edit", model: [listAccountsInstance: listAccountsInstance])
                return
            }
        }
		
		def date_got = params.get('createdate')
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd");
		Date date_received = df.parse(date_got);
		params.createdate = date_received
		
        listAccountsInstance.properties = params

        if (!listAccountsInstance.save(flush: true)) {
            render(view: "edit", model: [listAccountsInstance: listAccountsInstance])
            return
        }

		//println "Got to update: " + listAccountsInstance
		updateAITwithReminderDate(listAccountsInstance.aitnumber)
		redirect(controller: "ListAccounts", action: "list")
    }

    def delete() {
        def listAccountsInstance = ListAccounts.get(params.id)
        if (!listAccountsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "list")
            return
        }

        try {
            listAccountsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'listAccounts.label', default: 'ListAccounts'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
