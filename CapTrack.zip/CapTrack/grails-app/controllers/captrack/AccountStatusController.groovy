package captrack

import org.springframework.dao.DataIntegrityViolationException

import captrack.AccountStatus;
import groovy.sql.Sql;
import grails.converters.JSON

class AccountStatusController {
	def dataSource
    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }
	
	/*-- THIS Subroutine should no longer be needed --*/
	def getDBLink(){
		def db1 = new Sql(dataSource)
		if (params.aitnumber){
			def aitID = params.aitnumber
			def queryString="""\
				select hotpdb.capacity_workflow_master.db_link from 
				hotpdb.capacity_workflow_master where 
				hotpdb.capacity_workflow_master.aitnumber= ${aitID}
			"""
			println queryString
			def firstRow  = db1.firstRow(queryString).db_link
			redirect(url: firstRow)
		}
	}
	
	/*-- THIS Subroutine should no longer be needed --*/
	def aitDataLookup(){
		def db = new Sql(dataSource)
		def queryString = """\
			Select capacity_workflow_status.aitnumber, capacity_workflow_status.dashboard_status, 
			capacity_workflow_status.forecast_status, capacity_workflow_status.selfassessment_status, 
			capacity_workflow_status.adhocassessment_status,capacity_workflow_status.advanceservice_status  
			from hotpdb.capacity_workflow_status
		"""
		//println queryString
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def listack() {
		[accountStatusInstanceList: AccountStatus.list(params)]
	}
	
	def duedatepast() {
		[accountStatusInstanceList: AccountStatus.list(params)]
	}

	
	def list() {
		[accountStatusInstanceList: AccountStatus.list(params)]
	}

    def create() {
        [accountStatusInstance: new AccountStatus(params)]
    }

    def save() {
        def accountStatusInstance = new AccountStatus(params)
        if (!accountStatusInstance.save(flush: true)) {
            render(view: "create", model: [accountStatusInstance: accountStatusInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), accountStatusInstance.id])
        redirect(action: "show", id: accountStatusInstance.id)
    }

    def show() {
        def accountStatusInstance = AccountStatus.get(params.id)
        if (!accountStatusInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "list")
            return
        }

        [accountStatusInstance: accountStatusInstance]
    }

    def edit() {
        def accountStatusInstance = AccountStatus.get(params.id)
        if (!accountStatusInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "list")
            return
        }

        [accountStatusInstance: accountStatusInstance]
    }

    def update() {
        def accountStatusInstance = AccountStatus.get(params.id)
        if (!accountStatusInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (accountStatusInstance.version > version) {
                accountStatusInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'accountStatus.label', default: 'AccountStatus')] as Object[],
                          "Another user has updated this AccountStatus while you were editing")
                render(view: "edit", model: [accountStatusInstance: accountStatusInstance])
                return
            }
        }

        accountStatusInstance.properties = params

        if (!accountStatusInstance.save(flush: true)) {
            render(view: "edit", model: [accountStatusInstance: accountStatusInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), accountStatusInstance.id])
        redirect(action: "show", id: accountStatusInstance.id)
    }

    def delete() {
        def accountStatusInstance = AccountStatus.get(params.id)
        if (!accountStatusInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "list")
            return
        }

        try {
            accountStatusInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'accountStatus.label', default: 'AccountStatus'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
