use DBI;
use strict;
use Getopt::Long;
use Time::HiRes qw(usleep gettimeofday tv_interval stat);

#default assignment
my $debug = 0;
my $test = 0;

my $options = GetOptions(
	"debug=i" => \$debug, # int
	"test=i" => \$test, # int
);

#compare existing items to data feed
my $inserts = 0;
my $updates = 0;

sub getDocuments
{
	#
	#get list of MRDs from mrdb.documents

	my $dbh = shift;

	my $t0 = [gettimeofday];
	my $sql = qq(select documentId, ait, umid, revision, status from Documents);
	my $sth = $dbh->prepare($sql); 
	$sth->execute();
	my $e1 = tv_interval ($t0, [gettimeofday]);
	
	#my $rows = $sth->rows();
	#print "Database query getDocuments() returned [$rows] rows in [$e1] second(s)\n";
		
	my $documents = $sth->fetchall_hashref('documentId');
	$sth->finish();
	
	return($documents);
}

sub formatUmidPrimaryKey
{
	my $d = shift;
	my $orig = $d;
	my $code = 0;

	if ($d =~ m/\s+|\t+/)
	{ 
		print "Removing whitespace from [$d]\n" if ($debug);
		$d =~ s/\s+|\t+//g;
		print "Reformatted: orig [$orig] new [$d]\n" if ($debug);
		$code = 1;
	}
	
	if ($d =~ m/^0+0$/) #eg 00000
	{ 
		print "Removing leading zero's from [$d]\n" if ($debug);
		$d = 0;
		print "Reformatted: orig [$orig] new [$d]\n" if ($debug);
		$code = 1;
	}
	elsif ($d =~ m/^0+/) #eg 0012343
	{ 
		print "Removing leading zero's from [$d]\n" if ($debug);
		$d =~ s/0*(\d+)/$1/;
		print "Reformatted: orig [$orig] new [$d]\n" if ($debug);
		$code = 1;
	}
	if ($d =~ m/\D+|^\s*$/)
	{
		print "Removing record with non integer or empty PK [$d]\n" if ($debug);
		#delete
		$code = 2;
	}
	elsif ($d > 5000000)
	{
		print "Removing record with corrupt PK > 5000k [$d]\n" if ($debug);
		#delete
		$code = 2;
	}
	return($orig, $d, $code)
}

sub getItmUmids
{
	#
	#get list of UMIDS with ITM application monitoring
	#

	my $dbh = shift;

	my $t0 = [gettimeofday];
	my $sql = qq(select UMID, 5 as 'ITM_VERSION', MMI from MMI_ITM5
	where MMI > 1
	union
	select UMID, 6 as 'ITM_VERSION', MMI from MMI_ITM6
	where MMI > 1);
	my $sth = $dbh->prepare($sql); 
	$sth->execute();
	my $e1 = tv_interval ($t0, [gettimeofday]);
	
	#my $rows = $sth->rows();
	#print "Database query getDocuments() returned [$rows] rows in [$e1] second(s)\n";
		
	my $documents = $sth->fetchall_hashref('UMID');
	$sth->finish();

	foreach my $d (keys %{$documents})
	{
		my ($orig, $new, $code) = formatUmidPrimaryKey($d);
		if ($code == 1)
		{
			#update
			$documents->{$new} = $documents->{$orig};
			$documents->{$new}->{UMID} = $new;
			delete $documents->{$orig};
			print "Updating PK: old [$orig] New [$new] UMID:[$documents->{$new}->{UMID}]\n" if ($debug);
		}
		elsif ($code == 2)
		{
			print "Removing PK: old [$orig] UMID:[$documents->{$orig}->{UMID}]\n" if ($debug);
			delete $documents->{$orig};
		}
		else
		{
			#print "Leaving PK: old [$orig] New [$new] UMID:[$documents->{$new}->{UMID}]\n" if ($debug);
		}
	}

	return($documents);
}

sub selectByUmid
{
	#
	#get list of UMIDs with vam monitoring
	#

	my $dbh = shift;
	my $query = shift;

	my $t0 = [gettimeofday];
	my $sql = qq($query);
	my $sth = $dbh->prepare($sql); 
	$sth->execute();
	my $e1 = tv_interval ($t0, [gettimeofday]);
	
	#my $rows = $sth->rows();
	#print "Database query getDocuments() returned [$rows] rows in [$e1] second(s)\n";
		
	my $documents = $sth->fetchall_hashref('UMID');
	$sth->finish();

	foreach my $d (keys %{$documents})
	{
		my ($orig, $new, $code) = formatUmidPrimaryKey($d);
		if ($code == 1)
		{
			#update
			$documents->{$new} = $documents->{$orig};
			$documents->{$new}->{UMID} = $new;
			delete $documents->{$orig};
			print "Updating PK: old [$orig] New [$new] UMID:[$documents->{$new}->{UMID}]\n" if ($debug);
		}
		elsif ($code == 2)
		{
			print "Removing PK: old [$orig] UMID:[$documents->{$orig}->{UMID}]\n" if ($debug);
			delete $documents->{$orig};
		}
		else
		{
			print "Leaving PK: old [$orig] New [$new] UMID:[$documents->{$new}->{UMID}]\n" if ($debug);
		}
	}

	return($documents);
}

sub compareHashes
{
	my $hash1 = shift;
	my $hash2 = shift;
	my $index = shift | 'default';

	my $rc = 0;

	my $map = {};
	
	$map->{document}->{documentId} = 'document_id';
	$map->{document}->{ait} = 'app_id';
	$map->{document}->{umid} = 'umid';
	$map->{document}->{revision} = 'revision';
	$map->{document}->{status} = 'status';

	$map->{umid_to_mmi}->{UMID} = 'umid';
	$map->{umid_to_mmi}->{ITM_VERSION} = 'itm_version';
	$map->{umid_to_mmi}->{MMI} = 'mmi';

	$map->{umid_to_introscope_mmi}->{UMID} = 'umid';
	$map->{umid_to_introscope_mmi}->{MMI} = 'mmi';

	$map->{umid_to_foglight_mmi}->{UMID} = 'umid';
	$map->{umid_to_foglight_mmi}->{MMI} = 'mmi';

	$map->{umid_to_sitescope_mmi}->{UMID} = 'umid';
	$map->{umid_to_sitescope_mmi}->{MMI} = 'mmi';

	$map->{default}->{UMID} = 'umid';
	$map->{default}->{MMI} = 'mmi';
	
	foreach my $key (keys %{$map->{$index}})
	{
		if ($hash1->{$key} == $hash2->{"$map->{$index}->{$key}"})
		{
			#print "Identical: $hash1->{$key} == $hash2->{$map->{$index}->{$key}}\n";
		}
		else
		{
			print "Different: $hash1->{$key} != $hash2->{$map->{$index}->{$key}}\n";
			$rc = 1;
			last;
		}
	}
	return($rc);
}

sub upsertDocuments
{
	#
	#upsert MRD inserts/updates into hotpdb.mon_documents
	#

	my $dbh = shift;
	my $documents = shift;

	eval
	{
		my $sql = qq(select document_id, app_id, umid, revision, status from mon_document);
		my $sth = $dbh->prepare($sql);
		$sth->execute();
		my $tmpDocuments = $sth->fetchall_hashref('document_id');

		#remove stale records from hotpd
		foreach my $tmp (keys %{$tmpDocuments})
		{
			#check for an entry with the same primary key in the latest mrdb export
			if (!defined $documents->{$tmp})
			{
				print "Record with PK [$tmp] was not found in the latest export - removing\n";
			}
		}

		#setup the bind queries
		my $insert_sql = qq( );
		my $insert_sth = $dbh->prepare($insert_sql);

		my $update_sql = qq(update mon_document set app_id=?, umid=?, revision=?, status=? where document_id=?);
		my $update_sth = $dbh->prepare($update_sql);	


		foreach my $record (keys %{$documents})
		{
			#is there an existing record
			if (defined $tmpDocuments->{$record})
			{
				my $rc = compareHashes($documents->{$record},$tmpDocuments->{$record},'document');
				if ($rc == 1)
				{
					#an update is required
					$update_sth->execute($documents->{$record}->{ait},$documents->{$record}->{umid},$documents->{$record}->{revision},$documents->{$record}->{status},$documents->{$record}->{documentId});
				}
			}
			else
			{
				#an insert is required
				$insert_sth->execute($documents->{$record}->{documentId},$documents->{$record}->{ait},$documents->{$record}->{umid},$documents->{$record}->{revision},$documents->{$record}->{status});
			}
		}

		$dbh->commit;
	};

	if ($@) 
	{
		warn "Database error: $DBI::errstr\n";
    		$dbh->rollback(); #just die if rollback is failing
	}
}

sub upsertItmUmids
{
	#
	#upsert MRD inserts/updates into hotpdb.mon_documents
	#

	my $dbh = shift;
	my $documents = shift;

	eval
	{
		my $sql = qq(select umid, itm_version, mmi from mon_itm_mmi);
		my $sth = $dbh->prepare($sql);
		$sth->execute();
		my $tmpDocuments = $sth->fetchall_hashref('umid');

		#remove stale records from hotpd
		foreach my $tmp (keys %{$tmpDocuments})
		{
			#check for an entry with the same primary key in the latest mrdb export
			if (!defined $documents->{$tmp})
			{
				print "Record with PK [$tmp] was not found in the latest export - removing\n";
			}
		}

		#setup and prepare the bind queries
		my $insert_sql = qq(insert into mon_itm_mmi (umid, itm_version, mmi) values (?,?,?));
		my $insert_sth = $dbh->prepare($insert_sql);

		my $update_sql = qq(update mon_itm_mmi set itm_version=?, mmi=? where umid=?);
		my $update_sth = $dbh->prepare($update_sql);	


		foreach my $record (keys %{$documents})
		{
			#is there an existing record
			if (defined $tmpDocuments->{$record})
			{
				my $rc = compareHashes($documents->{$record},$tmpDocuments->{$record},'umid_to_mmi');
				if ($rc == 1)
				{
					#an update is required
					$update_sth->execute($documents->{$record}->{ITM_VERSION},$documents->{$record}->{MMI},$documents->{$record}->{UMID});
				}
			}
			else
			{
				#an insert is required
				print "inserting primary key [$documents->{$record}->{UMID}] from source data record [$record]\n";
				$insert_sth->execute($documents->{$record}->{UMID},$documents->{$record}->{ITM_VERSION},$documents->{$record}->{MMI});
			}
		}

		$dbh->commit;
	};

	if ($@) 
	{
		warn "Database error: $DBI::errstr\n";
    		$dbh->rollback(); #just die if rollback is failing
	}
}

sub upsertUmidToMmi
{
	#
	#upsert MRD inserts/updates into
	#

	my $dbh = shift;
	my $documents = shift;
	my $dstTable = shift;

	eval
	{
		# -- Entries in HOTPDB DB ($tmpDocuments)
		my $sql = qq(select umid, mmi from $dstTable);
		my $sth = $dbh->prepare($sql);
		$sth->execute();
		my $tmpDocuments = $sth->fetchall_hashref('umid');

		#remove stale records from hotpd
		foreach my $tmp (keys %{$tmpDocuments})
		{
			#check for an entry with the same primary key in the latest mrdb export
			if (!defined $documents->{$tmp})
			{
				print "Record with PK [$tmp] was not found in the latest export - removing\n";
			}
		}

		#setup and prepare the bind queries
		my $insert_sql = qq(insert into $dstTable (umid, mmi) values (?,?));
		my $insert_sth = $dbh->prepare($insert_sql);

		my $update_sql = qq(update $dstTable set mmi=? where umid=?);
		my $update_sth = $dbh->prepare($update_sql);	


		foreach my $record (keys %{$documents})
		{
			#is there an existing record
			if (defined $tmpDocuments->{$record})
			{
				my $rc = compareHashes($documents->{$record},$tmpDocuments->{$record});
				if ($rc == 1)
				{
					#an update is required
					print "updating primary key [$documents->{$record}->{UMID}] from source data record [$record]\n";
					$update_sth->execute($documents->{$record}->{MMI},$documents->{$record}->{UMID});
				}
			}
			else
			{
				#an insert is required
				print "inserting primary key [$documents->{$record}->{UMID}] from source data record [$record]\n";
				$insert_sth->execute($documents->{$record}->{UMID},$documents->{$record}->{MMI});
			}
		}

		$dbh->commit;
	};

	if ($@) 
	{
		warn "Database error: $DBI::errstr\n";
    		$dbh->rollback(); #just die if rollback is failing
	}
}

sub createHandle
{
	my $dsn = shift;
	my $user = shift;
	my $passwd = shift;
	my $dbh = DBI->connect("dbi:ODBC:$dsn", $user, $passwd) 
		|| die "Database connection not made: $DBI::errstr";
	$dbh->{AutoCommit} = 0; 					#turn off auto commit
	$dbh->{RaiseError} = 1;
	return($dbh);
}

sub main
{
	my $mrdbH = createHandle('MRDB','monread','read321sql');
	my $monmetH = createHandle('MONMET','monread','read321sql');
	my $hotpdbH = createHandle('HOTPDB');
	
	#############################################################		
	######	Stage 1. get documents from monmet
	#############################################################
	#
	my $documents = getDocuments($mrdbH);
	upsertDocuments($hotpdbH,$documents);
	
	my $itmUmids = getItmUmids($monmetH);
	upsertItmUmids($hotpdbH,$itmUmids);

	#now derived from hotpdb.introscopeserverjamaits
	#my $introscopeUmids = selectByUmid($monmetH,'select UMID, MMI from MMI_INTROSCOPE');
	#upsertUmidToMmi($hotpdbH,$introscopeUmids,'mon_introscope_mmi');

	#data now taken from extdb.mon_fgl_monitor_info
	#my $foglightUmids = selectByUmid($monmetH,'select UMID, MMI from MMI_PAC_Foglight');
	#upsertUmidToMmi($hotpdbH,$foglightUmids, 'mon_foglight_mmi');

	my $sitescopeUmids = selectByUmid($monmetH,'select UMID, MMI from MMI_SS');
	upsertUmidToMmi($hotpdbH,$sitescopeUmids,'mon_sitescope_mmi');
	
	#small number of records now maintained manually in hotpdb.mon_non_mmi
	#my $vamUmids = selectByUmid($monmetH,'select UMID, MMI from MMI_VAM');
	#upsertUmidToMmi($hotpdbH,$vamUmids,'mon_vam_mmi');
	
	#monmet data is stale so this data is now manually maintained in hotpdb.mon_non_mmi
	#my $saasUmids = selectByUmid($monmetH,'select UMID, MMI from MMI_PAC_BPM');
	#upsertUmidToMmi($hotpdbH,$saasUmids,'mon_hp_saas_mmi');
	
	$mrdbH->disconnect();
	$monmetH->disconnect();
	$hotpdbH->disconnect();
}

main;