sub main
{
  open(NETUITIVE_R, "< ./netuitive.txt") or die "failed to open ./netuitive.txt for r";
  open(NETUITIVE_W, "> ./netuitive.csv") or die "failed to open ./netuitive.csv for w";

  my @contents = <NETUITIVE_R>;
  foreach my $line (@contents)
  {
    chomp($line);
    my @entries = split(" ", $line);
    foreach my $entry (@entries)
    {
      chomp($entry);
      print "$entry\n";
      print NETUITIVE_W "$entry\n";
    }
  }

  close (NETUITIVE_R);
  close (NETUITIVE_W);
}

main;