#!/usr/bin/perl
####----
##### update auto_ait2host a join itmstats b on a.hostname = b.hostname set a.itm_flag = 1;
##### Affected rows: 7,042  Found rows: 0  Warnings: 0  Duration for 1 query: 00:25:39 */
####----

use strict;
use DBI;
use DBD::mysql;
use XML::LibXML;

my $platform = "mysql";
my $database = "hotpdb";
my $host = "lcdra76577.cdr-p01.chp.bankofamerica.com";
my $port = "3307";
my $dsn = "dbi:$platform:$database:$host:$port";
my $dbh = createHandle("zkaqrvs","ch1rag3nter");
my $parser = XML::LibXML->new();

my $getSQL = "select hostname,environment from auto_ait2host where environment".
				" in ('Production','Contingency') and hostname = 'TX8MRHUB010'";

my $sth = $dbh->prepare($getSQL);
$sth->execute;

while (my @row = $sth->fetchrow_array()){
        my $hosttocheck = $row[0];
        my $hostenv = $row[1];
		&itmcheck($hosttocheck);
        #print "$hosttocheck :- $hostenv\n";
}
$dbh->disconnect();

###################################################################################
# Function		: itmcheck
# Description	:  

# Input(s)		: Configname (String)
# Return(s)		: None
#####################################################################################

sub itmcheck
{
	my $hostname = shift;
	my $xmlData=`/app/chirag/ITM_Tools/itm-inventory.pl getagent $hostname`;
	
	if ( $? == -1 ){
		print "Command failed: $!\n";
		exit(1);
	}

	my $xmldoc = $parser->parse_string($xmlData);
	for my $sample ($xmldoc->findnodes('/NewDataSet/ROW')) {
		my $product_name = $sample->findvalue('Product');
			if ($product_name eq 'LO') {
				&updateFlags("itm_lo_flag",$hostname);
			} elsif ($product_name eq 'UX') {
				&updateFlags("itm_flag",$hostname);
			} else{
				print "Unknown \n";
			}
	}
}

###################################################################################
# Function		: createHandle
# Description	:  

# Input(s)		: Configname (String)
# Return(s)		: None
#####################################################################################

sub createHandle
{
	my $user = shift;
	my $passwd = shift;
	my $dbh = DBI->connect($dsn, $user, $passwd) 
		|| die "Database connection not made: $DBI::errstr";
	$dbh->{AutoCommit} = 0; 					#turn off auto commit
	$dbh->{RaiseError} = 1;
	return($dbh);
}

###################################################################################
# Function		: updateFlags
# Description	:  

# Input(s)		: Configname (String)
# Return(s)		: None
#####################################################################################

sub updateFlags
{
	my $field = shift;
	my $hostupdate = shift;
	my $sqltorun = "update auto_ait2host set ".$field."=1 where hostname = ".$hostupdate;
	print "Checking Query : $sqltorun \n";
	#my $stupdate = $dbh->prepare($sqltorun); 
	#$sthupdate->execute();
}