#############################################################################################
###     Script          :       bluestripe-userstats.pl
###     Version         : 1.0.1
###
###     Author          :       Chirag Khara (Chirag.Khara@bankofamerica.com)
###     Author 2        :       Ian Raeburn (ian.c.raeburn@baml.com)
###
###     Description     : This script extracts all users logged in to Bluestripe daily along with
###                                     no. of logons. It stores the information in a central Database, which
###                                     contains information of mgmt server, userid and no. of logons
###
###     Input(s)        : /var/log/bluestripe-management-server/FactFinderMS.log*
###
###     Output(s)       : Entries into DATABASE for the Bluestripe Userstats
###
###
#############################################################################################

use strict;
use DBI;
use DBD::mysql;

#-- CONFIG VARIABLES
my @userids;
my $platform = "mysql";
my $database = "hotpdb";
my $host = "lcdra76577.cdr-p01.chp.bankofamerica.com";
my $port = "3307";
my $user = "zkaqrvs";
my $pw = "ch1rag3nter";
my $mgmhost = `hostname`;
$mgmhost =~ s/\n//g;

#-- DATA SOURCE NAME
my $dsn = "dbi:$platform:$database:$host:$port";

#-- PERL DBI CONNECT
my $DBIconnect = DBI->connect($dsn, $user, $pw)
                                or die "Unable to connect: $DBI::errstr\n";

#------------------------------
#-- MAIN PROGAM LOGIC BEGINS --
#------------------------------
my @run=`find /var/log/bluestripe-management-server -name \"FactFinderMS.lo*\" -mtime -1 -exec grep \"User .* logged in successfully\" \{\} \\\;`;
if ( $? == -1 ){
   print "Command failed: $!\n";
   exit(1);
 }

#-- Example log entry
#-- 2014-01-27 08:47:41,171 [RMI TCP Connection(24)-165.43.89.129] {INFO} FactFinder - User admin (Console) logged in successfully
# -- PATTERN MATCH ALL LOG ENTRIES TO EXTRACT USERID
foreach (@run) {
        if ($_ =~ m/\d{4}.*,\d+ \[RMI.*FactFinder - User (\w+).* logged in successfully.*/) {
                push(@userids,lc($1));
        }
}

#-- CREATE HASH OF UNIQUE USER AND ITS COUNT
my %usercounts;
my @res = grep { !$usercounts{$_}++ } @userids;

#-- CALL TO UPDATE EACH VALUES (IF NOT PREVIOUSLY RECORDED) INTO DB
foreach my $userkey (keys %usercounts) {
	        #-- print "$userkey logged on $usercounts{$userkey} times on the Bluestripe console\n";
        &updateDBwithValues($mgmhost,$userkey,$usercounts{$userkey});
}

#-- DB Function
#################################################################################################
# Subroutine  : updateDBwithValues{
# Description :  Updates database with user stats information if not already existed in DB.

# Input(s)      : management server name, username, user_session_counts

# Return(s)     : None
#################################################################################################

sub updateDBwithValues{
        my $mgmt_hostname = $_[0];
        my $username = $_[1];
        my $Ucount = $_[2];

#-- print "$mgmt_hostname,$username,$Ucount\n";

my $sth = $DBIconnect->prepare("select userid from bluestripe_userstats where userid = '$username' and date = curdate() and mgmt_server = '$mgmt_hostname'");
$sth->execute;

    if (defined (my $count = $sth->fetchrow_arrayref)) {
		               #print "User Entry already exists in the Database\n";
    }else{
                my $stmt = "insert into bluestripe_userstats(mgmt_server,userid,no_logons,date) values ('$mgmt_hostname','$username',$Ucount,curdate())";
        #print "Inserting New User update - ".$stmt."\n";
        my $sth = $DBIconnect->prepare($stmt);
        $sth->execute || die "execute: $stmt : $DBI::errstr";
    }
}
