#!/usr/bin/perl
use strict;
my @names = ("zkaqrvs", "nbkdxge", "admin", "nbkfyxx");
my @userids; my @run;

foreach my $role (@names) {
   @run=`./ldap_listuser $role | grep \"displayName:\" | cut -d':' -f2 2>&1`;

   foreach  (@run) {
      if ($_ =~ m/\s+(\S+)\,\s+(\S+).*/) {
         push(@userids,"$2 $1");
         print "User:$2 $1\n";
      }
   }
}