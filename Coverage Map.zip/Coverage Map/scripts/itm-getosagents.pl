#!/usr/bin/perl
use strict;
use DBI;
use DBD::mysql;
use Getopt::Long;
use XML::LibXML;

#default assignment
my $debug = 0;
my $test = 0;
my $options = GetOptions(
	"debug=i" => \$debug, # int
	"test=i" => \$test, # int
);

my $platform = "mysql";
my $database = "hotpdb";
my $host = "lcdra76577.cdr-p01.chp.bankofamerica.com";
my $port = "3307";
my $dsn = "dbi:$platform:$database:$host:$port";

my $parser = XML::LibXML->new();
my $dbh = createHandle("zkaqrvs","ch1rag3nter");

my $filename = "ITMALLSample.xml";
&getXMLData($filename,$dbh);

sub getXMLData{
	my $rolename = shift;
	my $dbhandle = shift;
	
	my $xmldoc = $parser->parse_file($rolename);
		for my $sample ($xmldoc->findnodes('/NewDataSet/ROW')) {
		my $HTEMS = $sample->findnodes('./HTEMs');
		my $agent_name = $sample->findnodes('./Name');
		my $host_name = $sample->findnodes('./Hostname');
		my $host_ip = $sample->findnodes('./Host_Address');
		my $host_OS = $sample->findnodes('./Host_Info');
		$host_OS =~ s/\~//g;
		my $agent_version = $sample->findnodes('./Version');
		my $agent_status = $sample->findnodes('./Status');
		$agent_status =~ s/\*//g;
		my $r4mflag = $sample->findnodes('./Ready4Monitoring');
		$aitdomain =~ s/\&amp\;/\-/g;
		my $regnloc = $sample->findnodes('./Region')."-".$sample->findnodes('./Location');
		my $isProd = $sample->findnodes('./isProduction');
		my $hasMQ = $sample->findnodes('./hasMQ');
		my $msl_lists = $sample->findnodes('./MSLs');
		$msl_lists =~ s/\;/ /g;
		#print "Row START ##########\nHostname = $host_name\n";
		my $sql = "insert into itmstats(agentname,hostname,agentstatus,agentversion,".
			"ipaddress,msllist,r4mflag,region_location,prod_flag,mq_flag,aitdomain) values ".
			"('$agent_name','$host_name','$agent_status','$agent_version','$host_ip',".
			"'$msl_lists','$r4mflag','$regnloc','$isProd','$hasMQ','$aitdomain')";
		print "$sql\n";
		#my $sthandle = $dbhandle->prepare($sql); 
		#$sthandle->execute();
		#$sthandle->finish();
	}
}

sub createHandle
{
	my $user = shift;
	my $passwd = shift;
	my $dbh = DBI->connect($dsn, $user, $passwd) 
		|| die "Database connection not made: $DBI::errstr";
	$dbh->{AutoCommit} = 0; 					#turn off auto commit
	$dbh->{RaiseError} = 1;
	return($dbh);
}

