#!/usr/bin/perl
use strict;
use DBI;
use DBD::mysql;
use Getopt::Long;
use XML::LibXML;

#default assignment
my $debug = 0;
my $test = 0;
my @names = ("Production", "NonProduction", "Development");
#my @names = ("Development");
my $options = GetOptions(
        "debug=i" => \$debug, # int
        "test=i" => \$test, # int
);

my $platform = "mysql";
my $database = "hotpdb";
my $host = "lcdra76577.cdr-p01.chp.bankofamerica.com";
my $port = "3307";
my $dsn = "dbi:$platform:$database:$host:$port";

my $parser = XML::LibXML->new();
my $dbh = createHandle("zkaqrvs","ch1rag3nter");

foreach my $role (@names) {
        &getXMLData($role,$dbh);
}

sub getXMLData{
        my $rolename = "Collector-".$_[0].".xml";
        my $dbhandle = $_[1];

        my $xmldoc = $parser->parse_file($rolename);
        for my $sample ($xmldoc->findnodes('/NewDataSet/Collectors')) {
                my $mgmt_server = $sample->findnodes('./FFMS');
                my $host_name = $sample->findnodes('./Name');
                my $host_ip = $sample->findnodes('./IPAddresses');
                my $host_OS = $sample->findnodes('./OSInfo');
                my $coll_version = $sample->findnodes('./Version');
                my $coll_status = $sample->findnodes('./Status');
                my $coll_type = $sample->findnodes('./TYPE');
                my $sql = "insert into bluestripestats(coll_version,osname,bs_hostname,primary_ip,mgmt_svr,host_env,agentstatus)".
                        " values ('$coll_version','$host_OS','$host_name','$host_ip','$mgmt_server','$coll_type','$coll_status')";
                print "$sql\n";
                my $sthandle = $dbhandle->prepare($sql);
                $sthandle->execute();
                $sthandle->finish();
        }
}

sub createHandle
{
        my $user = shift;
        my $passwd = shift;
        my $dbh = DBI->connect($dsn, $user, $passwd)
                || die "Database connection not made: $DBI::errstr";
        $dbh->{AutoCommit} = 0;                                         #turn off auto commit
        $dbh->{RaiseError} = 1;
        return($dbh);
}