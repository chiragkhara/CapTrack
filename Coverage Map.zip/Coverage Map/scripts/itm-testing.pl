#!/usr/bin/perl
use strict;
use DBI;
use DBD::mysql;
use XML::LibXML;

my $parser = XML::LibXML->new();
my $dbh = createHandle("zkaqrvs","ch1rag3nter");

my $filename = "ITMALLSample.xml";
&getXMLData($filename);

sub getXMLData{
	my $rolename = shift;
	my $host_name; my $sql;

    my $xmldoc = $parser->parse_file($rolename);
    for my $sample ($xmldoc->findnodes('/NewDataSet/ROW')) {
		
		# -- GET ALL COMMON ATTRIBUTES FIRST
		my $productID = $sample->findnodes('./Product');
		my $HTEMS = $sample->findnodes('./HTEMS');
		my $agent_name = $sample->findnodes('./Name');
		my $host_ip = $sample->findnodes('./Host_Address');
		my $host_OS = $sample->findnodes('./Host_Info');
		$host_OS =~ s/\~//g;
		my $agent_version = $sample->findnodes('./Version');
		my $agent_status = $sample->findnodes('./Status');
		$agent_status =~ s/\*//g;
		my $r4mflag = $sample->findnodes('./Ready4Monitoring');
		my $regnloc = $sample->findnodes('./Region')."-".$sample->findnodes('./Location');
		my $isProd = $sample->findnodes('./isProduction');
		my $hasMQ = $sample->findnodes('./hasMQ');
		my $msl_lists = $sample->findnodes('./MSLs');
		$msl_lists =~ s/\;/ /g;

		#-- CHECK FOR HOSTNAME if HOSTNAME NOT SET CORRECTLY
		my $hostid = $sample->findnodes('./Hostname');
        if ("$hostid" eq "LO") {
	        $host_name = $sample->findnodes('./Managing_System');
			$host_name =~ s/.*\:(.+)\:.*/$1/;
        }else{
            $host_name = $hostid;
        }

		#-- Ensure LO-Agent information is stored in different table
		if ("$productID" eq "LO") {
		$sql = "insert into itmlostats(agentname,hostname,productcode,agentversion,agentstatus,osname,".
			"ipaddress,r4mflag,msllist,htem,region_location,prod_flag,mq_flag) values ".
			"('$agent_name','$host_name','$productID','$agent_version','$agent_status','$host_OS','$host_ip',".
			"'$r4mflag','$msl_lists','$HTEMS','$regnloc','$isProd','$hasMQ')";
		}else{
		$sql = "insert into itmstats(agentname,hostname,productcode,agentversion,agentstatus,osname,".
			"ipaddress,r4mflag,msllist,htem,region_location,prod_flag,mq_flag) values ".
			"('$agent_name','$host_name','$productID','$agent_version','$agent_status','$host_OS','$host_ip',".
			"'$r4mflag','$msl_lists','$HTEMS','$regnloc','$isProd','$hasMQ')";
		}
		print "$sql\n";
		my $sthandle = $dbh->prepare($sql); 
		#$sthandle->execute();
		#$sthandle->finish();
	}
}

# - Disconnect DB Handler before Exit
$dbh->disconnect();


#############################################################################################################
# Function		: createHandle
# Description	:  

# Input(s)		: Configname (String)
# Return(s)		: None
#############################################################################################################

sub createHandle
{
	my $user = shift;
	my $passwd = shift;
	
	my $platform = "mysql";
	my $database = "hotpdb";
	my $host = "lcdra76577.cdr-p01.chp.bankofamerica.com";
	my $port = "3307";
	my $dsn = "dbi:$platform:$database:$host:$port";
	
	my $dbh = DBI->connect($dsn, $user, $passwd) 
		|| die "Database connection not made: $DBI::errstr";
	$dbh->{AutoCommit} = 0; 					#turn off auto commit
	$dbh->{RaiseError} = 1;
	return($dbh);
}