/app/chirag/ITM_Tools/itm-inventory.pl getbluestripecollectorbytype Development > /app/covmap/Collector-Development.xml
/app/chirag/ITM_Tools/itm-inventory.pl getbluestripecollectorbytype Non-Production > /app/covmap/Collector-NonProduction.xml
/app/chirag/ITM_Tools/itm-inventory.pl getbluestripecollectorbytype Production > /app/covmap/Collector-Production.xml
