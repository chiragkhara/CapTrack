DROP PROCEDURE IF EXISTS hotpdb.sp_mon_coverage_map_new;
CREATE PROCEDURE hotpdb.`sp_mon_coverage_map_new`()
BEGIN
  create temporary table if not exists tmp_coverage_map 
    (app_id int primary key, ait_flag int not null default 0, mrd_flag int not null default 0, 
      bhw_flag int not null default 0, tivoli_flag int not null default 0, 
      introscope_flag int not null default 0, foglight_flag int not null default 0, 
      sitescope_flag int not null default 0, vam_flag int not null default 0, 
      hp_saas_flag int not null default 0, bam_lite_flag int not null default 0, 
      console_works_flag int not null default 0, gas_flag int not null default 0,
      splunk_flag int not null default 0,
      bam_flag int not null default 0,
      cv_active_flag int not null default 0,
      proactive_flag int not null default 0,
      netuitive_flag int not null default 0,
      bluestripe_flag int not null default 0,
      gomez_flag int not null default 0,
      tbsm_flag int not null default 0,
      advanced_mq_flag int not null default 0,
      bhw_partial_flag int not null default 0);
  truncate table tmp_coverage_map;
  
  /* get the list of aits */
  insert into tmp_coverage_map (app_id, ait_flag, mrd_flag) 
    (select a.APP_ID, 1, b.MRD_FLAG
      from mon_vw_application a
      left join mon_vw_coverage_by_document b on a.APP_ID = b.APP_ID);
            
  /* check which aits have 100% bhw called out */
  update tmp_coverage_map set bhw_flag = 1
   where app_id in (
    select appid from mon_rpt_tivoli_dnt_cnt
    where (proditm5count + proditm6count + contitm5count + contitm6count) = (prodmgdhostcount + contmgdhostcount));

/* check which aits have partial bhw (1 or more hosts) called out */
  update tmp_coverage_map set bhw_partial_flag = 1
   where app_id in (
    select appid from mon_rpt_tivoli_dnt_cnt
    where (proditm5count + proditm6count + contitm5count + contitm6count) > 0);    

  /* check which aits have an umid with tivoli appliaction monitoring called out */
  update tmp_coverage_map set tivoli_flag = 1 
    where app_id in (select a.app_id from mon_vw_document_current a
    inner join mon_itm_mmi b on a.umid = b.umid);
    
  /* check which aits have an umid with introscope called out */
  /* updated to use hotp feed as this is now reliable */
  /*
  update tmp_coverage_map set introscope_flag = 1 
    where app_id in (select a.app_id from mon_vw_document_current a
    inner join mon_introscope_mmi b on a.umid = b.umid);
  */
  update tmp_coverage_map set introscope_flag = 1 
    where app_id in (select ait_id from mon_serverintroscopejvmaits);  
  
  /* check which aits have an umid with foglight called out */
  /* updated to use hotp feed as this is now reliable */
  /*
  update tmp_coverage_map set foglight_flag = 1 
    where app_id in (select e.ait_number from mon_foglight_hosts as a
      inner join ia_host b on a.hostname = b.hostname
      inner join ia_host_environment c on c.id_host = b.id_host
      inner join ia_environment d on c.id_env = d.id_env
      inner join ia_host_ait e on b.id_host = e.id_host
      where d.id_env in (16,19)
      group by e.ait_number);
  */
  update tmp_coverage_map set foglight_flag = 1 
    where app_id in (select e.ait_number from extdb.mon_fgl_monitor_info as a
      inner join ia_host b on a.host_name = b.hostname
      inner join ia_host_environment c on c.id_host = b.id_host
      inner join ia_environment d on c.id_env = d.id_env
      inner join ia_host_ait e on b.id_host = e.id_host
      where d.id_env in (16,19)
      group by e.ait_number);    

  /* check which aits have an umid with sitescope called out */
  update tmp_coverage_map set sitescope_flag = 1 
    where app_id in (select a.app_id from mon_vw_document_current a
    inner join mon_sitescope_mmi b on a.umid = b.umid);
  
  /* check which aits have an umid with vam called out */
  update tmp_coverage_map set vam_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.vam_flag = 1); 
 
  /* check which aits have an umid with hp_saas called out */
  update tmp_coverage_map set hp_saas_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.hpsaas_flag = 1);
  
  /* check which aits have an bam_lite called out */
  update tmp_coverage_map set bam_lite_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.bam_lite_flag = 1);
  
  /* check which aits have an console_works called out */
  update tmp_coverage_map set console_works_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.console_works_flag = 1); 
  
  /* check which aits have an gas called out */
  update tmp_coverage_map set gas_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.gas_flag = 1);     
  
  /* check which aits have an splunk called out */
  update tmp_coverage_map set splunk_flag = 1 
    where app_id in  
      (select e.ait_number from ia_splunk_prov_status as a
        inner join ia_host b on a.target_host = b.hostname
        inner join ia_host_environment c on c.id_host = b.id_host
        inner join ia_environment d on c.id_env = d.id_env
        inner join ia_host_ait e on b.id_host = e.id_host
        where d.id_env in (16,19)
       group by e.ait_number);
 
  /* check which aits have an bam called out */
  update tmp_coverage_map set bam_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.bam_flag = 1);
    
  /* check which aits have an cv_active called out */
  update tmp_coverage_map set cv_active_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.cv_active_flag = 1);

  /* check which aits have an netuitive called out */
  update tmp_coverage_map set netuitive_flag = 1 
    where app_id in (select e.ait_number from mon_netuitive_hosts as a
      inner join ia_host b on a.hostname = b.hostname
      inner join ia_host_environment c on c.id_host = b.id_host
      inner join ia_environment d on c.id_env = d.id_env
      inner join ia_host_ait e on b.id_host = e.id_host
      where d.id_env in (16,19)
      group by e.ait_number);

  /* check which aits have an bluestripe called out */
  update tmp_coverage_map set bluestripe_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.bluestripe_flag = 1);    
    
  /* check which aits have an gomez called out */
  update tmp_coverage_map set gomez_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.gomez_flag = 1);      
  
  /* check which aits have an tbsm called out */
  update tmp_coverage_map set tbsm_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.tbsm_flag = 1);
    
  /* check which aits have advacned mq (latency) monitoring called out */
  update tmp_coverage_map set advanced_mq_flag = 1 
    where app_id in (select a.app_id from mon_non_mmi a where a.advanced_mq_flag = 1);    
    
  /* select the data to return */
  select a.app_id, c.APP_FULL_NAME as 'app_full_name',
    a.mrd_flag, a.bhw_flag, a.tivoli_flag, a.introscope_flag, foglight_flag,
    sitescope_flag, vam_flag, hp_saas_flag, a.bam_lite_flag,
    a.console_works_flag, a.gas_flag, a.splunk_flag, a.bam_flag, a.cv_active_flag, 
    a.proactive_flag, a.netuitive_flag, a.bluestripe_flag, a.gomez_flag, a.ait_flag,
    h.report_group, e.name as 'category', g.name as 'architecture', a.tbsm_flag, 
    a.advanced_mq_flag, a.bhw_partial_flag
    from tmp_coverage_map a
    inner join mon_vw_application c on a.app_id = c.APP_ID
    inner join mon_coverage_hierarchy_level1 e on c.REPORT_GROUP = e.id
    inner join mon_coverage_hierarchy_level2 g on c.ARCHITECTURE = g.id    
    inner join mon_vw_coverage_threedot_grouping h on c.THREE_DOT_HIERARCHY_DESC = h.three_dot_hierarchy_desc
      and c.TECH_EXEC_lNAME = h.tech_exec_lname
      and c.TECH_EXEC_FNAME = h.tech_exec_fname;
      
  /* clean up */
  drop temporary table tmp_coverage_map;
END;
