#!/usr/bin/perl
   use IO::Socket;
   use Time::localtime;

  $remoteAddr = "crprchga1o8e.bankofamerica.com";
  $remotePort = "8084";
  $now = ctime();
  $arg_string=join(' ',@ARGV);

  if($socket = IO::Socket::INET->new (PeerAddr => $remoteAddr,
                        PeerPort => $remotePort,
                        Proto => "tcp",
                        Type => SOCK_STREAM)) 
  {             
     print $socket $arg_string;
     $output = "";
     $text = " ";
     while($text ne '') {
        die "no connection" unless $socket -> connected(); 
        $socket->recv($text,16384);
        if($text ne '')
        {
           $output =  $output . $text;
          # print $output;
        }
     }

     close ($socket);
     printf "$output\n";
 } else {
        print ("Could not connect to $remoteAddr:$remotePort: $@\n");
 }

