package oachecks



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(AssessFileSystem)
class AssessFileSystemTests {

    void testSomething() {
       fail "Implement me"
    }
}
