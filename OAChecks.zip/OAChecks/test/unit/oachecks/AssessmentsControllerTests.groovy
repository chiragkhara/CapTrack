package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(AssessmentsController)
@Mock(Assessments)
class AssessmentsControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/assessments/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.assessmentsInstanceList.size() == 0
        assert model.assessmentsInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.assessmentsInstance != null
    }

    void testSave() {
        controller.save()

        assert model.assessmentsInstance != null
        assert view == '/assessments/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/assessments/show/1'
        assert controller.flash.message != null
        assert Assessments.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/assessments/list'


        populateValidParams(params)
        def assessments = new Assessments(params)

        assert assessments.save() != null

        params.id = assessments.id

        def model = controller.show()

        assert model.assessmentsInstance == assessments
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/assessments/list'


        populateValidParams(params)
        def assessments = new Assessments(params)

        assert assessments.save() != null

        params.id = assessments.id

        def model = controller.edit()

        assert model.assessmentsInstance == assessments
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/assessments/list'

        response.reset()


        populateValidParams(params)
        def assessments = new Assessments(params)

        assert assessments.save() != null

        // test invalid parameters in update
        params.id = assessments.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/assessments/edit"
        assert model.assessmentsInstance != null

        assessments.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/assessments/show/$assessments.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        assessments.clearErrors()

        populateValidParams(params)
        params.id = assessments.id
        params.version = -1
        controller.update()

        assert view == "/assessments/edit"
        assert model.assessmentsInstance != null
        assert model.assessmentsInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/assessments/list'

        response.reset()

        populateValidParams(params)
        def assessments = new Assessments(params)

        assert assessments.save() != null
        assert Assessments.count() == 1

        params.id = assessments.id

        controller.delete()

        assert Assessments.count() == 0
        assert Assessments.get(assessments.id) == null
        assert response.redirectedUrl == '/assessments/list'
    }
}
