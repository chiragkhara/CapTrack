package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(Ait2hostController)
@Mock(Ait2host)
class Ait2hostControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/ait2host/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.ait2hostInstanceList.size() == 0
        assert model.ait2hostInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.ait2hostInstance != null
    }

    void testSave() {
        controller.save()

        assert model.ait2hostInstance != null
        assert view == '/ait2host/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/ait2host/show/1'
        assert controller.flash.message != null
        assert Ait2host.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/ait2host/list'


        populateValidParams(params)
        def ait2host = new Ait2host(params)

        assert ait2host.save() != null

        params.id = ait2host.id

        def model = controller.show()

        assert model.ait2hostInstance == ait2host
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/ait2host/list'


        populateValidParams(params)
        def ait2host = new Ait2host(params)

        assert ait2host.save() != null

        params.id = ait2host.id

        def model = controller.edit()

        assert model.ait2hostInstance == ait2host
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/ait2host/list'

        response.reset()


        populateValidParams(params)
        def ait2host = new Ait2host(params)

        assert ait2host.save() != null

        // test invalid parameters in update
        params.id = ait2host.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/ait2host/edit"
        assert model.ait2hostInstance != null

        ait2host.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/ait2host/show/$ait2host.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        ait2host.clearErrors()

        populateValidParams(params)
        params.id = ait2host.id
        params.version = -1
        controller.update()

        assert view == "/ait2host/edit"
        assert model.ait2hostInstance != null
        assert model.ait2hostInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/ait2host/list'

        response.reset()

        populateValidParams(params)
        def ait2host = new Ait2host(params)

        assert ait2host.save() != null
        assert Ait2host.count() == 1

        params.id = ait2host.id

        controller.delete()

        assert Ait2host.count() == 0
        assert Ait2host.get(ait2host.id) == null
        assert response.redirectedUrl == '/ait2host/list'
    }
}
