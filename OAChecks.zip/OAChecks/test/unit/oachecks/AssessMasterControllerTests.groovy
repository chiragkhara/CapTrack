package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(AssessMasterController)
@Mock(AssessMaster)
class AssessMasterControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/assessMaster/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.assessMasterInstanceList.size() == 0
        assert model.assessMasterInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.assessMasterInstance != null
    }

    void testSave() {
        controller.save()

        assert model.assessMasterInstance != null
        assert view == '/assessMaster/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/assessMaster/show/1'
        assert controller.flash.message != null
        assert AssessMaster.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/assessMaster/list'


        populateValidParams(params)
        def assessMaster = new AssessMaster(params)

        assert assessMaster.save() != null

        params.id = assessMaster.id

        def model = controller.show()

        assert model.assessMasterInstance == assessMaster
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/assessMaster/list'


        populateValidParams(params)
        def assessMaster = new AssessMaster(params)

        assert assessMaster.save() != null

        params.id = assessMaster.id

        def model = controller.edit()

        assert model.assessMasterInstance == assessMaster
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/assessMaster/list'

        response.reset()


        populateValidParams(params)
        def assessMaster = new AssessMaster(params)

        assert assessMaster.save() != null

        // test invalid parameters in update
        params.id = assessMaster.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/assessMaster/edit"
        assert model.assessMasterInstance != null

        assessMaster.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/assessMaster/show/$assessMaster.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        assessMaster.clearErrors()

        populateValidParams(params)
        params.id = assessMaster.id
        params.version = -1
        controller.update()

        assert view == "/assessMaster/edit"
        assert model.assessMasterInstance != null
        assert model.assessMasterInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/assessMaster/list'

        response.reset()

        populateValidParams(params)
        def assessMaster = new AssessMaster(params)

        assert assessMaster.save() != null
        assert AssessMaster.count() == 1

        params.id = assessMaster.id

        controller.delete()

        assert AssessMaster.count() == 0
        assert AssessMaster.get(assessMaster.id) == null
        assert response.redirectedUrl == '/assessMaster/list'
    }
}
