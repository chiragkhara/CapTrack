package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(CapacityIssuesController)
@Mock(CapacityIssues)
class CapacityIssuesControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/capacityIssues/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.capacityIssuesInstanceList.size() == 0
        assert model.capacityIssuesInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.capacityIssuesInstance != null
    }

    void testSave() {
        controller.save()

        assert model.capacityIssuesInstance != null
        assert view == '/capacityIssues/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/capacityIssues/show/1'
        assert controller.flash.message != null
        assert CapacityIssues.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/capacityIssues/list'


        populateValidParams(params)
        def capacityIssues = new CapacityIssues(params)

        assert capacityIssues.save() != null

        params.id = capacityIssues.id

        def model = controller.show()

        assert model.capacityIssuesInstance == capacityIssues
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/capacityIssues/list'


        populateValidParams(params)
        def capacityIssues = new CapacityIssues(params)

        assert capacityIssues.save() != null

        params.id = capacityIssues.id

        def model = controller.edit()

        assert model.capacityIssuesInstance == capacityIssues
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/capacityIssues/list'

        response.reset()


        populateValidParams(params)
        def capacityIssues = new CapacityIssues(params)

        assert capacityIssues.save() != null

        // test invalid parameters in update
        params.id = capacityIssues.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/capacityIssues/edit"
        assert model.capacityIssuesInstance != null

        capacityIssues.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/capacityIssues/show/$capacityIssues.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        capacityIssues.clearErrors()

        populateValidParams(params)
        params.id = capacityIssues.id
        params.version = -1
        controller.update()

        assert view == "/capacityIssues/edit"
        assert model.capacityIssuesInstance != null
        assert model.capacityIssuesInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/capacityIssues/list'

        response.reset()

        populateValidParams(params)
        def capacityIssues = new CapacityIssues(params)

        assert capacityIssues.save() != null
        assert CapacityIssues.count() == 1

        params.id = capacityIssues.id

        controller.delete()

        assert CapacityIssues.count() == 0
        assert CapacityIssues.get(capacityIssues.id) == null
        assert response.redirectedUrl == '/capacityIssues/list'
    }
}
