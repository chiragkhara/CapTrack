package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(BpInfranameController)
@Mock(BpInfraname)
class BpInfranameControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/bpInfraname/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.bpInfranameInstanceList.size() == 0
        assert model.bpInfranameInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.bpInfranameInstance != null
    }

    void testSave() {
        controller.save()

        assert model.bpInfranameInstance != null
        assert view == '/bpInfraname/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/bpInfraname/show/1'
        assert controller.flash.message != null
        assert BpInfraname.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/bpInfraname/list'


        populateValidParams(params)
        def bpInfraname = new BpInfraname(params)

        assert bpInfraname.save() != null

        params.id = bpInfraname.id

        def model = controller.show()

        assert model.bpInfranameInstance == bpInfraname
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/bpInfraname/list'


        populateValidParams(params)
        def bpInfraname = new BpInfraname(params)

        assert bpInfraname.save() != null

        params.id = bpInfraname.id

        def model = controller.edit()

        assert model.bpInfranameInstance == bpInfraname
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/bpInfraname/list'

        response.reset()


        populateValidParams(params)
        def bpInfraname = new BpInfraname(params)

        assert bpInfraname.save() != null

        // test invalid parameters in update
        params.id = bpInfraname.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/bpInfraname/edit"
        assert model.bpInfranameInstance != null

        bpInfraname.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/bpInfraname/show/$bpInfraname.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        bpInfraname.clearErrors()

        populateValidParams(params)
        params.id = bpInfraname.id
        params.version = -1
        controller.update()

        assert view == "/bpInfraname/edit"
        assert model.bpInfranameInstance != null
        assert model.bpInfranameInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/bpInfraname/list'

        response.reset()

        populateValidParams(params)
        def bpInfraname = new BpInfraname(params)

        assert bpInfraname.save() != null
        assert BpInfraname.count() == 1

        params.id = bpInfraname.id

        controller.delete()

        assert BpInfraname.count() == 0
        assert BpInfraname.get(bpInfraname.id) == null
        assert response.redirectedUrl == '/bpInfraname/list'
    }
}
