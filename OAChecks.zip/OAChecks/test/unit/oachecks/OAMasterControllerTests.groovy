package oachecks



import org.junit.*
import grails.test.mixin.*

@TestFor(OAMasterController)
@Mock(OAMaster)
class OAMasterControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/OAMaster/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.report_catalog()

        assert model.OAMasterInstanceList.size() == 0
        assert model.OAMasterInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.OAMasterInstance != null
    }

    void testSave() {
        controller.save()

        assert model.OAMasterInstance != null
        assert view == '/OAMaster/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/OAMaster/show/1'
        assert controller.flash.message != null
        assert OAMaster.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/OAMaster/list'


        populateValidParams(params)
        def OAMaster = new OAMaster(params)

        assert OAMaster.save() != null

        params.id = OAMaster.id

        def model = controller.show()

        assert model.OAMasterInstance == OAMaster
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/OAMaster/list'


        populateValidParams(params)
        def OAMaster = new OAMaster(params)

        assert OAMaster.save() != null

        params.id = OAMaster.id

        def model = controller.edit()

        assert model.OAMasterInstance == OAMaster
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/OAMaster/list'

        response.reset()


        populateValidParams(params)
        def OAMaster = new OAMaster(params)

        assert OAMaster.save() != null

        // test invalid parameters in update
        params.id = OAMaster.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/OAMaster/edit"
        assert model.OAMasterInstance != null

        OAMaster.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/OAMaster/show/$OAMaster.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        OAMaster.clearErrors()

        populateValidParams(params)
        params.id = OAMaster.id
        params.version = -1
        controller.update()

        assert view == "/OAMaster/edit"
        assert model.OAMasterInstance != null
        assert model.OAMasterInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/OAMaster/list'

        response.reset()

        populateValidParams(params)
        def OAMaster = new OAMaster(params)

        assert OAMaster.save() != null
        assert OAMaster.count() == 1

        params.id = OAMaster.id

        controller.delete()

        assert OAMaster.count() == 0
        assert OAMaster.get(OAMaster.id) == null
        assert response.redirectedUrl == '/OAMaster/list'
    }
}
