	var invNo = 2;

$(document).ready(function() {
	var todaysdate = $.datepicker.formatDate('yy-mm-dd', new Date());
	$("#cap_add_row").click(function() {
		var username = $("#username").val();
		var textString = $("<tr id='capa"+ invNo + "'><td>" + invNo + "</td><td><select name='capobsv" + invNo + "' id='capobsv" + invNo +
			"'><option value='High CPU'>High CPU</option><option value='High Memory'>High Memory</option><option value='High Disk Service Time'>High Disk Service Time</option><option value='High Filesystem Capacity'>High Filesystem Capacity</option><option value='High Swap Usage'>High Swap Usage</option><option value='Underutilization'>Underutilization</option><option value='CapTrack - Not Registered'>CapTrack - Not Registered</option><option value='Business Volume Metrics'>Business Volume Metrics</option></select></td>" +
			"<td><textarea class='title_inputs' name='title" + invNo + "' id='title" + invNo + "' placeholder='Title'></textarea> </td>" +
			"<td><textarea class='text_inputs' name='capissues" + invNo + "' id='capissues" + invNo + "' placeholder='Issues'></textarea> </td>" +
			"<td><select name='taskstatus" + invNo + "' id='taskstatus" + invNo +
			"'><option value='Active'>Active</option><option value='Not Started'>Not Started</option><option value='Waivered'>Waivered</option><option value='Resolved'>Resolved</option></select></td>" +
			"<td><select name='capaction" + invNo + "' id='capaction" + invNo +
			"'><option value='Action'>Action Item</option><option value='Watch'>Watch Item</option></select></td>" +
			"<td><input type='text' class='inputlabel' id='assignby"+invNo+"' name='assignby"+invNo+"' value='"+username+"' readonly></td>"+
			"<td><input type='text' class='inputlabel' id='createdate"+invNo+"' name='createdate"+invNo+"' value='"+todaysdate+"' /></td>"+
			"<td><input type='text' class='duedate' id='duedate"+invNo+"' name='duedate"+invNo+"'></td></tr>");
		
		textString.find('.duedate').datepicker({
			minDate: 0,
			dateFormat:'yy-mm-dd',
			autoSize: true,
			maxDate: "+3M 0D"
		}).datepicker("setDate", new Date());
		
		
		/* -- Add/Remove Executive Summary -- */
		$('#cap_table_logic tbody').append(textString);
		invNo++;
		
	});

	$("#cap_delete_row").click(function() {
		if (invNo > 1) {
			$("#capa" + (invNo - 1)).remove()
			invNo--;
		}
	});
});

$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup").autocomplete({
			source : function(request, response) {
				$.ajax({
							url : "/OAChecks/assessments/aitLookup/",
							data : {
								aitName : request.term
							},
							success : function(data) {
								response($
										.map(
												data,
												function(item) {
													return {
														label : item.ait_aitnumber,
														inTitle : item.ait_aitnumber
																+ " ("
																+ item.ait_aitshortname
																+ ")",
														aitsname : item.ait_aitshortname,
														aittier : item.aittier,
														ucal : item.ucal_flag,
														dbflag : item.dashboard_flag,
														dblink : item.db_link,
														process : item.processed
													}
												}));
							}
						});
			},
			minLength : 3,
			select : function(event, ui) {
				getAssocServers(ui.item.label, ui.item.aitsname)
				getcsvHosts(ui.item.label)
				$("#saservicediv").show();
				$("#cfservicediv").show();
				$("#displayArea").show();
				$("#host_instruction").hide();
				$("#config_instruction").hide();
				$("#aitSName").val(ui.item.aitsname);
				$("#aitTier").val(ui.item.aittier);
				if (ui.item.ucal == "1") {
					$("#aitUCAL").val("YES");
				} else {
					$("#aitUCAL").val("NO");
				}
				
				if (ui.item.process == "True") {
					$("#aitCapTrack").val("YES");
					$("#captrackmsg").hide();
				} else {
					$("#aitCapTrack").val("NO");
					$("#captrackmsg").show();
				}
				

				/*derive for Capacity Metric graphs*/
				var capMetricLink
				capMetricLink = "http://gwb-analytics.bankofamerica.com/ServicePortal/?type=Capacity&subType=Capacity%20Metrics&ait="
						+ ui.item.aitsname
				if (ui.item.aitsname) {
					$("#capMetric_link").attr("href",
							capMetricLink);
					$("#capMetric_link").attr("target",
							"_blank");
					$("#capMetric_link").text("Click Here.");
					$("#memMetric_link").attr("href",
							capMetricLink);
					$("#memMetric_link").attr("target",
							"_blank");
					$("#memMetric_link").text("Click Here.");
				} else {
					$("#capMetric_link").attr("href", "#");
					$("#capMetric_link").text("Please select your AIT in the Previous section first!");
					$("#memMetric_link").attr("href", "#");
					$("#memMetric_link").text("Please select your AIT in the Previous section first!");
				}

				if (ui.item.dbflag == "1") {
					$("#a_dblink").attr("href", ui.item.dblink);
					$("#a_dblink").attr("target", "_blank");
					$("#a_dblink")
							.text(
									"Dashboard Already Exists! Click Here.");
				} else {
					$("#a_dblink")
							.text(
									"Dashboard Not configured. Go to Contact Us for more information.");
					$("#a_dblink").attr("href", '#')
				}
			}
		}).data("ui-autocomplete")._renderItem = function(ul, item) {
	return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
};

	$("#aitLookup").keyup(function() {
		if (!this.value) {
			$("#saservicediv").hide();
			$("#cfservicediv").hide();
			$("#displayArea").hide();
			$("#visible_ait").hide()
			$("#host_instruction").show();
			$("#config_instruction").show();
			$("#a_dblink").text("Input the AIT number to check for Capacity Dashboard");
			$("#capMetric_link").attr("href", "#");
			$("#capMetric_link").text("Please select your AIT in the Previous section first!");
		}
	});
					
	$("#fsInputs").focus(function() {
    var $this = $(this);
    $this.select();

    // Work around Chrome's little problem
    $this.mouseup(function() {
        // Prevent further mouseup intervention
        $this.unbind("mouseup");
        return false;
    });
});
	
})


/*
 * function loops through created HTML table and injects a column and creates a drop down for each host...
 */

function drawTable(data, tableId, functionKeys) {

	var stringHeader = "<thead><tr>"
	var stringTable = "<tbody>"
	var firstRow = false

	for ( var key in data) {
		var obj = data[key];
		stringTable += "<tr>"

		for ( var prop in obj) {
			if (!firstRow) {
				stringHeader += "<th>" + prop + "</th>"
			}

			stringTable += "<td>"

			if (typeof functionKeys != 'undefined'
					&& typeof functionKeys[prop] != 'undefined') {
				stringTable += functionKeys[prop](obj)
			} else {
				stringTable += obj[prop]
			}

			stringTable += "</td>"
		}
		;

		stringTable += "</tr>"
		firstRow = true;

	}

	stringHeader += "</tr></thead>"
	var staticData = "<h4><span style='color: #C00000;'> NOTE : This assessment is applicable only for AITs which cover MIDRANGE servers. Mainframe OR Desktop Only AITs should not run this assessment. </span></h4><br />";
	var stringReturn = "<table id=\""+tableId+"\" class=\"datatable\">"
			+ stringHeader + staticData + stringTable + "</tbody></table>"
	return stringReturn
}



/* Calling for HELP DIALOG on What is this?. for each Form element */
$(function() {
	$( ".helpful a" ).click(function(){
  		$.ajax({
			url:"/OAChecks/assessments/getHelpContent/",
		   data: {
				helpident : $(this).attr('id')
		 	},
		 	dataType: 'json',
		 	type: 'POST',
	   		success: function( data ) {
	   			if ( data.length != 0 ) {
					var tmpId = $('<div />').html(data[0].help_text);
		        	$(tmpId).dialog({
		        		autoOpen: true,
		            	autoResize: true,
		            	width: 600,
		            	modal: true,
		            	title: data[0].help_subj,
		            	close: function() {
		               		$(this).dialog('destroy')
		            	}
		        	});// Prepare dialog
	   			}// End of Data Length check
	   		} // End of success	        	
		}); // End AJAX call
	}); // End dblink
}); // End Function



//-- Create Link table for All Hosts
function drawDNTTable(prodHosts,tblLabel){

	var enddate = $.datepicker.formatDate('yy-mm-dd', new Date());
	var today = new Date();
	var yesterday = new Date(today);
	yesterday.setMonth(today.getMonth() - 3);
	var threemonthdate = $.datepicker.formatDate('yy-mm-dd', yesterday);
	var onedaybefore = new Date(today);
	onedaybefore.setDate(today.getDate() - 1);
	var onedaydate =  $.datepicker.formatDate('yy-mm-dd', onedaybefore);
	
	var prodhostArray = prodHosts.split(',');
	arrLength = prodhostArray.length;
	var proddata;
	

	proddata = "<p style='font-style: italic;'>Please find below the DNT link(s) for your "+ tblLabel +" Hosts</p>"
	
	proddata = proddata + '<table class="dnttable"><tr><td colspan=3>'+tblLabel+' DATA</td></tr><tr><td><b>3 Month Data</b></td><td><b> 1 Day Data</b></td><td><b> Hosts Covered</b></td></tr>'
	var anchorString = 'http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=';
	var hosts="";
	
	for (i = 1; i <= arrLength; i++){
		if(i % 10 != 0){
			hosts = hosts + prodhostArray[i - 1] + ",";
		}else{
			hosts = hosts + prodhostArray[i - 1] + ",";
			hosts = hosts.replace(/,\s*$/, "");
			proddata = proddata + 
			'<tr><td><a href="'+anchorString+hosts+'&BeginDate=' + threemonthdate + '&EndDate=' + enddate +  '&timeInterval=60" target="_blank">DNT Link</a></td>'+
			'<td><a href="'+anchorString+hosts+'&BeginDate=' + onedaydate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td><td>'+hosts+'</td></tr>'
			hosts = "";
		}
	}
	
	if(arrLength % 10 != 0){
		hosts = "";
		for (i = (Math.floor(arrLength/10) * 10); i < arrLength; i++){
			hosts = hosts + prodhostArray[i] + ",";
		}
		hosts = hosts.replace(/,\s*$/, "");
		proddata = proddata + '<tr><td><a href="'+anchorString+hosts+'&BeginDate=' + threemonthdate + '&EndDate=' + enddate +  '&timeInterval=60" target="_blank">DNT Link</a></td>' + 
		'<td><a href="'+anchorString+hosts+'&BeginDate=' + onedaydate + '&EndDate=' + enddate +  '" target="_blank">DNT Link</a></td><td>'+hosts+'</td></tr>'
	}
	proddata = proddata + "</table>"

	return proddata;
}



		
/* GET SERVERS SECTION BEGINS */
function getAssocServers(aitnumber, name) {
	var url = "/OAChecks/assessments/getHostlist/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {  
			if ( data.length != 0 ) {
				$("#invalid_aitCheck").show()
				$("#visible_ait").show()
				var stringReturn = drawTable(data, "fab_logic_1")
				$("#displayArea").html(stringReturn)
			} else{
				$("#invalid_aitCheck").hide()
				$("#visible_ait").hide()
				$("#displayArea").html("<p class='myp'> This AIT does not have any valid hosts. No report to generate </p>")
				$("#submitBtn").attr("disabled", true);
			} 
		}
	});
}

function getcsvHosts(aitnumber) {
	var url = "/OAChecks/assessments/getcsvHosts/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {
			var enddate = $.datepicker.formatDate('yy-mm-dd', new Date());
			var today = new Date();
			var yesterday = new Date(today);
			yesterday.setMonth(today.getMonth() - 3);
			var threemonthdate = $.datepicker.formatDate('yy-mm-dd', yesterday);
			var onedaybefore = new Date(today);
			onedaybefore.setDate(today.getDate() - 1);
			var onedaydate =  $.datepicker.formatDate('yy-mm-dd', onedaybefore);

			//-- Get Production and Contingency Hosts
			
			var splitHosts = data.split(':')
			$("#fsInputs").val(data.replace(':',','));
			var prodHosts = splitHosts[0]
			var contHosts = splitHosts[1]
			
			
			//-- Checking for NULL Production Hosts
			
			if ((prodHosts) || (contHosts)){
				var manualDNT = "<p>To manually enter your hosts in DNT for reporting - Click <a href='http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Default.aspx' target='_blank'>here</a></p>"; 
				$("#manualDNT").html(manualDNT)
			}
			
			if (!prodHosts){
				console.log("No values found!!")
			} else {
				var prodTable = drawDNTTable(prodHosts,'PRODUCTION')
				$("#prodDNT").html(prodTable)
				
				var prod_configLink = "http://dnt.bankofamerica.com/Portal/ConfigLoader.aspx?hostNames=" + prodHosts + "&BeginDate=" + threemonthdate + "&EndDate=" + enddate;
				
				$("#prod_configLink").attr("href",prod_configLink);
				$("#prod_configLink").attr("target","_blank");
				$("#prod_configLink").text("Prod Link.");
			}
			
			//-- Checking for NULL Contingency Hosts
			
			if (!contHosts){
				console.log("No values found!!")
			} else {
				var contTable = drawDNTTable(contHosts,'CONTINGENCY')
				$("#contDNT").html(contTable)
				
				var cont_configLink = "http://dnt.bankofamerica.com/Portal/ConfigLoader.aspx?hostNames=" + contHosts + "&BeginDate=" + threemonthdate + "&EndDate=" + enddate;
				$("#cont_configLink").attr("href",cont_configLink);
				$("#cont_configLink").attr("target","_blank");
				$("#cont_configLink").text("Cont Link.");
			}
			
		}
	});
}