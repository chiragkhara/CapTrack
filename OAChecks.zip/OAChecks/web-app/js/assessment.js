	var iExecSummary = 2;
	var iAssessmentInfo = 2;

$(document).ready(function() {
	$("#add_row").click(function() {
		var tdString = "<td>" + iExecSummary + "</td><td><select name='obsv" + iExecSummary + "' id='obsv" + iExecSummary +
			"'><option value='CPU'>CPU</option><option value='Memory'>Memory</option><option value='Disk'>Disk</option><option value='Filesystem'>Filesystem</option><option value='Other'>Other</option></select></td><td><textarea name='issues" + iExecSummary + 
			"' placeholder='Issues' class='text_inputs'></textarea> </td>"
		var trString = '<tr id="addr'+ iExecSummary + '">'+ tdString + '</tr>'

			/* -- Add/Remove Executive Summary -- */
		$('#tab_logic tbody').append(trString);
		iExecSummary++;
	});

	$("#delete_row").click(function() {
		if (iExecSummary > 1) {
			$("#addr" + (iExecSummary - 1)).remove()
			iExecSummary--;
		}
	});
});	

//====================//
//==== AIT LOOKUP ====//
//=====================//

$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup").autocomplete({
		source : function(request, response) {
			$.ajax({
				url : "../assessments/aitLookup/",
				data : {
					aitName : request.term
				},
				success : function(data) {
					response($.map(data, function(item) {
						return {
							label : item.ait_aitnumber,
							inTitle : item.ait_aitnumber
									+ " ("
									+ item.ait_aitshortname
									+ ")",
							aitsname : item.ait_aitshortname,
							aittier : item.aittier,
							ucal : item.ucal_flag,
							dbflag : item.dashboard_flag,
							dblink : item.db_link
						}
					}));
				}
			});
		},
		minLength : 3,
		select : function(event, ui) {
			getAssocServers(ui.item.label, ui.item.aitsname)
			getcsvHosts(ui.item.label)
			$("#tabs").tabs({disabled: false});
			$("#saservicediv").show();
			$("#displayArea").show();
			$("#host_instruction").hide();

			$("#aitSName").val(ui.item.aitsname);
			$("#aitTier").val(ui.item.aittier);
			if (ui.item.ucal == "1") {
				$("#aitUCAL").val("YES");
			} else {
				$("#aitUCAL").val("NO");
			}

							/*derive for Capacity Metric graphs*/
			var capMetricLink
			capMetricLink = "http://gwb-analytics.bankofamerica.com/ServicePortal/?type=Capacity&subType=Capacity%20Metrics&ait="
					+ ui.item.aitsname
			if (ui.item.aitsname) {
				$("#capMetric_link").attr("href",
						capMetricLink);
				$("#capMetric_link").attr("target",
						"_blank");
				$("#capMetric_link").text("Click Here.");
			} else {
				$("#capMetric_link").attr("href", "#");
				$("#capMetric_link").text("Please select your AIT in the Previous section first!");
			}

			if (ui.item.dbflag == "1") {
				$("#a_dblink").attr("href", ui.item.dblink);
				$("#a_dblink").attr("target", "_blank");
				$("#a_dblink").text("Dashboard Already Exists! Click Here.");
			} else {
				$("#a_dblink").text("Dashboard Not configured. Go to Contact Us for more information.");
				$("#a_dblink").attr("href", '#')
			}
		}
	}).data("ui-autocomplete")._renderItem = function(ul,item) {
		return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
};

$("#aitLookup").keyup(function() {
	if (!this.value) {
		$("#tabs").tabs({disabled: [1,2,3,4,5]});
		$("#saservicediv").hide();
		$("#displayArea").hide();
		$("#host_instruction").show();
		$("#capMetric_link").attr("href", "#");
		$("#capMetric_link").text("Please select your AIT in the Previous section first!");
	}
});
						
$("#fsInputs").focus(function() {
    var $this = $(this);
    $this.select();

	// Work around Chrome's little problem
    $this.mouseup(function() {
	        // Prevent further mouseup intervention
        $this.unbind("mouseup");
	        return false;
	    });
	});
})


/* Calling for HELP DIALOG on What is this?. for each Form element */
$(function() {
	$( ".helpful a" ).click(function(){
  		$.ajax({
			url:"../assessments/getHelpContent/",
		   data: {
				helpident : $(this).attr('id')
		 	},
		 	dataType: 'json',
		 	type: 'POST',
	   		success: function( data ) {
	   			if ( data.length != 0 ) {
					var tmpId = $('<div />').html(data[0].help_text);
		        	$(tmpId).dialog({
		        		autoOpen: true,
		            	autoResize: true,
		            	width: 600,
		            	modal: true,
		            	title: data[0].help_subj,
		            	close: function() {
		               		$(this).dialog('destroy')
		            	}
		        	});// Prepare dialog
	   			}// End of Data Length check
	   		} // End of success	        	
		}); // End AJAX call
	}); // End dblink
}); // End Function
	
	
	
	
	
	/* Calling the TABS Function to format the form in different TABS */
$(function() {
	$("#tabs").tabs();
	$("#tabs").tabs({disabled: [1,2,3,4,5]});
});

/* ACCORDION SECTION BEGINS */
$(function() {
	var myicons = {
		header: "ui-icon-plus",
		activeHeader: "ui-icon-minus"
	};
	 $( "#cpuguidances" ).accordion({
	 	icons: myicons,
	 	event: "click hoverintent",
		heightStyle: "content"
	 });
	 $( "#memoryguidances" ).accordion({
	 	icons: myicons,
	 	event: "click hoverintent",
		heightStyle: "content"
	 });
	 $( "#diskguidances" ).accordion({
		 icons: myicons,
		 event: "click hoverintent",
		heightStyle: "content"
	 });
	 $( "#filesystemguidances" ).accordion({
		 icons: myicons,
		 event: "click hoverintent",
		heightStyle: "content"
	 });
});


$.event.special.hoverintent = {
	setup: function(){
		$( this ).bind( "mouseover", jQuery.event.special.hoverintent.handler);
	},
	teardown: function() {
	$( this ).unbind( "mouseover",jQuery.event.special.hoverintent.handler );
	},
	handler: function( event ) {
		var currentX, currentY, timeout,
		args = arguments,
		target = $( event.target ),
		previousX = event.pageX,
		previousY = event.pageY;
		
		function track( event ) {
			currentX = event.pageX;
			currentY = event.pageY;
		};
		function clear() {
			target  
				.unbind( "mousemove", track ) 
				.unbind( "mouseout", clear );
			clearTimeout( timeout ); 
		}
		function handler() {
			var prop, orig = event;
			if (( Math.abs( previousX - currentX ) + Math.abs( previousY - currentY )) < 7 ) {
				clear();
				  
				event = $.Event( "hoverintent" );
				  
				for ( prop in orig ) {
					if ( !( prop in event )) {
						event[ prop ] = orig[ prop ];
				  	}
				}
				// Prevent accessing the originalevent since the new event 
				// is fired asynchronously and the old event is no longer 
				// usable (#6028) 
				  
				delete event.originalEvent;
				target.trigger( event );
			} else {
				previousX = currentX;
				previousY = currentY;
				timeout = setTimeout( handler, 100 );
			}
		} 
		
		timeout = setTimeout( handler, 100 );
		target.bind({
			mousemove: track,
			mouseout:clear
		});
	}
};
	/* ACCORDION SECTION ENDS */
	
/* GET SERVERS SECTION BEGINS */
function getAssocServers(aitnumber, name) {
	var url = "../assessments/getHostlist/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {  
			var stringReturn = drawTable(data, "fab_logic_1")
			$("#displayArea").html(stringReturn)
			appendChoiceColumn($("#fab_logic_1")) 
		}
	});
}

/* GET Hosts as CSV */

function getcsvHosts(aitnumber) {
	var url = "../assessments/getcsvHosts/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {  
			$("#fsInputs").val(data);
			var configLink = "http://dnt.bankofamerica.com/Portal/ConfigLoader.aspx?hostNames=" + data + "&BeginDate=2014-09-23&EndDate=2014-10-23";
			$("#configLink").attr("href",configLink);
			$("#configLink").attr("target","_blank");
			$("#configLink").text("Click Here.");

			// 3-month URL
			var dntLink = "http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=" + data + "&BeginDate=2014-07-23&EndDate=2014-10-23";
			$("#dntLinks").attr("href",dntLink);
			$("#dntLinks").attr("target","_blank");
			$("#dntLinks").text("Link Here.");

			// 1-day URL
			var dntLink_1 = "http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=" + data + "&BeginDate=2014-10-22&EndDate=2014-10-23";
			$("#dntLinks_1").attr("href",dntLink_1);
			$("#dntLinks_1").attr("target","_blank");
			$("#dntLinks_1").text("Link Here.");

			// 3-month URL Memory
			$("#memLinks").attr("href",dntLink);
			$("#memLinks").attr("target","_blank");
			$("#memLinks").text("Link Here.");

			// 1-day URL Memory
			$("#memLinks_1").attr("href",dntLink_1);
			$("#memLinks_1").attr("target","_blank");
			$("#memLinks_1").text("Link Here.");

			// 3-month URL Memory
			$("#dskLinks").attr("href",dntLink);
			$("#dskLinks").attr("target","_blank");
			$("#dskLinks").text("Link Here.");

			// 1-day URL Memory
			$("#dskLinks_1").attr("href",dntLink_1);
			$("#dskLinks_1").attr("target","_blank");
			$("#dskLinks_1").text("Link Here.");
		}
	});
}
	
/* DrawTable -->  */	

function drawTable(data, tableId, functionKeys) {

	var stringHeader = "<thead><tr>"
	var stringTable = "<tbody>"
	var firstRow = false

	for ( var key in data) {
		var obj = data[key];
		stringTable += "<tr>"

		for ( var prop in obj) {
			if (!firstRow) {
				stringHeader += "<th>" + prop + "</th>"
			}

			stringTable += "<td>"

			if (typeof functionKeys != 'undefined'
					&& typeof functionKeys[prop] != 'undefined') {
				stringTable += functionKeys[prop](obj)
			} else {
				stringTable += obj[prop]
			}

			stringTable += "</td>"
		}
		;

		stringTable += "</tr>"
		firstRow = true;

	}

	stringHeader += "</tr></thead>"
	var staticData = "<p style='color: red; font-size: 0.9em;'><i>NOTE : If any discrepancies are found in <b>Server to AIT</b> relationship, please correct <a href='http://rtt.bankofamerica.com/DataMaintenance/ApplicationSearch.aspx'>here</a><br />NOTE : If any discrepancies found in <b>Environment</b> information, Maximo system of records needs to be updated via RFC for environment level detail changes. <br />NOTE : If the <b>Server Role</b> is incorrect, please correct it in Runbook <a href='http://dssapps.bankofamerica.com/runbook/RunBookMenu.asp'>here</a><br />NOTE : Please select HA/Clustering for each server to the best of your knowledge</i></p>"
	var stringReturn = staticData + "<table id=\""+tableId+"\" class=\"datatable\">"
			+ stringHeader + stringTable + "</tbody></table>"
	return stringReturn
}
	
	

var hachoices = [ "Single Node", "2 Node", "3 Node","4 Node",
                  "5 Node", "6 Node" ]

/*This function adds all the other selects with the value configured in the SelectAllVals element*/
function setAllSelectVals(tableObj,columnIndex,valueToSet){
			//console.log(valueToSet)
			tableObj.find('tr:gt(0)').each(function(){
           $(this).find("td:eq("+columnIndex+")").find("select").val(valueToSet)
    });
}


/*
 * function loops through created HTML table and injects a column and creates a drop down for each host...
 */

function appendChoiceColumn(obj) {
	//Add Column Title and SELECT ALL drop down
	obj.find('tr:eq(0)').append('<th>HA / Clustering<br><select id="setAllHA" name="setAllHA" /></select></th>');
	
	$("<option>Set All</option>").appendTo($("#setAllHA"));
	for ( var haval in hachoices) {
		$("<option />", {
			value : haval,
			text : ' - to: '+hachoices[haval]
		}).appendTo($("#setAllHA"));
	}

	
	$('#setAllHA').change(function(){
	  if($(this).text()!="Set All Value"){
	   	setAllSelectVals($("#fab_logic_1"),4, $(this).val())
	  }
	});
	
	//Add each host workload HA Cluster dropdown
	obj.find('tr:gt(0)').each(function() {
		var hostname = $(this).find('td').eq(1).text()
		var haName = "HACLUS-" + hostname
		$(this).append('<td><select id="'+haName+'" name="'+haName+'" /></td>');

		for ( var haval in hachoices) {
			$("<option />", {
				value : haval,
				text : hachoices[haval]
			}).appendTo($("#" + haName));
		}

	});
}