	var invNo = 2;

$(document).ready(function() {
	
	var todaysdate = $.datepicker.formatDate('yy-mm-dd', new Date());
	
	$("#inv_add_row").click(function() {
		var username = $("#user_name").val();
		var email = $("#email").val();
		
		var textString = $("<tr id='addr"+ invNo + "'><td>" + invNo + "</td><td><select name='obsv" + invNo + "' id='obsv" + invNo +
			"'><option value='Software'>Software</option><option value='Hardware'>Hardware</option><option value='Environment'>Environment</option><option value='DNP'>DNP</option><option value='Server Missing'>Server Missing</option><option value='No DR Test'>No DR Test</option><option value='Other'>Other</option></select></td>" +
			"<td><textarea class='title_inputs' id='title" + invNo + "' name='title" + invNo + "' placeholder='Issues'></textarea> </td>" +
			"<td><textarea class='text_inputs' id='issues" + invNo + "' name='issues" + invNo + "' placeholder='Issues'></textarea> </td>" +
			"<td><select name='taskstatus" + invNo + "' id='taskstatus" + invNo +
			"'><option value='Active'>Active</option><option value='Not Started'>Not Started</option><option value='Waivered'>Waivered</option><option value='Resolved'>Resolved</option></select></td>" +
			"<td><select name='invaction" + invNo + "' id='invaction" + invNo +
			"'><option value='Action'>Action Item</option><option value='Watch'>Watch Item</option></select></td>" +
			"<td><input type='text' class='inputlabel' id='assignby"+invNo+"' name='assignby"+invNo+"' value='"+username+"' readonly><input type='hidden' id='emailby"+invNo+"' name='emailby"+invNo+"' value='"+email+"'></td>"+
			"<td><input type='text' class='inputlabel' id='createdate"+invNo+"' name='createdate"+invNo+"' value='"+todaysdate+"' /></td>"+
			"<td><input type='text' class='duedate' id='duedate"+invNo+"' name='duedate"+invNo+"'></td></tr>");
		
		textString.find('.duedate').datepicker({
			minDate: 0,
			dateFormat:'yy-mm-dd',
			autoSize: true,
			maxDate: "+3M 0D"
		}).datepicker("setDate", new Date());
		
		
		/* -- Add/Remove Executive Summary -- */
		$('#inv_table_logic tbody').append(textString);
		invNo++;
		
	});

	$("#inv_delete_row").click(function() {
		if (invNo > 1) {
			$("#addr" + (invNo - 1)).remove()
			invNo--;
		}
	});
	
	$('input[name=inv_dr]').click(function () {
	    if (this.id == "inventoryDRYes") {
	        $("#drArea").show();
	    } else {
	        $("#drArea").hide();
	    }
	});
	
});	

//====================//
//==== AIT LOOKUP ====//
//=====================//

$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup").autocomplete({
		source : function(request, response) {
			$.ajax({
				url : "../assessments/aitLookup/",
				data : {
					aitName : request.term
				},
				success : function(data) {
					response($.map(data, function(item) {
						return {
							label : item.ait_aitnumber,
							inTitle : item.ait_aitnumber
									+ " ("
									+ item.ait_aitshortname
									+ ")",
							aitsname : item.ait_aitshortname,
							aittier : item.aittier,
							ucal : item.ucal_flag
						}
					}));
				}
			});
		},
		minLength : 3,
		select : function(event, ui) {
			getAssocServers(ui.item.label, ui.item.aitsname)
			$("#saservicediv").show();
			$("#displayArea").show();
			$("#host_instruction").hide();
			
			$("#aitSName").val(ui.item.aitsname);
			$("#aitTier").val(ui.item.aittier);
			if (ui.item.ucal == "1") {
				$("#aitUCAL").val("YES");
			} else {
				$("#aitUCAL").val("NO");
			}
			$("#inv_ack").attr("disabled",false);
		}
	}).data("ui-autocomplete")._renderItem = function(ul,item) {
		return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
};

$("#aitLookup").keyup(function() {
	if (!this.value) {
		$("#tabs").tabs({disabled: [1,2,3,4,5]});
		$("#saservicediv").hide();
		$("#displayArea").hide();
		$("#visible_ait").hide();
		$("#host_instruction").show();
		$("#inv_ack").attr("disabled",true);
		$("#capMetric_link").attr("href", "#");
		$("#capMetric_link").text("Please select your AIT in the Previous section first!");
	}
});

$( "#inventory_form" ).submit(function( event ) {
	if(!confirm("Please confirm you want to submit this Inventory Assessment?")){
		event.preventDefault();
	}
});
						
$("#fsInputs").focus(function() {
    var $this = $(this);
    $this.select();

	// Work around Chrome's little problem
    $this.mouseup(function() {
	        // Prevent further mouseup intervention
        $this.unbind("mouseup");
	        return false;
	    });
	});
})

	
/* GET SERVERS SECTION BEGINS */
function getAssocServers(aitnumber, name) {
	var url = "../assessments/invLookup/?aitnumber=" + aitnumber
	$.ajax({
		url : url,
		success : function(data) {
			if ( data.length != 0 ) {
				$("#visible_ait").show()
				var stringReturn = drawTable(data, "fab_logic_1")
				$("#displayArea").html(stringReturn)
			}else{
				$("#visible_ait").hide()
				$("#displayArea").html("<p class='myp'> This AIT does not have any valid hosts. No report to generate </p>")
				$("#submitBtn").attr("disabled", true);
			}
		}
	});
}
	
/* DrawTable -->  */	

function drawTable(data, tableId, functionKeys) {

	var stringHeader = "<thead><tr>"
	var stringTable = "<tbody>"
	var firstRow = false

	for ( var key in data) {
		var obj = data[key];
		stringTable += "<tr>"

		for ( var prop in obj) {
			if (!firstRow) {
				stringHeader += "<th>" + prop + "</th>"
			}

			stringTable += "<td>"

			if (typeof functionKeys != 'undefined'
					&& typeof functionKeys[prop] != 'undefined') {
				stringTable += functionKeys[prop](obj)
			} else {
				stringTable += obj[prop]
			}

			stringTable += "</td>"
		}
		;

		stringTable += "</tr>"
		firstRow = true;

	}

	stringHeader += "</tr></thead>"
	var staticData = "<div class='helpful'><p style='color: red;'><i>NOTE : If any discrepancies are found in <b>Server to AIT</b> relationship, please correct on RTT <a href='http://rtt.bankofamerica.com/DataMaintenance/ApplicationSearch.aspx'>here</a><br />NOTE : If any discrepancies found in <b>Environment</b> information, Maximo system of records needs to be updated via RFC for environment level detail changes. <br />NOTE : If the <b>Server Role</b> is incorrect, please correct it in Runbook <a href='http://dssapps.bankofamerica.com/runbook/RunBookMenu.asp'>here</a><br />NOTE : Please select HA/Clustering for each server to the best of your knowledge</i></p></div>"
	var stringReturn = staticData + "<table id=\""+tableId+"\" class=\"datatable\">"
			+ stringHeader + stringTable + "</tbody></table>"
	return stringReturn
}
	
	

var hachoices = [ "Single Node", "2 Node", "3 Node","4 Node",
                  "5 Node", "6 Node" ]
