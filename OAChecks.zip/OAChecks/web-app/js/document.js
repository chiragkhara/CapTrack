	var invNo = 2;

$(document).ready(function() {
	$("#eval_questions").hide();
	var todaysdate = $.datepicker.formatDate('yy-mm-dd', new Date());
	$("#doc_add_row").click(function() {
		var username = $("#username").val();
		var textString = $("<tr id='docu"+ invNo + "'><td>" + invNo + "</td><td><select name='docobsv" + invNo + "' id='docobsv" + invNo +
			"'><option value='Missing Documentation'>Missing Documentation</option><option value='Documentation not current'>Documentation not current</option><option value='Multiple Locations'>Multiple Locations</option><option value='Other'>Other</option></select></td>" +
			"<td><textarea class='title_inputs' name='title" + invNo + "' id='title" + invNo + "' placeholder='Title'></textarea> </td>" +
			"<td><textarea class='text_inputs' name='docissues" + invNo + "' id='docissues" + invNo + "' placeholder='Issues'></textarea> </td>" +
			"<td><select name='taskstatus" + invNo + "' id='taskstatus" + invNo +
			"'><option value='Active'>Active</option><option value='Not Started'>Not Started</option><option value='Waivered'>Waivered</option><option value='Resolved'>Resolved</option></select></td>" +
			"<td><select name='docaction" + invNo + "' id='docaction" + invNo +
			"'><option value='Action'>Action Item</option><option value='Watch'>Watch Item</option></select></td>" +
			"<td><input type='text' class='inputlabel' id='assignby"+invNo+"' name='assignby"+invNo+"' value='"+username+"' readonly></td>"+
			"<td><input type='text' class='inputlabel' id='createdate"+invNo+"' name='createdate"+invNo+"' value='"+todaysdate+"' /></td>"+
			"<td><input type='text' class='duedate' id='duedate"+invNo+"' name='duedate"+invNo+"'></td></tr>");
		
		textString.find('.duedate').datepicker({
			minDate: 0,
			dateFormat:'yy-mm-dd',
			autoSize: true,
			maxDate: "+3M 0D"
		}).datepicker("setDate", new Date());
		
		
		/* -- Add/Remove Executive Summary -- */
		$('#doc_table_logic tbody').append(textString);
		invNo++;
		
	});

	$("#doc_delete_row").click(function() {
		if (invNo > 1) {
			$("#addr" + (invNo - 1)).remove()
			invNo--;
		}
	});
	
	
	var docNo = 2;
	$("#addoc_add_row").click(function() {
		var textString = $("<tr id='addoc"+ docNo + "'><td>" + docNo + "</td><td><select name='addsel" + docNo + "' id='addsel" + docNo +
			"'><option value='KCS'>KCS</option><option value='Discovery'>Discovery</option><option value='Sharepoint'>Sharepoint</option><option value='Desktop'>Desktop</option><option value='Share Drive'>Share Drive</option></select></td>" + 
			"<td><input type='text' class='addoc_inputs' name='add_doc"+docNo+"' id='add_doc"+docNo+"' /></td></tr>");
		
		/* -- Add/Remove Executive Summary -- */
		$('#addoc_table_logic tbody').append(textString);
		docNo++;
		
	});
	
	$("#addoc_delete_row").click(function() {
		if (docNo > 1) {
			$("#addoc" + (docNo - 1)).remove()
			docNo--;
		}
	});
	
	
});	

//====================//
//==== AIT LOOKUP ====//
//=====================//

$(function() {
	/* Search FOR AIT INPUT  */
	$("#aitLookup").autocomplete({
		source : function(request, response) {
			$.ajax({
				url : "../assessments/aitLookup/",
				data : {
					aitName : request.term
				},
				success : function(data) {
					response($.map(data, function(item) {
						return {
							label : item.ait_aitnumber,
							inTitle : item.ait_aitnumber
									+ " ("
									+ item.ait_aitshortname
									+ ")",
							aitsname : item.ait_aitshortname,
							aittier : item.aittier,
							ucal : item.ucal_flag
						}
					}));
				}
			});
		},
		minLength : 3,
		select : function(event, ui) {
			$("#displayArea").show();
			$("#host_instruction").hide();

			$("#aitSName").val(ui.item.aitsname);
			$("#aitTier").val(ui.item.aittier);
			if (ui.item.ucal == "1") {
				$("#aitUCAL").val("YES");
			} else {
				$("#aitUCAL").val("NO");
			}
			
			$("#inv_ack").attr("disabled",false);
		}
	}).data("ui-autocomplete")._renderItem = function(ul,item) {
		return $("<li>").append("<a>" + item.inTitle + "</a>").appendTo(ul);
};

$("#aitLookup").keyup(function() {
	if (!this.value) {
		$("#saservicediv").hide();
		$("#displayArea").hide();
		$("#host_instruction").show();
		$("#inv_ack").attr("disabled",true);
		$("#capMetric_link").attr("href", "#");
		$("#capMetric_link").text("Please select your AIT in the Previous section first!");
	}
});

$( "#document_form" ).submit(function( event ) {
	if(!confirm("Please confirm you want to submit this Documentation Assessment?")){
		event.preventDefault();
	}
});
						
$("#fsInputs").focus(function() {
    var $this = $(this);
    $this.select();

	// Work around Chrome's little problem
    $this.mouseup(function() {
	        // Prevent further mouseup intervention
        $this.unbind("mouseup");
	        return false;
	    });
	});
})


/* Calling for HELP DIALOG on What is this?. for each Form element */
$(function() {
	$( ".helpful a" ).click(function(){
  		$.ajax({
			url:"../assessments/getHelpContent/",
		   data: {
				helpident : $(this).attr('id')
		 	},
		 	dataType: 'json',
		 	type: 'POST',
	   		success: function( data ) {
	   			if ( data.length != 0 ) {
					var tmpId = $('<div />').html(data[0].help_text);
		        	$(tmpId).dialog({
		        		autoOpen: true,
		            	autoResize: true,
		            	width: 600,
		            	modal: true,
		            	title: data[0].help_subj,
		            	close: function() {
		               		$(this).dialog('destroy')
		            	}
		        	});// Prepare dialog
	   			}// End of Data Length check
	   		} // End of success	        	
		}); // End AJAX call
	}); // End dblink
}); // End Function


/*-- DETECT CHANGES IN THE RADIO BUTTON --*/

function showEvalDiv(){
	$('#eval_questions').show();
}

function hideEvalDiv(){
	$('#eval_questions').hide();
}
