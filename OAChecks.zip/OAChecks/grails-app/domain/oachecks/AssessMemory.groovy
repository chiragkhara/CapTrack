package oachecks

class AssessMemory {

	Integer Q1
	Integer Q2
	Integer Q3
	Integer Q4
	Integer Q5
	String Comments
	
	static mapping = {		
		table name: 'capassess_memory_checklist', schema: 'hotpdb'
		version false
		id column:'memid'	
	}	
}
