package oachecks

import java.util.Date;

class DocMaster {

    Integer aitnumber
	Date createdate
	String username
	String email
	Integer identify
	
	static mapping = {		
		table name: 'oassess_document_master_checklist', schema: 'hotpdb'
		version false
		id column:'docid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		createdate(size:0..12)
		username(size:0..127)
		email(size:0..256)
	
		identify nullable: true
	}
}
