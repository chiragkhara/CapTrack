package oachecks

import java.util.Date;

class OAMaster {
	
	Integer aitnumber
	String type
	String username
	String email
	Date createdate
	String assigned
	String assigned_email
	
	static mapping = {		
		table name: 'oassess_master_checklist', schema: 'hotpdb'
		version false
		id column:'repid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		createdate(size:0..12)
		username(size:0..127)
		email(size:0..256)
		
		assigned nullable: true
		assigned_email nullable:true
		username nullable: true
		email nullable:true
	
	}
}
