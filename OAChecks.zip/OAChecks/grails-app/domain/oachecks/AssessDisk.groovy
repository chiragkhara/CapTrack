package oachecks

class AssessDisk {

	Integer Q1
	Integer Q2
	String Comments
	
	static mapping = {		
		table name: 'capassess_diskp_checklist', schema: 'hotpdb'
		version false
		id column:'dskid'	
	}
	 
}
