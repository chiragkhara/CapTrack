package oachecks

import java.util.Date;

class DocDetails {

	Long docnumber
	String doctype
	String flag
	String loctype
	String document_link
	
	static mapping = {		
		table name: 'docassess_document_checklist', schema: 'hotpdb'
		version false
		id column:'docid'	
	}
}
