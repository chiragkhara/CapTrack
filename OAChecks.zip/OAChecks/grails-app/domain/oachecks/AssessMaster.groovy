package oachecks

import java.util.Date;

class AssessMaster {
	
	Integer aitnumber
	Date createdate
	String repo_link
	String username
	String email
	Integer identify
	Integer bmetrics
	
	static mapping = {		
		table name: 'oassess_capacity_master_checklist', schema: 'hotpdb'
		version false
		id column:'capid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		createdate(size:0..12)
		repo_link(size:0..511)
		username(size:0..127)
		email(size:0..256)
	
		repo_link nullable: true
		identify nullable: true
		bmetrics nullable: true
	}
}
