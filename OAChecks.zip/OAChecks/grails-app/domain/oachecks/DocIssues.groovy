package oachecks

class DocIssues {

 	Long docnumber
	Integer aitnumber
	String doc_title
	String doc_text
	String doc_category
	String doc_status
	String doc_action
	Date duedate
	
	static mapping = {		
		table name: 'oassess_document_checklist', schema: 'hotpdb'
		version false
		id column:'docid'	
	}
}
