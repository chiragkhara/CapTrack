package oachecks

import java.util.Date;

class InvMaster {

    Integer aitnumber
	Date createdate
	String username
	String email
	String identify
	Integer config
	Integer dr
	Date drdate
	String drdocument
	
	
	static mapping = {		
		table name: 'oassess_inventory_master_checklist', schema: 'hotpdb'
		version false
		id column:'invid'	
	}
	 
	static constraints = {		
		aitnumber(size:0..10)
		createdate(size:0..12)
		username(size:0..127)
		email(size:0..256)
	
		identify nullable: true
		config nullable: true
		dr nullable: true
		drdate nullable: true
		drdocument nullable: true
	}
}
