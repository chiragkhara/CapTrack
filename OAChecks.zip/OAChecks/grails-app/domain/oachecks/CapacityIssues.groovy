package oachecks

import java.util.Date;

class CapacityIssues {

	Long capnumber
	Integer aitnumber
	String cap_title
	String cap_text
	String cap_category
	String cap_status
	String cap_action
	Date duedate
	
	static mapping = {		
		table name: 'oassess_capacity_checklist', schema: 'hotpdb'
		version false
		id column:'capid'	
	}
}
