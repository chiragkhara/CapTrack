package oachecks

import java.util.Date;

class InvIssues {

 	Long invnumber
	Integer aitnumber
	String inv_title 
	String inv_text
	String inv_category
	String inv_status
	String inv_action
	Date duedate
	
	static mapping = {		
		table name: 'oassess_inventory_checklist', schema: 'hotpdb'
		version false
		id column:'invid'	
	}
}
