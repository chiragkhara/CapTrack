package oachecks

import java.util.Date;

class AssessCPU {
	Integer Q1
	Integer Q2
	Integer Q3
	Integer Q4
	Integer Q5
	Integer Q6
	String Comments
	
	static mapping = {		
		table name: 'capassess_cpu_checklist', schema: 'hotpdb'
		version false
		id column:'cpuid'	
	}
}
