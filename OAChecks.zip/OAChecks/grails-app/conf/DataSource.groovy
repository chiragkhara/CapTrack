dataSource {
    pooled = true
    driverClassName = "org.h2.Driver"
    username = "sa"
    password = ""
}
hibernate {
    cache.use_second_level_cache = true
    cache.use_query_cache = false
    cache.region.factory_class = 'net.sf.ehcache.hibernate.EhCacheRegionFactory'
}
// environment specific settings
environments {
    development {
        dataSource {
            loggingSql = true
			url = "jdbc:mysql://lcdra76577.cdr-p01.chp.bankofamerica.com:3307?zeroDateTimeBehavior=convertToNull"
			username = "nbkxuqk"
			password = "DsZ6FFXsABC"
			driverClassName = "com.mysql.jdbc.Driver"
			properties {
				maxActive = 50
				maxIdle = 25
				minIdle = 5
				initialSize = 5
				minEvictableIdleTimeMillis=60000
				timeBetweenEvictionRunsMillis=60000
				maxWait = 10000
				numTestsPerEvictionRun=3
				testOnBorrow=true
				testWhileIdle=true
				testOnReturn=true
				validationQuery="SELECT 1"
		  }
        }
    }

	test {
        dataSource {
            loggingSql = true
			url = "jdbc:mysql://lcdra76577.cdr-p01.chp.bankofamerica.com:3307?zeroDateTimeBehavior=convertToNull"
			username = "nbkxuqk"
			password = "DsZ6FFXsABC"
			driverClassName = "com.mysql.jdbc.Driver"
			properties {
				maxActive = 50
				maxIdle = 25
				minIdle = 5
				initialSize = 5
				minEvictableIdleTimeMillis=60000
				timeBetweenEvictionRunsMillis=60000
				maxWait = 10000
				numTestsPerEvictionRun=3
				testOnBorrow=true
				testWhileIdle=true
				testOnReturn=true
				validationQuery="SELECT 1"
		  }
        }
    }
    production {
        dataSource {
                     url = "jdbc:mysql://lrcha76630.rch-p01.chp.bankofamerica.com:3307?zeroDateTimeBehavior=convertToNull"
					 username = "hotprw"
                     password = "TpCRV6CN"
					 //username = "nbkxuqk"
					 //password = "DsZ6FFXsABC"
                     driverClassName = "com.mysql.jdbc.Driver"
                     properties {
                           maxActive = 50
                           maxIdle = 25
                           minIdle = 5
                           initialSize = 5
                           minEvictableIdleTimeMillis=60000
                           timeBetweenEvictionRunsMillis=60000
                           maxWait = 10000
                           numTestsPerEvictionRun=3
                           testOnBorrow=true
                           testWhileIdle=true
                           testOnReturn=true
                           validationQuery="SELECT 1"
                     }
              }
    	}
}