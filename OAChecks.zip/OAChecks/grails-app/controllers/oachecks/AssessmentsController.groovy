package oachecks

import grails.converters.JSON
import groovy.sql.Sql
import groovy.transform.Canonical
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class AssessmentsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource
	def aitLookup
	
	/*===================================================================*/
	/*===================================================================*/
	/*							ALL GET CALLS							 */
	/*===================================================================*/
	/*===================================================================*/
	
	def cap_assessment(){
		getUser()
	}
	
	def getAssessment(){
		def report_number = params['reportno']
		def masterList = OAMaster.get(report_number)
		
		if (masterList.type == 'Capacity'){
			redirect(action: "getcapAssessment", params: [reportno: report_number])
		} else if(masterList.type == 'Inventory'){
			redirect(action: "getinvAssessment", params: [reportno: report_number])
		} else if(masterList.type == 'Document'){
		redirect(action: "getdocAssessment", params: [reportno: report_number])
		}else{
			render "Assessment not found error!!"
		}		
	}
	
	
	def getcapAssessment(){
		def report_number = params['reportno']
		
		def masterList = AssessMaster.get(report_number)
		def cpuList = AssessCPU.get(report_number)
		def memList = AssessMemory.get(report_number)
		def dskList = AssessDisk.get(report_number)
		def fsList = AssessFileSystem.get(report_number)
		def issuesList = CapacityIssues.findAll("from CapacityIssues as ci where ci.capnumber = ${report_number}")
		[master: masterList, cpu: cpuList, mem: memList, dsk: dskList, fs: fsList, issues: issuesList]
	}
	
	
	
	def getdocAssessment(){
		def report_number = params['reportno']
		
		def masterList = DocMaster.get(report_number)
		def detailList = DocDetails.findAll("from DocDetails as dd where dd.docnumber = ${report_number}")
		def issuesList = DocIssues.findAll("from DocIssues as ci where ci.docnumber = ${report_number}")
		[master: masterList, details: detailList, issues: issuesList]
	}
	
	
	
	def getinvAssessment(){
		def report_number = params['reportno']
		
		def masterList = InvMaster.get(report_number)
		def issuesList = InvIssues.findAll("from InvIssues as II where II.invnumber = ${report_number}")
		[master: masterList, issues: issuesList]
	}
	
	
	
	/*===================================================================*/
	/*===================================================================*/
	/*						 ALL PRINT CALLS							 */
	/*===================================================================*/
	/*===================================================================*/
	
	def print_document(){
		def report_number = params['docnumber']
		
		def masterList = DocMaster.get(report_number)
		def detailList = DocDetails.findAll("from DocDetails as dd where dd.docnumber = ${report_number}")
		def issuesList = DocIssues.findAll("from DocIssues as ci where ci.docnumber = ${report_number}")
		[master: masterList, details: detailList, issues: issuesList]
	}
	
	
	
	def print_inventory(){
		def report_number = params['invnumber']
		
		def masterList = InvMaster.get(report_number)
		def issuesList = InvIssues.findAll("from InvIssues as II where II.invnumber = ${report_number}")
		[master: masterList, issues: issuesList]
	}
	
	
	
	def print_capacity(){
		def report_number = params['capnumber']
		
		def masterList = AssessMaster.get(report_number)
		def cpuList = AssessCPU.get(report_number)
		def memList = AssessMemory.get(report_number)
		def dskList = AssessDisk.get(report_number)
		def fsList = AssessFileSystem.get(report_number)
		def issuesList = CapacityIssues.findAll("from CapacityIssues as ci where ci.capnumber = ${report_number}")
		
		[master: masterList, cpu: cpuList, mem: memList, dsk: dskList, fs: fsList, issues: issuesList]
	}
	
	
	/*===================================================================*/
	/*===================================================================*/
	/*							ALL EDIT CALLS							 */					
	/*===================================================================*/
	/*===================================================================*/
	
	def editcapAssessment(){
		getUser()
		//println "ID to get data - " + params.id
		def capacityInstance = CapacityIssues.get(params.id)
        if (!capacityInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
            return
        }
        [capacityInstance: capacityInstance]
	}
	
	def editinvAssessment(){
		getUser()
		//println "ID to get data - " + params.id
		def inventoryInstance = InvIssues.get(params.id)
		if (!inventoryInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'invIssues.label', default: 'InvIssues'), params.id])
			redirect(action: "list")
			return
		}
		[inventoryInstance: inventoryInstance]
	}
	
	
	
	def editdocAssessment(){
		getUser()
		//println "ID to get data - " + params.id
		def documentInstance = DocIssues.get(params.id)
		if (!documentInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'docIssues.label', default: 'DocIssues'), params.id])
			redirect(action: "list")
			return
		}
		[documentInstance: documentInstance]
	}
	
	
	/*===================================================================*/
	/*===================================================================*/
	/*							ALL FORM SUBMITS						 */
	/*===================================================================*/
	/*===================================================================*/
	
	def inventoryData(){
		def db = new Sql(dataSource)
				
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		
		def aitnum = params.get('aitLookup')
		
		/*--- CONFIG Information Section ---*/
		//def invIdentify = params.get('inv_identify')
		def invConfig = params.get('inv_config')
		def invDR = params.get('inv_dr')
		
		def dr_date = params.get('drdate')
		def dr_document = params.get('dr_document')
		
		def user_id = params.get('user_name')
		//println "User : " + user_id
		def email = params.get('email')
		
		java.util.Date date_got = new java.util.Date();
		def uniqueKey = date_got.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_added = df.format(date_got);
		
		def insertMasterEntries,inventoryMaster,inventoryReport
		if(invDR == "0"){
			insertMasterEntries = """\
			insert into hotpdb.oassess_inventory_master_checklist
			(invid,aitnumber,config,dr,createdate,username,email)
			values (?,?,?,?,?,?,?)
		"""
			inventoryMaster = [uniqueKey,aitnum,invConfig,invDR,date_added,user_id,email]
		
			inventoryReport = db.execute(insertMasterEntries, inventoryMaster)
			
		}else{
				insertMasterEntries = """\
				insert into hotpdb.oassess_inventory_master_checklist
				(invid,aitnumber,config,dr,drdate,drdocument,createdate,username,email)
				values (?,?,?,?,?,?,?,?,?)
			"""
				inventoryMaster = [uniqueKey,aitnum,invConfig,invDR,dr_date,dr_document,date_added,user_id,email]
			
				inventoryReport = db.execute(insertMasterEntries, inventoryMaster)
		}
		
		/* -- FOR REPORTING ONLY --*/
		def insertReporting = """\
			insert into hotpdb.oassess_master_checklist (repid,aitnumber,type,
			createdate,username,email) values (?,?,?,?,?,?)
		"""
		def arrayReport = [uniqueKey,aitnum,'Inventory',date_added,user_id,email]
		def issueReport = db.execute(insertReporting, arrayReport)
		/* -- Reporting Ends --*/
		
		/* EXECUTIVE SUMMARY SECTION */
		def inventorynumber
		def issue_text, issue_title
		def issue_category
		def issue_status, issue_action
		def issue_assignby
		def issue_assignemail
		def createdate
		def duedate
		
		params.entrySet().each{
			if (it.key.toString().contains("obsv")){
				inventorynumber = it.key.toString().substring(4)
				issue_title = params.get('title' + inventorynumber)
				issue_text = params.get('issues' + inventorynumber)
				issue_category = it.value
				issue_status = params.get('taskstatus' + inventorynumber)
				issue_action = params.get('invaction' + inventorynumber)
				createdate = params.get('createdate' + inventorynumber)
				duedate = params.get('duedate' + inventorynumber)
				
				if (!(issue_title) && !(issue_text)){
				} else {
					def insertIssues = """\
						insert into hotpdb.oassess_inventory_checklist 
						(invnumber,aitnumber,inv_title,inv_text,inv_category,inv_status,inv_action,duedate)
						values (?,?,?,?,?,?,?,?)
					"""
					def issueArray = [uniqueKey,aitnum,issue_title,issue_text,issue_category,issue_status,issue_action,duedate]
					def issueCreate = db.execute(insertIssues, issueArray)
				
					def insertaudit = """\
						insert into hotpdb.oassess_audit_entries (oassess_key, oassess_category, oassess_subcategory,
						user_name,entrydate,description) values (?,?,?,?,?,?)
					"""
				
					def auditArray = [uniqueKey, 'Inventory - ' + issue_category, 'Create', user_id, createdate,
					 'New issues registered for the AIT']
					db.execute(insertaudit, auditArray)
				}
			}
		}
		
		redirect(action: "getinvAssessment", params: [reportno: uniqueKey])
	}
	
	
	
	
	def documentData(){

		def db = new Sql(dataSource)
					
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		
		def aitnum = params.get('aitLookup')
		def docident = params.get('doc_identify')
		def user_name = params.get('user_name')
		def email = params.get('email')
		
		java.util.Date date_got = new java.util.Date();
		def uniqueKey = date_got.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_added = df.format(date_got);
		
		//println "Unique Key --> " + uniqueKey + " Today's date - "  + date_added
		
		/*-- Master Table - Registering the AIT for first use --*/
		def insertCfg = """\
			insert into hotpdb.oassess_document_master_checklist (docid,aitnumber,identify,
			createdate,username,email) values (?,?,?,?,?,?)
		"""

		def issueArray = [uniqueKey,aitnum,docident,date_added,user_name,session['email']]
		def docCreate = db.execute(insertCfg, issueArray)
		
		/* -- FOR REPORTING ONLY --*/
		def insertReporting = """\
			insert into hotpdb.oassess_master_checklist (repid,aitnumber,type,
			createdate,username,email) values (?,?,?,?,?,?)
		"""
		def arrayReport = [uniqueKey,aitnum,'Document',date_added,user_name,email]
		def issueReport = db.execute(insertReporting, arrayReport)
		/* -- Reporting Ends --*/
		
		
		/* -- BASIC DOCUMENTATION FIRST ENTRY -- */
		
		def docno, doc_type, docflag, loc_type, loc_text
		params.entrySet().each{
			if (it.key.toString().contains("docflag")){
				docno = it.key.toString().substring(7)
				doc_type = params.get('doc_type' + docno)
				docflag = it.value
				loc_type = params.get('loc_type' + docno)
				loc_text = params.get('doc_link' + docno)
				
				if (docflag == 'Yes'){
					def basicdocEntries = """\
						insert into hotpdb.docassess_document_checklist (docnumber,doctype,flag,
						loctype,document_link) values (?,?,?,?,?)
					"""
					def basicdocArray = [uniqueKey,doc_type,docflag,loc_type,loc_text]
					def basicdocCreate = db.execute(basicdocEntries, basicdocArray)
				}
			}
		}
		
		/* -- ADDITIONAL DOCUMENTATION FIRST ENTRY -- */
		
		def add_docno, add_loc_type, add_loc_text
		params.entrySet().each{
			if (it.key.toString().contains("addsel")){
				add_docno = it.key.toString().substring(6)
				add_loc_type = it.value
				add_loc_text = params.get('add_doc' + add_docno)
				
				if (docflag == 'Yes'){
					def adddocEntries = """\
						insert into hotpdb.docassess_document_checklist (docnumber,doctype,flag,
						loctype,document_link) values (?,?,?,?,?)
					"""
					def adddocArray = [uniqueKey,'Additional Documents','Yes',add_loc_type,add_loc_text]
					def adddocCreate = db.execute(adddocEntries, adddocArray)
				}
			}
		}
		
		/*-- DOCUMENTATION ISSUES DESCRIPTION --*/
		
		def issuenumber, issue_category,issue_text,issue_title,issue_status,issue_action,createdate,duedate
		params.entrySet().each{
			if (it.key.toString().contains("docissues")){
				issuenumber = it.key.toString().substring(9)
				issue_category = params.get('docobsv' + issuenumber)
				
				issue_title = params.get('title' + issuenumber)
				issue_text = it.value
				issue_status = params.get('taskstatus' + issuenumber)
				issue_action = params.get('docaction' + issuenumber)
				createdate = params.get('createdate' + issuenumber)
				duedate = params.get('duedate' + issuenumber)
				if (!(issue_title) && !(issue_text)){
				} else {
					def documentIssues = """\
						insert into hotpdb.oassess_document_checklist (docnumber,aitnumber,doc_text,
						doc_category,doc_status,doc_action,duedate) values (?,?,?,?,?,?,?)
					"""
					def documentArray = [uniqueKey,aitnum,issue_text,issue_category,issue_status,issue_action,duedate]
					def documentCreate = db.execute(documentIssues, documentArray)
					
					def insertaudit = """\
					insert into hotpdb.oassess_audit_entries (oassess_key, oassess_category,oassess_subcategory,
						user_name,entrydate,description) values (?,?,?,?,?,?)"""
					def auditArray = [uniqueKey, 'Document - ' + issue_category, 'Create', user_name, createdate,
						'New document issues registered for the AIT']
					db.execute(insertaudit, auditArray)
				}
			}
		}
		
		redirect(action: "getdocAssessment", params: [reportno: uniqueKey])
		//render "Documents added successfully!!"
		/* Executive Summary section ends */
	}
	

	
			
	def capacityData(){
		def db = new Sql(dataSource)
				
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		
		def aitnum = params.get('aitLookup')
		
		/*--- CONFIG Information Section ---*/
		//def capident = params.get('cap_identify')
		def bmetrics = params.get('cap_config')
		def repo_link = params.get('business_Metrics')
		
		/*--- Hidden Sections ---*/
		
		java.util.Date date_got = new java.util.Date();
		def uniqueKey = date_got.getTime();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");
		String date_added = df.format(date_got);
		def user_name = params.get('user_name')
		//println "User : " + user_id
		def email = params.get('email')
		
		//println "Unique Key --> " + uniqueKey + " Today's date - "  + date_added
		
		def insertCfg = """\
				insert into hotpdb.oassess_capacity_master_checklist (capid,aitnumber,bmetrics,
					repo_link,createdate,username,email) values (?,?,?,?,?,?,?)"""
		
		def issueArray = [uniqueKey,aitnum,bmetrics,repo_link,date_added,user_name,email]
		def capCreate = db.execute(insertCfg, issueArray)
		
		/* -- FOR REPORTING ONLY --*/
		def insertReporting = """\
			insert into hotpdb.oassess_master_checklist (repid,aitnumber,type,
			createdate,username,email) values (?,?,?,?,?,?)
		"""
		def arrayReport = [uniqueKey,aitnum,'Capacity',date_added,user_name,email]
		def issueReport = db.execute(insertReporting, arrayReport)
		/* -- Reporting Ends --*/
		
		/*--- CPU Information ---*/
		
		def cpu_Q1 = params.get('cpu_Q1')
		def cpu_Q2 = params.get('cpu_Q2')
		def cpu_Q3 = params.get('cpu_Q3')
		def cpu_Q4 = params.get('cpu_Q4')
		def cpu_Q5 = params.get('cpu_Q5')
		def cpu_Q6 = params.get('cpu_Q6')
		
		
		def insertCPU = """\
			insert into hotpdb.capassess_cpu_checklist (cpuid,Q1,Q2,Q3,Q4,Q5,Q6)
			values (${uniqueKey},${cpu_Q1},${cpu_Q2},${cpu_Q3},${cpu_Q4},
			${cpu_Q5},${cpu_Q6})
		"""
		
		def cpuCreate = db.execute(insertCPU)

		/*--- Memory Information ---*/
		
		def mem_Q1 = params.get('mem_Q1')
		def mem_Q2 = params.get('mem_Q2')
		def mem_Q3 = params.get('mem_Q3')
		def mem_Q4 = params.get('mem_Q4')
		def mem_Q5 = params.get('mem_Q5')
		
		def insertMemory = """\
			insert into hotpdb.capassess_memory_checklist (memid,Q1,Q2,Q3,Q4,Q5)
			values (${uniqueKey},${mem_Q1},${mem_Q2},${mem_Q3},${mem_Q4},
			${mem_Q5})
		"""
		def memCreate = db.execute(insertMemory)
		
		/*--- DISK Information ---*/
		
		def disk_Q1 = params.get('disk_Q1')
		def disk_Q2 = params.get('disk_Q2')
		
		
		def insertDisk = """\
			insert into hotpdb.capassess_diskp_checklist (dskid,Q1,Q2)
			values (${uniqueKey},${disk_Q1},${disk_Q2})
		"""
		//println insertDisk
		def diskCreate = db.execute(insertDisk)

		/*--- FILESYSTEM Information ---*/
		
		def fs_Q1 = params.get('file_Q1')
		def fs_Q2 = params.get('file_Q2')
		
		
		def insertFS = """\
			insert into hotpdb.capassess_filesys_checklist (fsid,Q1,Q2)
			values (${uniqueKey},${fs_Q1},${fs_Q2})
		"""
		//println insertFS
		def fsCreate = db.execute(insertFS)
		
		/* EXECUTIVE SUMMARY SECTION */
		def issuenumber
		def issue_text, issue_title
		def issue_category
		def issue_status,issue_action
		def createdate
		def duedate
		
		params.entrySet().each{
			if (it.key.toString().contains("capissues")){
				issuenumber = it.key.toString().substring(9)
				issue_category = params.get('capobsv' + issuenumber)
				issue_title = params.get('title' + issuenumber)
				issue_text = it.value
				issue_status = params.get('taskstatus' + issuenumber)
				issue_action = params.get('capaction' + issuenumber)
				createdate = params.get('createdate' + issuenumber)
				duedate = params.get('duedate' + issuenumber)
				if (!(issue_title) && !(issue_text)){
				} else {
					def capacityIssues = """\
						insert into hotpdb.oassess_capacity_checklist (capnumber,aitnumber,cap_title,cap_text,
						cap_category,cap_status,cap_action,duedate) values (?,?,?,?,?,?,?,?)
					"""
					def capacityArray = [uniqueKey,aitnum,issue_title,issue_text,issue_category,issue_status,issue_action,duedate]
					def capacityCreate = db.execute(capacityIssues, capacityArray)
					
					def insertaudit = """\
					insert into hotpdb.oassess_audit_entries (oassess_key, oassess_category,oassess_subcategory,
						user_name,entrydate,description) values (?,?,?,?,?,?)"""
					def auditArray = [uniqueKey, 'Capacity - ' + issue_category, 'Create', user_name, createdate,
						'New capacity issues registered for the AIT']
					db.execute(insertaudit, auditArray)
				}
			}
		}
		
		redirect(action: "getcapAssessment", params: [reportno: uniqueKey])
	}

	/*===================================================================*/
	/*===================================================================*/
	/*				Lookups and Functionality Calls						 */
	/*===================================================================*/
	/*===================================================================*/
	
	def aitLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitName
		
		def queryString = """\
			Select capacity_workflow_master.aitshortname as ait_aitshortname,
			capacity_workflow_master.aitnumber as ait_aitnumber,capacity_workflow_master.aittier, 
			capacity_workflow_master.ucal_flag, capacity_workflow_master.dashboard_flag,
			capacity_workflow_master.db_link, capacity_workflow_master.processed FROM hotpdb.capacity_workflow_master
			WHERE (capacity_workflow_master.aitshortname LIKE '"""+aitLookup+"""%'
			OR capacity_workflow_master.aitnumber LIKE '"""+aitLookup+"""%')
			LIMIT 15
		"""
		//println queryString
		
		def result = db.rows(queryString)
		render result as JSON
	}
	
	/*===================================================================*/
	/*===================================================================*/
	/*					Inventory Lookup main functions					 */
	/*===================================================================*/
	/*===================================================================*/
	
	def invLookup(){
		def db = new Sql(dataSource)
		def aitLookup = params.aitnumber
		
		def queryString = """\
			Select extdb.mdh_compsys.compsys_hostname as Hostname, extdb.mdh_compsys.compsys_operatingenv as Environment,
			extdb.dss_nos.serverfunction as Role, extdb.dss_hardware1xs.computermfr as Mfr, extdb.dss_hardware1xs.computermodel as Hardware_Model,
			extdb.mdh_compsys.COMPSYS_STATUS as Status,extdb.mdh_compsys.COMPSYS_OSNAME as Operating_System,
			extdb.mdh_compsys.compsys_region as Region, extdb.mdh_compsys.compsys_city as City, 
			extdb.mdh_compsys.compsys_os_dnp as OS_DNP, extdb.mdh_compsys.compsys_hw_dnp as HW_DNP,
			extdb.mdh_compsys.compsys_is_virtual as IsVirtual FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel 
			ON mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
			INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID 
			LEFT JOIN extdb.dss_nos ON dss_nos.servername = mdh_compsys.compsys_hostname
			LEFT JOIN extdb.dss_hardware1xs ON dss_hardware1xs.servername = mdh_compsys.compsys_hostname
			WHERE extdb.mdh_ait.ait_cto = 'GWBT&O' AND extdb.mdh_compsys.compsys_operatingenv not in ('Lab')
			AND extdb.mdh_ait.AIT_AITNUMBER LIKE '"""+aitLookup+"""%'
			order by mdh_compsys.compsys_operatingenv desc, mdh_compsys.compsys_hostname asc
		"""
		
		def result = db.rows(queryString)
		render result as JSON
	}
	
	def getAssesslist(){
		def db = new Sql(dataSource)
		def assessStr = """\
			Select concat("<a href='../assessments/getAssessment/?reportno=",CAST(repid AS CHAR),"' target='_blank'>",CAST(repid as CHAR),"</a>") as ReportNumber,
				type as ReportType, DATE_FORMAT(createdate,'%m-%d-%Y') as DateGenerated, aitnumber as AITNum, username as Author
				from hotpdb.oassess_master_checklist where aitnumber = ${params.aitnumber}
				order by createdate desc limit 10;
		 """
		
		def AssessList = db.rows(assessStr)
		render AssessList as JSON
	}
	
	def getHostlist(){
		def db = new Sql(dataSource)
		
		def dntBaseLink="http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?Export=false&hostNames=";
		
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd")
		Date date = new Date()
		def todaydate = df.format(date);
		def begindate;
		
		use ( TimeCategory ){
			begindate = df.format(date - 3.months)
		}
		
		def dntFollowLink = "&BeginDate=" + begindate + "&EndDate=" + todaydate;

		/*def hostString = """\
			Select auto_ait2host.aitnumber as AIT, auto_ait2host.hostname as Hostname,
			auto_ait2host.environment as Environment, auto_ait2host.role as ServerRole,
			concat("<a href='http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?
			Export=false&hostNames=",auto_ait2host.hostname,"${dntFollowLink}' target='_blank'>",
			"DNT Graph </a>") as DNTLink
			from hotpdb.auto_ait2host where auto_ait2host.environment in ('Production','Contingency') AND
			auto_ait2host.aitnumber = ${params.aitnumber}
			order by auto_ait2host.environment desc, auto_ait2host.hostname asc
		"""*/
		
		def hostString = """\
			select extdb.mdh_ait.AIT_AITNUMBER as aitno, mdh_compsys.compsys_hostname as Hostname,
			mdh_compsys.compsys_operatingenv as Environment, extdb.dss_nos.serverfunction as Role, 
			mdh_compsys.compsys_os_software_name as OSType,
			concat("<a href='http://dnt.bankofamerica.com/Portal/Graphing/Grapher/Grapher.aspx?
			Export=false&hostNames=",mdh_compsys.compsys_hostname,"${dntFollowLink}' target='_blank'>",
			"DNT Graph </a>") as DNTLink
			FROM extdb.mdh_compsys INNER JOIN extdb.mdh_app_compsys_rel ON
			mdh_compsys.COMPSYS_CMSCIID = mdh_app_compsys_rel.REL_COMPSYS
			INNER JOIN extdb.mdh_ait ON mdh_app_compsys_rel.REL_APP = mdh_ait.AIT_CMSCIID
			LEFT JOIN extdb.dss_nos ON dss_nos.servername = mdh_compsys.compsys_hostname
			WHERE extdb.mdh_ait.ait_cto = 'GWBT&O' AND
			mdh_compsys.compsys_operatingenv in ('Contingency','Production')  AND
			extdb.mdh_ait.AIT_AITNUMBER = ${params.aitnumber}
		"""
		
		def configureList = db.rows(hostString)
		render configureList as JSON
	}
	
	
	/*def getHostlist(){
		def db = new Sql(dataSource)
		def hostString = """\
			Select auto_ait2host.aitnumber as AIT, auto_ait2host.hostname as Hostname, 
			auto_ait2host.environment as Environment, auto_ait2host.role as ServerRole,auto_ait2host.osname as OS 
			from hotpdb.auto_ait2host where auto_ait2host.environment in ('Production','Contingency') AND 
			auto_ait2host.aitnumber = ${params.aitnumber} 
			order by auto_ait2host.environment desc, auto_ait2host.hostname asc
		"""
		
		def configureList = db.rows(hostString)
		render configureList as JSON
	}*/
	
	def getcsvHosts(){
		def chk = new Sql(dataSource)
		def query = """\
			Select auto_ait2host.hostname as Hostname,auto_ait2host.environment as Environment from hotpdb.auto_ait2host
			where auto_ait2host.environment in ('Production','Contingency') AND 
			auto_ait2host.aitnumber = ${params.aitnumber}
		"""
		List hostProd = new ArrayList()
		List hostCont = new ArrayList()
		chk.eachRow(query) {
			if(it.Environment == "Production"){
				hostProd.push(it.Hostname)
			}
			
			if(it.Environment == "Contingency"){
				hostCont.push(it.Hostname)
			}
		}
		def listSize = hostProd.size()
		
		//println listSize
		def prodString = hostProd.join(",")
		def contString = hostCont.join(",")
		
		render (prodString + ":" + contString)
	}
	
	def getHelpContent(){
		def dbh = new Sql(dataSource)
		if (params.helpident){
			def getHelpdata = """\
				select capacity_workflow_help.help_subj,capacity_workflow_help.help_text
				from hotpdb.capacity_workflow_help where
			capacity_workflow_help.help_key = '"""+params.helpident+"""'
			"""
			
			def result = dbh.rows(getHelpdata)
			render result as JSON
		}
	}
	
	def getUser(){
		def myid = request.getHeader("uid")	
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName") + " " + ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
	
	/*===================================================================*/
	/*===================================================================*/
	/*							ALL UPDATE CALLS						 */
	/*===================================================================*/
	/*===================================================================*/
	def updateCap() {
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')

		/*--- CONFIG Information Section ---*/
		def capNum = params.get('id')
		def capnumber = params.get('capnumber')
		def capText = params.get('cap_text')
		def capStatus = params.get('cap_status')
		def capAction = params.get('cap_action')
		def duedate = params.get('duedate')
		
		def capacityIssues = """\
			update hotpdb.oassess_capacity_checklist set cap_text=?,cap_status=?,duedate=?,cap_action=? 
			where capid = ?
		"""
		def capacityArray = [capText,capStatus,duedate,capAction,capNum]
		def capacityCreate = db.execute(capacityIssues, capacityArray)
		
		redirect(action: "getcapAssessment", params: [reportno: capnumber])	
	}
	
	
	def updateInv() {
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')

		/*--- CONFIG Information Section ---*/
		def invNum = params.get('id')
		def invnumber = params.get('invnumber')
		def invText = params.get('inv_text')
		def invStatus = params.get('inv_status')
		def invAction = params.get('inv_action')
		def duedate = params.get('duedate')
		
		def inventoryIssues = """\
			update hotpdb.oassess_inventory_checklist set inv_text=?,inv_status=?,duedate=?,inv_action=?
			where invid = ?
		"""
		def inventoryArray = [invText,invStatus,duedate,invAction,invNum]
		def inventoryCreate = db.execute(inventoryIssues, inventoryArray)
		
		redirect(action: "getinvAssessment", params: [reportno: invnumber])
	}
	
	def updateDoc() {
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')

		/*--- CONFIG Information Section ---*/
		def docNum = params.get('id')
		def docnumber = params.get('docnumber')
		def docText = params.get('doc_text')
		def docStatus = params.get('doc_status')
		def docAction = params.get('doc_action')
		def duedate = params.get('duedate')
		
		def documentIssues = """\
			update hotpdb.oassess_document_checklist set doc_text=?,doc_status=?,duedate=?,doc_action=?
			where docid = ?
		"""
		def documentArray = [docText,docStatus,duedate,docAction,docNum]
		def documentCreate = db.execute(documentIssues, documentArray)
		
		redirect(action: "getdocAssessment", params: [reportno: docnumber])
	}
	
	/*===================================================================*/
	/*===================================================================*/
	/*							ALL INPUT PAGE CALLS					 */
	/*===================================================================*/
	/*===================================================================*/
	
	def inventory_assessment(){
		getUser()	
	}
	
	def inventorytest(){
		getUser()
	}
	
	def capacity_assessment(){
		getUser()
	}
	
	def document_assessment(){
		getUser()
	}
	
	def index() {
		getUser()
		redirect(action: "retrieve_assessments")
	}
	
	def retrieve_assessments() {
		getUser()
	}
	
}
