package oachecks

import grails.converters.JSON
import groovy.sql.Sql
import groovy.transform.Canonical
import org.springframework.dao.DataIntegrityViolationException
import com.bankofamerica.gwbio.ia.LDAPFunctions.LDAPSearch
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date

class ReportsController {
	
	static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource
	
    def index() {
		 
	}
	
	def report_issues(){
		getUser()
	}
	
	def reportData(){
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')
		
		def fromdate = params['fromdate']
		def todate = params['todate']
		def report_type = params['reptype']
		
		//println "From : " + fromdate + ", To : " + todate + ", Report Type : " + report_type
		
		def reportQuery, result
		if (report_type == 'Inventory'){
			reportQuery = """\
				Select a.inv_category as '"""+report_type+""" Issue Category',count(b.invid) as 'No. of Issues' 
				from hotpdb.oassess_inventory_checklist a, hotpdb.oassess_inventory_master_checklist b
				where a.invnumber = b.invid and b.createdate between '"""+fromdate+"""' and '"""+todate+"""'
				group by a.inv_category
			"""	
				
			println reportQuery
			result = db.rows(reportQuery)
				
		}else if(report_type == 'Capacity'){
		
			reportQuery = """\
				Select a.cap_category as '"""+report_type+""" Issue Category',count(b.capid) as 'No. of Issues'
				from hotpdb.oassess_capacity_checklist a, hotpdb.oassess_capacity_master_checklist b
				where a.capnumber = b.capid and b.createdate between '"""+fromdate+"""' and '"""+todate+"""'
				group by a.cap_category
			"""
				println reportQuery
				result = db.rows(reportQuery)
		}else{
		
			reportQuery = """\
				Select a.doc_category as '"""+report_type+""" Issue Category',count(b.docid) as 'No Of Issues'
				from hotpdb.oassess_document_checklist a, hotpdb.oassess_document_master_checklist b
				where a.docnumber = b.docid and b.createdate between '"""+fromdate+"""' and '"""+todate+"""'
				group by a.doc_category
			"""
				result = db.rows(reportQuery)
		}
		
		render result as JSON
		
	}
	
	def ait_coverage() {
		def db = new Sql(dataSource)
		
		def aitLists = "Select distinct aitnumber from hotpdb.oassess_master_checklist"
		def aitResults = db.rows(aitLists)
		
		def typeLists = """\
			select distinct a.aitnumber,'Capacity' as RepType from oassess_capacity_master_checklist a, oassess_master_checklist b where 
			a.aitnumber = b.aitnumber 
			UNION
			select distinct a.aitnumber,'Document' as RepType from oassess_document_master_checklist a, oassess_master_checklist b where 
			a.aitnumber = b.aitnumber 
			UNION
			select distinct a.aitnumber,'Inventory' as RepType from oassess_inventory_master_checklist a, oassess_master_checklist b where 
			a.aitnumber = b.aitnumber
		"""
		
		def listResults = db.rows(typeLists)
		
		[aitResults : aitResults, listResults : listResults]
	
	}
	
	def updateReportData() {
		def db = new Sql(dataSource)
		
		params.remove('controller')
		params.remove('action')
		params.remove('sendupdate')

		/*--- CONFIG Information Section ---*/
		def repid = params.get('id')
		def assigned_user = params.get('assigned_admin')
		def assigned_email = params.get('admin_email')
		
		def updateIssues = """\
			update hotpdb.oassess_master_checklist set assigned=?,assigned_email=?
			where repid = ?
		"""
		def updateArray = [assigned_user,assigned_email,repid]
		def updateCreate = db.execute(updateIssues, updateArray)
		
		redirect(action: "list")
	}
	
	
	/*-- LIST INTERFACE --*/
	def list() {
		getUser()
		def db = new Sql(dataSource)
		
		def numofdays = params['numofdays']
		def username = session['name']
		
		if(!numofdays){
			numofdays = 7;
		}
		
		def dataBout = """\
			a.repid as repid, a.aitnumber as aitnumber, a.type as type, a.createdate as createdate, 
			a.username as username,a.email as email,a.assigned,c.aittier,c.ucal_flag
		"""
		
		def query="""\
			select """+dataBout+""", count(b.capid) as issuecount from 
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_capacity_checklist b on a.repid = b.capnumber 
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber 
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() and b.cap_status not in ('Resolved','Waivered') 
			 group by capnumber
			UNION
			select """+dataBout+""", count(b.invid) as issuecount from 
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_inventory_checklist b on a.repid = b.invnumber
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber 
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() and b.inv_status not in ('Resolved','Waivered')
			 group by invnumber
			UNION
			select """+dataBout+""", count(b.docid) as issuecount from 
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_document_checklist b on a.repid = b.docnumber
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber   
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() and b.doc_status not in ('Resolved','Waivered')
			 group by docnumber
		"""	

		def result = db.rows(query)
		[listAccountsInstanceList : result, username: username]
	}

	def report_catalog() {
		getUser()
		def db = new Sql(dataSource)
		
		[OAMasterInstanceList: OAMaster.list(params)]

		/*def numofdays = params['numofdays']
		def username = session['name']
		
		if(!numofdays){
			numofdays = 7;
		}
		
		def dataBout = """\
			a.repid as repid, a.aitnumber as aitnumber, a.type as type, a.createdate as createdate,
			a.username as username,a.email as email,a.assigned,c.aittier,c.ucal_flag
		"""
		
		def query="""\
			select """+dataBout+""", count(b.capid) as issuecount from
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_capacity_checklist b on a.repid = b.capnumber
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() group by capnumber
			UNION
			select """+dataBout+""", count(b.invid) as issuecount from
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_inventory_checklist b on a.repid = b.invnumber
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() group by invnumber
			UNION
			select """+dataBout+""", count(b.docid) as issuecount from
			hotpdb.oassess_master_checklist a inner join hotpdb.oassess_document_checklist b on a.repid = b.docnumber
			 inner join hotpdb.capacity_workflow_master c on a.aitnumber = c.aitnumber
			where a.createdate between sysdate() - interval """+numofdays+""" day and sysdate() group by docnumber
		"""

		def result = db.rows(query)
		[listAccountsInstanceList : result, username: username]
		*/
	}
	
	
	/*-- EDIT INTERFACE --*/
	def edit() {
		def listAccountsInstance = OAMaster.get(params.id)
		if (!listAccountsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'oaMaster.label', default: 'OAMaster'), params.id])
			redirect(action: "list")
			return
		}

		[listAccountsInstance: listAccountsInstance]
	}
		
	
	/*-- ASEARCHASSOCIATE Function --*/
	def searchAssociate(){
		def results
		if(params.searchName){
			   LDAPSearch search = new LDAPSearch();
			   search.LDAPComplexSearch(params.searchName);
			   results = search.getResultsList()
		}else{
					  results = [:]
					  results.put("Error", "No search term")
		}
		render results as JSON
	}
	
	def getUser(){
		def myid = request.getHeader("uid")
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName") + " " + ldapValues.get("sn")
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
		
}
