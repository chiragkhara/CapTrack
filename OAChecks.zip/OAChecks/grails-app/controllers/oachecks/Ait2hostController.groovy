package oachecks

import org.springframework.dao.DataIntegrityViolationException

class Ait2hostController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [ait2hostInstanceList: Ait2host.list(params), ait2hostInstanceTotal: Ait2host.count()]
    }

    def create() {
        [ait2hostInstance: new Ait2host(params)]
    }

    def save() {
        def ait2hostInstance = new Ait2host(params)
        if (!ait2hostInstance.save(flush: true)) {
            render(view: "create", model: [ait2hostInstance: ait2hostInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), ait2hostInstance.id])
        redirect(action: "show", id: ait2hostInstance.id)
    }

    def show() {
        def ait2hostInstance = Ait2host.get(params.id)
        if (!ait2hostInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "list")
            return
        }

        [ait2hostInstance: ait2hostInstance]
    }

    def edit() {
        def ait2hostInstance = Ait2host.get(params.id)
        if (!ait2hostInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "list")
            return
        }

        [ait2hostInstance: ait2hostInstance]
    }

    def update() {
        def ait2hostInstance = Ait2host.get(params.id)
        if (!ait2hostInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (ait2hostInstance.version > version) {
                ait2hostInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'ait2host.label', default: 'Ait2host')] as Object[],
                          "Another user has updated this Ait2host while you were editing")
                render(view: "edit", model: [ait2hostInstance: ait2hostInstance])
                return
            }
        }

        ait2hostInstance.properties = params

        if (!ait2hostInstance.save(flush: true)) {
            render(view: "edit", model: [ait2hostInstance: ait2hostInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), ait2hostInstance.id])
        redirect(action: "show", id: ait2hostInstance.id)
    }

    def delete() {
        def ait2hostInstance = Ait2host.get(params.id)
        if (!ait2hostInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "list")
            return
        }

        try {
            ait2hostInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'ait2host.label', default: 'Ait2host'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
