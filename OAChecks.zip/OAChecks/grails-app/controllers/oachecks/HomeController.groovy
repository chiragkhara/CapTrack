package oachecks
import com.bankofamerica.gwbio.ia.LDAPFunctions.*
import grails.converters.JSON


class HomeController {

    def index() {
		getUser()
	}
	
	def servicedefinitions(){
	}
	
	def contactus(){
	}
	
	def getUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
				
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
	}
	
	def displayUser(){
		def myid = request.getHeader("uid")
		
		if (myid != null){
			LDAPSearch search = new LDAPSearch(myid);
			
			if(search.getResultsList().size()>0){
				def ldapValues = search.getResultsList().get(0)
				session['username'] = ldapValues.get("uid")
				session['email'] = ldapValues.get("mail")
				session['name'] = ldapValues.get("givenName")+" "+ldapValues.get("sn")
				
			}
			else {
				session['username'] = "guest"
				session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
				session['name'] = "Guest User"
			}
			
		}else{
			session['username'] = "guest"
			session['email'] = "dg.GWB_Capacity_Planning@bankofamerica.com"
			session['name'] = "Guest User"
		}
		
		render "User : " + myid + " identified as : " + session['name'];
	}
}
