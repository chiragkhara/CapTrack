package oachecks

import org.springframework.dao.DataIntegrityViolationException

class OAMasterController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "report_catalog", params: params)
    }

    def report_catalog() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [OAMasterInstanceList: OAMaster.list(params), OAMasterInstanceTotal: OAMaster.count()]
    }

    def create() {
        [OAMasterInstance: new OAMaster(params)]
    }

    def save() {
        def OAMasterInstance = new OAMaster(params)
        if (!OAMasterInstance.save(flush: true)) {
            render(view: "create", model: [OAMasterInstance: OAMasterInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), OAMasterInstance.id])
        redirect(action: "show", id: OAMasterInstance.id)
    }

    def show() {
        def OAMasterInstance = OAMaster.get(params.id)
        if (!OAMasterInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "report_catalog")
            return
        }

        [OAMasterInstance: OAMasterInstance]
    }

    def edit() {
        def OAMasterInstance = OAMaster.get(params.id)
        if (!OAMasterInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "report_catalog")
            return
        }

        [OAMasterInstance: OAMasterInstance]
    }

    def update() {
        def OAMasterInstance = OAMaster.get(params.id)
        if (!OAMasterInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "report_catalog")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (OAMasterInstance.version > version) {
                OAMasterInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'OAMaster.label', default: 'OAMaster')] as Object[],
                          "Another user has updated this OAMaster while you were editing")
                render(view: "edit", model: [OAMasterInstance: OAMasterInstance])
                return
            }
        }

        OAMasterInstance.properties = params

        if (!OAMasterInstance.save(flush: true)) {
            render(view: "edit", model: [OAMasterInstance: OAMasterInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), OAMasterInstance.id])
        redirect(action: "show", id: OAMasterInstance.id)
    }

    def delete() {
        def OAMasterInstance = OAMaster.get(params.id)
        if (!OAMasterInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "report_catalog")
            return
        }

        try {
            OAMasterInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "report_catalog")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'OAMaster.label', default: 'OAMaster'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
