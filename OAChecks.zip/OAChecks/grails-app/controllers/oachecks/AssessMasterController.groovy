package oachecks

import org.springframework.dao.DataIntegrityViolationException

class AssessMasterController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [assessMasterInstanceList: AssessMaster.list(params), assessMasterInstanceTotal: AssessMaster.count()]
    }

    def create() {
        [assessMasterInstance: new AssessMaster(params)]
    }

    def save() {
        def assessMasterInstance = new AssessMaster(params)
        if (!assessMasterInstance.save(flush: true)) {
            render(view: "create", model: [assessMasterInstance: assessMasterInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), assessMasterInstance.id])
        redirect(action: "show", id: assessMasterInstance.id)
    }

    def show() {
        def assessMasterInstance = AssessMaster.get(params.id)
        if (!assessMasterInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "list")
            return
        }

        [assessMasterInstance: assessMasterInstance]
    }

    def edit() {
        def assessMasterInstance = AssessMaster.get(params.id)
        if (!assessMasterInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "list")
            return
        }

        [assessMasterInstance: assessMasterInstance]
    }

    def update() {
        def assessMasterInstance = AssessMaster.get(params.id)
        if (!assessMasterInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (assessMasterInstance.version > version) {
                assessMasterInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'assessMaster.label', default: 'AssessMaster')] as Object[],
                          "Another user has updated this AssessMaster while you were editing")
                render(view: "edit", model: [assessMasterInstance: assessMasterInstance])
                return
            }
        }

        assessMasterInstance.properties = params

        if (!assessMasterInstance.save(flush: true)) {
            render(view: "edit", model: [assessMasterInstance: assessMasterInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), assessMasterInstance.id])
        redirect(action: "show", id: assessMasterInstance.id)
    }

    def delete() {
        def assessMasterInstance = AssessMaster.get(params.id)
        if (!assessMasterInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "list")
            return
        }

        try {
            assessMasterInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'assessMaster.label', default: 'AssessMaster'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
