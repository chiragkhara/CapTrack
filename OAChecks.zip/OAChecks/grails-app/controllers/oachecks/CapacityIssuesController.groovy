package oachecks

import org.springframework.dao.DataIntegrityViolationException

class CapacityIssuesController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "list", params: params)
    }

    def list() {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [capacityIssuesInstanceList: CapacityIssues.list(params), capacityIssuesInstanceTotal: CapacityIssues.count()]
    }

    def create() {
        [capacityIssuesInstance: new CapacityIssues(params)]
    }

    def save() {
        def capacityIssuesInstance = new CapacityIssues(params)
        if (!capacityIssuesInstance.save(flush: true)) {
            render(view: "create", model: [capacityIssuesInstance: capacityIssuesInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), capacityIssuesInstance.id])
        redirect(action: "show", id: capacityIssuesInstance.id)
    }

    def show() {
        def capacityIssuesInstance = CapacityIssues.get(params.id)
        if (!capacityIssuesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
            return
        }

        [capacityIssuesInstance: capacityIssuesInstance]
    }

    def edit() {
        def capacityIssuesInstance = CapacityIssues.get(params.id)
        if (!capacityIssuesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
            return
        }

        [capacityIssuesInstance: capacityIssuesInstance]
    }

    def update() {
        def capacityIssuesInstance = CapacityIssues.get(params.id)
        if (!capacityIssuesInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (capacityIssuesInstance.version > version) {
                capacityIssuesInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'capacityIssues.label', default: 'CapacityIssues')] as Object[],
                          "Another user has updated this CapacityIssues while you were editing")
                render(view: "edit", model: [capacityIssuesInstance: capacityIssuesInstance])
                return
            }
        }

        capacityIssuesInstance.properties = params

        if (!capacityIssuesInstance.save(flush: true)) {
            render(view: "edit", model: [capacityIssuesInstance: capacityIssuesInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), capacityIssuesInstance.id])
        redirect(action: "show", id: capacityIssuesInstance.id)
    }

    def delete() {
        def capacityIssuesInstance = CapacityIssues.get(params.id)
        if (!capacityIssuesInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
            return
        }

        try {
            capacityIssuesInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'capacityIssues.label', default: 'CapacityIssues'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
