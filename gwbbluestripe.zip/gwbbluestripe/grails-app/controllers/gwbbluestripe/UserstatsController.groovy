package gwbbluestripe

import org.springframework.dao.DataIntegrityViolationException
import grails.converters.JSON
import groovy.sql.Sql
import groovy.time.TimeCategory
import java.text.DateFormat
import java.text.SimpleDateFormat

class UserstatsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]
	def dataSource
	
    def index() {
        redirect(action: "listUsers", params: params)
    }
	
	def charts() {
	}

	def chartbyDepartment(){
		def dbh = new Sql(dataSource)
		
		def getdataByDepartment = """\
		select hotpdb.bluestripe_userstats.mgmt_identifier,count(hotpdb.bluestripe_userstats.no_logons) as totalCount from hotpdb.bluestripe_userstats 
		where hotpdb.bluestripe_userstats.mgmt_env in ('Production','Pre-Production') group by hotpdb.bluestripe_userstats.mgmt_identifier
			"""	
			def result = dbh.rows(getdataByDepartment)
			render result as JSON
	}
	
	def chartbyMgmtServer(){
		def dbh = new Sql(dataSource)
		
		def getdataByMgmtServer = """\
			select hotpdb.bluestripe_userstats.mgmt_server,count(hotpdb.bluestripe_userstats.no_logons) as totalCount 
			from hotpdb.bluestripe_userstats
			where hotpdb.bluestripe_userstats.mgmt_env in ('Production','Pre-Production') and 
			hotpdb.bluestripe_userstats.mgmt_identifier = 'GWBIO' 
			group by hotpdb.bluestripe_userstats.mgmt_server
		"""
			def result = dbh.rows(getdataByMgmtServer)
			render result as JSON
	}
	
    def list() {
        [userstatsInstanceList: Userstats.list(params)]
    }
	
	def listUsers() {
		def userCounts = Userstats.findAll("from Userstats as US where US.mgmt_identifier='GWBIO'")
		[userstatsInstanceList: userCounts]
	}

    def create() {
        [userstatsInstance: new Userstats(params)]
    }

    def save() {
        def userstatsInstance = new Userstats(params)
        if (!userstatsInstance.save(flush: true)) {
            render(view: "create", model: [userstatsInstance: userstatsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'userstats.label', default: 'Userstats'), userstatsInstance.id])
        redirect(action: "show", id: userstatsInstance.id)
    }

    def show() {
        def userstatsInstance = Userstats.get(params.id)
        if (!userstatsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "list")
            return
        }

        [userstatsInstance: userstatsInstance]
    }

    def edit() {
        def userstatsInstance = Userstats.get(params.id)
        if (!userstatsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "list")
            return
        }

        [userstatsInstance: userstatsInstance]
    }

    def update() {
        def userstatsInstance = Userstats.get(params.id)
        if (!userstatsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (userstatsInstance.version > version) {
                userstatsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'userstats.label', default: 'Userstats')] as Object[],
                          "Another user has updated this Userstats while you were editing")
                render(view: "edit", model: [userstatsInstance: userstatsInstance])
                return
            }
        }

        userstatsInstance.properties = params

        if (!userstatsInstance.save(flush: true)) {
            render(view: "edit", model: [userstatsInstance: userstatsInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'userstats.label', default: 'Userstats'), userstatsInstance.id])
        redirect(action: "show", id: userstatsInstance.id)
    }

    def delete() {
        def userstatsInstance = Userstats.get(params.id)
        if (!userstatsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "list")
            return
        }

        try {
            userstatsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'userstats.label', default: 'Userstats'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
