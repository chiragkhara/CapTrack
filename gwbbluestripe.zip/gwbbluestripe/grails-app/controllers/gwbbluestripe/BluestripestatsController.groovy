package gwbbluestripe

import org.springframework.dao.DataIntegrityViolationException

class BluestripestatsController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index() {
        redirect(action: "listAgents", params: params)
    }

    def list() {
        [bluestripestatsInstanceList: Bluestripestats.list(params)]
    }
	
	def listAgents() {
		def configureAgents = Bluestripestats.findAll("from Bluestripestats as BS where BS.mgmt_svr in ('lkcma0gy.kcm-p01.chp.bankofamerica.com','lcdre2cb.cdr-p01.chp.bankofamerica.com','lrcha1ch.rch-p01.chp.bankofamerica.com')")
		//[bluestripestatsInstanceList: Bluestripestats.list(params)]
		
		[bluestripestatsInstanceList: configureAgents]
	}
	
			
	def export(ObjectPassed, title) {
			
		def date = new Date()
		def formattedDate = date.format('yyyyMMdd_HHmm')
		def filename = title+"_"+formattedDate
	
	
			
		response.setHeader("Content-disposition", "attachment; filename=${filename}.csv")
		response.contentType = "application/vnd.ms-excel"
				
		def outs = response.outputStream
		
		//pass all GroovyRowResult to an array of maps
		def arry = []
		ObjectPassed.each {
			def map = [:]
			map.putAll(it)
			arry.add(map)
		}
				
				
		//Push titles to output
		arry[0].each() { key, value ->
			outs << "\""+key+"\","
		}
				
		outs << "\n"
				
		//Push values to output
		arry.each() {
			it.each(){ key, value ->
				value = value.toString().replaceAll("\r\n|\n\r|\n|\r"," ").replaceAll("\\s+", " ").replaceAll (/"/, '')
				outs << "\""+value+"\","
			}
					
			outs << "\n"
		};			
		outs.flush()
		outs.close()
	
	}
	
	
	
    def create() {
        [bluestripestatsInstance: new Bluestripestats(params)]
    }

    def save() {
        def bluestripestatsInstance = new Bluestripestats(params)
        if (!bluestripestatsInstance.save(flush: true)) {
            render(view: "create", model: [bluestripestatsInstance: bluestripestatsInstance])
            return
        }

		flash.message = message(code: 'default.created.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), bluestripestatsInstance.id])
        redirect(action: "show", id: bluestripestatsInstance.id)
    }

    def show() {
        def bluestripestatsInstance = Bluestripestats.get(params.id)
        if (!bluestripestatsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "list")
            return
        }

        [bluestripestatsInstance: bluestripestatsInstance]
    }

    def edit() {
        def bluestripestatsInstance = Bluestripestats.get(params.id)
        if (!bluestripestatsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "list")
            return
        }

        [bluestripestatsInstance: bluestripestatsInstance]
    }

    def update() {
        def bluestripestatsInstance = Bluestripestats.get(params.id)
        if (!bluestripestatsInstance) {
            flash.message = message(code: 'default.not.found.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "list")
            return
        }

        if (params.version) {
            def version = params.version.toLong()
            if (bluestripestatsInstance.version > version) {
                bluestripestatsInstance.errors.rejectValue("version", "default.optimistic.locking.failure",
                          [message(code: 'bluestripestats.label', default: 'Bluestripestats')] as Object[],
                          "Another user has updated this Bluestripestats while you were editing")
                render(view: "edit", model: [bluestripestatsInstance: bluestripestatsInstance])
                return
            }
        }

        bluestripestatsInstance.properties = params

        if (!bluestripestatsInstance.save(flush: true)) {
            render(view: "edit", model: [bluestripestatsInstance: bluestripestatsInstance])
            return
        }

		flash.message = message(code: 'default.updated.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), bluestripestatsInstance.id])
        redirect(action: "show", id: bluestripestatsInstance.id)
    }

    def delete() {
        def bluestripestatsInstance = Bluestripestats.get(params.id)
        if (!bluestripestatsInstance) {
			flash.message = message(code: 'default.not.found.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "list")
            return
        }

        try {
            bluestripestatsInstance.delete(flush: true)
			flash.message = message(code: 'default.deleted.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "list")
        }
        catch (DataIntegrityViolationException e) {
			flash.message = message(code: 'default.not.deleted.message', args: [message(code: 'bluestripestats.label', default: 'Bluestripestats'), params.id])
            redirect(action: "show", id: params.id)
        }
    }
}
