package gwbbluestripe

class Bluestripestats {
	
	Integer aitnumber
	String aitshortname
	String aitstatus
	String bs_hostname
	String agentstatus
	String osname
	String coll_version
	String mgmt_svr
	String plugins
	
	static mapping = {
		table name: 'bluestripestats', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
	}
	
    static constraints = {
		aitnumber(size:0..10)
		aitshortname(size:0..100)
		aitstatus(size:0..100)
		bs_hostname(size:0..100)
		agentstatus(size:0..100)
		osname(size:0..512)
		coll_version(size:0..50)
		mgmt_svr(size:0..127)	
    }
}
