package gwbbluestripe

class Userstats {
	
	String mgmt_server
	String userid
	Integer no_logons
	String mgmt_identifier
	String mgmt_env
	Date date

	static mapping = {
		table name: 'bluestripe_userstats', schema: 'hotpdb'
		//version is set to false, because this isn't available by default for legacy databases
		version false
		id column:'id'
	}
	
    static constraints = {	
		mgmt_server(size:0..100)
		userid(size:0..100)
		no_logons(size:0..11)
		mgmt_identifier(size:0..100)
		mgmt_env(size:0..100)
		date(size:0..15)
    }
}
