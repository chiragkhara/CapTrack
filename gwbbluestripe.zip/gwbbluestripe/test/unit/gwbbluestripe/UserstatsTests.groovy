package gwbbluestripe



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Userstats)
class UserstatsTests {

    void testSomething() {
       fail "Implement me"
    }
}
