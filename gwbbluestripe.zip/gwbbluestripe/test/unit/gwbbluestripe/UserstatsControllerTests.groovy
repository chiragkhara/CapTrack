package gwbbluestripe



import org.junit.*
import grails.test.mixin.*

@TestFor(UserstatsController)
@Mock(Userstats)
class UserstatsControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/userstats/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.userstatsInstanceList.size() == 0
        assert model.userstatsInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.userstatsInstance != null
    }

    void testSave() {
        controller.save()

        assert model.userstatsInstance != null
        assert view == '/userstats/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/userstats/show/1'
        assert controller.flash.message != null
        assert Userstats.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/userstats/list'


        populateValidParams(params)
        def userstats = new Userstats(params)

        assert userstats.save() != null

        params.id = userstats.id

        def model = controller.show()

        assert model.userstatsInstance == userstats
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/userstats/list'


        populateValidParams(params)
        def userstats = new Userstats(params)

        assert userstats.save() != null

        params.id = userstats.id

        def model = controller.edit()

        assert model.userstatsInstance == userstats
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/userstats/list'

        response.reset()


        populateValidParams(params)
        def userstats = new Userstats(params)

        assert userstats.save() != null

        // test invalid parameters in update
        params.id = userstats.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/userstats/edit"
        assert model.userstatsInstance != null

        userstats.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/userstats/show/$userstats.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        userstats.clearErrors()

        populateValidParams(params)
        params.id = userstats.id
        params.version = -1
        controller.update()

        assert view == "/userstats/edit"
        assert model.userstatsInstance != null
        assert model.userstatsInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/userstats/list'

        response.reset()

        populateValidParams(params)
        def userstats = new Userstats(params)

        assert userstats.save() != null
        assert Userstats.count() == 1

        params.id = userstats.id

        controller.delete()

        assert Userstats.count() == 0
        assert Userstats.get(userstats.id) == null
        assert response.redirectedUrl == '/userstats/list'
    }
}
