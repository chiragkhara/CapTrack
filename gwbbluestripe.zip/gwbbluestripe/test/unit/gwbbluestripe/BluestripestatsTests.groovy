package gwbbluestripe



import grails.test.mixin.*
import org.junit.*

/**
 * See the API for {@link grails.test.mixin.domain.DomainClassUnitTestMixin} for usage instructions
 */
@TestFor(Bluestripestats)
class BluestripestatsTests {

    void testSomething() {
       fail "Implement me"
    }
}
