package gwbbluestripe



import org.junit.*
import grails.test.mixin.*

@TestFor(BluestripestatsController)
@Mock(Bluestripestats)
class BluestripestatsControllerTests {


    def populateValidParams(params) {
      assert params != null
      // TODO: Populate valid properties like...
      //params["name"] = 'someValidName'
    }

    void testIndex() {
        controller.index()
        assert "/bluestripestats/list" == response.redirectedUrl
    }

    void testList() {

        def model = controller.list()

        assert model.bluestripestatsInstanceList.size() == 0
        assert model.bluestripestatsInstanceTotal == 0
    }

    void testCreate() {
       def model = controller.create()

       assert model.bluestripestatsInstance != null
    }

    void testSave() {
        controller.save()

        assert model.bluestripestatsInstance != null
        assert view == '/bluestripestats/create'

        response.reset()

        populateValidParams(params)
        controller.save()

        assert response.redirectedUrl == '/bluestripestats/show/1'
        assert controller.flash.message != null
        assert Bluestripestats.count() == 1
    }

    void testShow() {
        controller.show()

        assert flash.message != null
        assert response.redirectedUrl == '/bluestripestats/list'


        populateValidParams(params)
        def bluestripestats = new Bluestripestats(params)

        assert bluestripestats.save() != null

        params.id = bluestripestats.id

        def model = controller.show()

        assert model.bluestripestatsInstance == bluestripestats
    }

    void testEdit() {
        controller.edit()

        assert flash.message != null
        assert response.redirectedUrl == '/bluestripestats/list'


        populateValidParams(params)
        def bluestripestats = new Bluestripestats(params)

        assert bluestripestats.save() != null

        params.id = bluestripestats.id

        def model = controller.edit()

        assert model.bluestripestatsInstance == bluestripestats
    }

    void testUpdate() {
        controller.update()

        assert flash.message != null
        assert response.redirectedUrl == '/bluestripestats/list'

        response.reset()


        populateValidParams(params)
        def bluestripestats = new Bluestripestats(params)

        assert bluestripestats.save() != null

        // test invalid parameters in update
        params.id = bluestripestats.id
        //TODO: add invalid values to params object

        controller.update()

        assert view == "/bluestripestats/edit"
        assert model.bluestripestatsInstance != null

        bluestripestats.clearErrors()

        populateValidParams(params)
        controller.update()

        assert response.redirectedUrl == "/bluestripestats/show/$bluestripestats.id"
        assert flash.message != null

        //test outdated version number
        response.reset()
        bluestripestats.clearErrors()

        populateValidParams(params)
        params.id = bluestripestats.id
        params.version = -1
        controller.update()

        assert view == "/bluestripestats/edit"
        assert model.bluestripestatsInstance != null
        assert model.bluestripestatsInstance.errors.getFieldError('version')
        assert flash.message != null
    }

    void testDelete() {
        controller.delete()
        assert flash.message != null
        assert response.redirectedUrl == '/bluestripestats/list'

        response.reset()

        populateValidParams(params)
        def bluestripestats = new Bluestripestats(params)

        assert bluestripestats.save() != null
        assert Bluestripestats.count() == 1

        params.id = bluestripestats.id

        controller.delete()

        assert Bluestripestats.count() == 0
        assert Bluestripestats.get(bluestripestats.id) == null
        assert response.redirectedUrl == '/bluestripestats/list'
    }
}
